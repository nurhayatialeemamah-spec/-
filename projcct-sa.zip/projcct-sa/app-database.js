// ============================================
// ระบบจัดการผัก - เชื่อมต่อกับฐานข้อมูล
// ============================================

// ตัวแปรเก็บข้อมูล
let vegetables = [];
let plantingCycles = [];
let plantings = [];
let cares = [];
let harvests = [];
let sales = [];
let salesDetails = [];

// ============================================
// ฟังก์ชัน API Call
// ============================================

async function apiCall(action, table, data = {}) {
    try {
        const formData = new FormData();
        formData.append('action', action);
        formData.append('table', table);
        
        for (let key in data) {
            formData.append(key, data[key]);
        }
        
        const response = await fetch('api.php', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        return result;
    } catch (error) {
        console.error('API Error:', error);
        return { success: false, message: 'เกิดข้อผิดพลาดในการเชื่อมต่อ' };
    }
}

// ============================================
// โหลดข้อมูลทั้งหมด
// ============================================

async function loadAllData() {
    const vegResult = await apiCall('getAll', 'vegetables');
    if (vegResult.success) vegetables = vegResult.data;
    
    const cycleResult = await apiCall('getAll', 'planting_cycles');
    if (cycleResult.success) plantingCycles = cycleResult.data;
    
    const plantResult = await apiCall('getAll', 'plantings');
    if (plantResult.success) plantings = plantResult.data;
    
    const careResult = await apiCall('getAll', 'care_records');
    if (careResult.success) cares = careResult.data;
    
    const harvestResult = await apiCall('getAll', 'harvests');
    if (harvestResult.success) harvests = harvestResult.data;
    
    const saleResult = await apiCall('getAll', 'sales');
    if (saleResult.success) sales = saleResult.data;
    
    const detailResult = await apiCall('getAll', 'sales_details');
    if (detailResult.success) salesDetails = detailResult.data;
    
    await updateAutoIdDisplays();
}

// ============================================
// อัพเดท Auto ID Displays
// ============================================

async function updateAutoIdDisplays() {
    const result = await apiCall('getNextIds', '');
    if (result.success) {
        const ids = result.data;
        document.getElementById('vegIdDisplay').value = ids.veg_id;
        document.getElementById('cycleNoDisplay').value = ids.cycle_no;
        document.getElementById('plantIdDisplay').value = ids.plant_id;
        document.getElementById('careIdDisplay').value = ids.care_id;
        document.getElementById('harvestIdDisplay').value = ids.harvest_id;
        document.getElementById('saleIdDisplay').value = ids.sale_id;
        document.getElementById('detailOrderDisplay').value = ids.detail_order;
    }
}

// ============================================
// VEGETABLES - ข้อมูลผัก
// ============================================

function renderVegetables() {
    const tbody = document.getElementById('vegetableTableBody');
    if (vegetables.length === 0) {
        tbody.innerHTML = '<tr class="empty-state"><td colspan="5"><p>ยังไม่มีข้อมูลผัก</p></td></tr>';
        return;
    }
    
    tbody.innerHTML = vegetables.map((v, index) => `
        <tr>
            <td>${v.veg_id}</td>
            <td>${v.veg_name}</td>
            <td>${v.duration}</td>
            <td>${parseFloat(v.price_per_unit).toFixed(2)}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn btn-edit" onclick="editVegetable(${index})">✏️ แก้ไข</button>
                    <button class="btn btn-delete" onclick="deleteVegetable('${v.veg_id}')">🗑️ ลบ</button>
                </div>
            </td>
        </tr>
    `).join('');
    
    updateVegetableSelects();
}

function editVegetable(index) {
    const veg = vegetables[index];
    document.getElementById('vegId').value = veg.veg_id;
    document.getElementById('vegIdDisplay').value = veg.veg_id;
    document.getElementById('vegName').value = veg.veg_name;
    document.getElementById('vegDuration').value = veg.duration;
    document.getElementById('vegPrice').value = veg.price_per_unit;
    document.getElementById('vegEditIndex').value = index;
    document.getElementById('vegSubmitBtn').textContent = '💾 บันทึกการแก้ไข';
    document.getElementById('vegCancelBtn').style.display = 'inline-flex';
    
    document.getElementById('vegetables').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function deleteVegetable(vegId) {
    if (!confirm('คุณต้องการลบข้อมูลผักนี้ใช่หรือไม่?')) return;
    
    const result = await apiCall('delete', 'vegetables', { veg_id: vegId });
    if (result.success) {
        showAlert(result.message, 'success');
        await loadAllData();
        renderVegetables();
        updateSummary();
    } else {
        showAlert(result.message, 'error');
    }
}

function cancelEditVegetable() {
    document.getElementById('vegetableForm').reset();
    document.getElementById('vegEditIndex').value = '';
    document.getElementById('vegSubmitBtn').textContent = '➕ เพิ่มข้อมูลผัก';
    document.getElementById('vegCancelBtn').style.display = 'none';
    updateAutoIdDisplays();
}

document.getElementById('vegetableForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const editIndex = document.getElementById('vegEditIndex').value;
    
    const data = {
        veg_name: document.getElementById('vegName').value,
        duration: document.getElementById('vegDuration').value,
        price: document.getElementById('vegPrice').value
    };
    
    let result;
    if (editIndex !== '') {
        data.veg_id = document.getElementById('vegId').value;
        result = await apiCall('update', 'vegetables', data);
        cancelEditVegetable();
    } else {
        result = await apiCall('add', 'vegetables', data);
        this.reset();
    }
    
    if (result.success) {
        showAlert(result.message, 'success');
        await loadAllData();
        renderVegetables();
        updateSummary();
    } else {
        showAlert(result.message, 'error');
    }
});

// ============================================
// PLANTING CYCLES - รอบการปลูก
// ============================================

function renderPlantingCycles() {
    const tbody = document.getElementById('plantingCycleTableBody');
    if (plantingCycles.length === 0) {
        tbody.innerHTML = '<tr class="empty-state"><td colspan="4"><p>ยังไม่มีข้อมูลรอบการปลูก</p></td></tr>';
        return;
    }
    
    tbody.innerHTML = plantingCycles.map((c, index) => `
        <tr>
            <td>${c.cycle_no}</td>
            <td>${c.planting_date}</td>
            <td>${c.total_plants}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn btn-edit" onclick="editCycle(${index})">✏️ แก้ไข</button>
                    <button class="btn btn-delete" onclick="deleteCycle(${c.cycle_no})">🗑️ ลบ</button>
                </div>
            </td>
        </tr>
    `).join('');
}

function editCycle(index) {
    const cycle = plantingCycles[index];
    document.getElementById('cycleNo').value = cycle.cycle_no;
    document.getElementById('cycleNoDisplay').value = cycle.cycle_no;
    document.getElementById('cycleDate').value = cycle.planting_date;
    document.getElementById('cycleAmount').value = cycle.total_plants;
    document.getElementById('cycleEditIndex').value = index;
    document.getElementById('cycleSubmitBtn').textContent = '💾 บันทึกการแก้ไข';
    document.getElementById('cycleCancelBtn').style.display = 'inline-flex';
    
    document.getElementById('plantingCycles').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function deleteCycle(cycleNo) {
    if (!confirm('คุณต้องการลบรอบการปลูกนี้ใช่หรือไม่?')) return;
    
    const result = await apiCall('delete', 'planting_cycles', { cycle_no: cycleNo });
    if (result.success) {
        showAlert(result.message, 'success');
        await loadAllData();
        renderPlantingCycles();
        updateSummary();
    } else {
        showAlert(result.message, 'error');
    }
}

function cancelEditCycle() {
    document.getElementById('plantingCycleForm').reset();
    document.getElementById('cycleEditIndex').value = '';
    document.getElementById('cycleSubmitBtn').textContent = '➕ เพิ่มรอบการปลูก';
    document.getElementById('cycleCancelBtn').style.display = 'none';
    updateAutoIdDisplays();
}

document.getElementById('plantingCycleForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const editIndex = document.getElementById('cycleEditIndex').value;
    
    const data = {
        planting_date: document.getElementById('cycleDate').value,
        total_plants: document.getElementById('cycleAmount').value
    };
    
    let result;
    if (editIndex !== '') {
        data.cycle_no = document.getElementById('cycleNo').value;
        result = await apiCall('update', 'planting_cycles', data);
        cancelEditCycle();
    } else {
        result = await apiCall('add', 'planting_cycles', data);
        this.reset();
    }
    
    if (result.success) {
        showAlert(result.message, 'success');
        await loadAllData();
        renderPlantingCycles();
        updateSummary();
    } else {
        showAlert(result.message, 'error');
    }
});

// ============================================
// PLANTINGS - การปลูก
// ============================================

function renderPlantings() {
    const tbody = document.getElementById('plantingTableBody');
    if (plantings.length === 0) {
        tbody.innerHTML = '<tr class="empty-state"><td colspan="6"><p>ยังไม่มีข้อมูลการปลูก</p></td></tr>';
        return;
    }
    
    tbody.innerHTML = plantings.map((p, index) => `
        <tr>
            <td>${p.plant_id}</td>
            <td>${p.cycle_no}</td>
            <td>${p.veg_id}</td>
            <td>${p.quantity}</td>
            <td>${p.plot_name}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn btn-edit" onclick="editPlanting(${index})">✏️ แก้ไข</button>
                    <button class="btn btn-delete" onclick="deletePlanting('${p.plant_id}')">🗑️ ลบ</button>
                </div>
            </td>
        </tr>
    `).join('');
    
    updatePlantingSelects();
}

function editPlanting(index) {
    const planting = plantings[index];
    document.getElementById('plantId').value = planting.plant_id;
    document.getElementById('plantIdDisplay').value = planting.plant_id;
    document.getElementById('plantCycleNo').value = planting.cycle_no;
    document.getElementById('plantVegId').value = planting.veg_id;
    document.getElementById('plantQuantity').value = planting.quantity;
    document.getElementById('plantPlot').value = planting.plot_name;
    document.getElementById('plantEditIndex').value = index;
    document.getElementById('plantSubmitBtn').textContent = '💾 บันทึกการแก้ไข';
    document.getElementById('plantCancelBtn').style.display = 'inline-flex';
    
    document.getElementById('planting').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function deletePlanting(plantId) {
    if (!confirm('คุณต้องการลบข้อมูลการปลูกนี้ใช่หรือไม่?')) return;
    
    const result = await apiCall('delete', 'plantings', { plant_id: plantId });
    if (result.success) {
        showAlert(result.message, 'success');
        await loadAllData();
        renderPlantings();
        updateSummary();
    } else {
        showAlert(result.message, 'error');
    }
}

function cancelEditPlanting() {
    document.getElementById('plantingForm').reset();
    document.getElementById('plantEditIndex').value = '';
    document.getElementById('plantSubmitBtn').textContent = '➕ เพิ่มข้อมูลการปลูก';
    document.getElementById('plantCancelBtn').style.display = 'none';
    updateAutoIdDisplays();
}

document.getElementById('plantingForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const editIndex = document.getElementById('plantEditIndex').value;
    
    const data = {
        cycle_no: document.getElementById('plantCycleNo').value,
        veg_id: document.getElementById('plantVegId').value,
        quantity: document.getElementById('plantQuantity').value,
        plot_name: document.getElementById('plantPlot').value
    };
    
    let result;
    if (editIndex !== '') {
        data.plant_id = document.getElementById('plantId').value;
        result = await apiCall('update', 'plantings', data);
        cancelEditPlanting();
    } else {
        result = await apiCall('add', 'plantings', data);
        this.reset();
    }
    
    if (result.success) {
        showAlert(result.message, 'success');
        await loadAllData();
        renderPlantings();
        updateSummary();
    } else {
        showAlert(result.message, 'error');
    }
});

// ============================================
// CARE RECORDS - การดูแล
// ============================================

function renderCares() {
    const tbody = document.getElementById('careTableBody');
    if (cares.length === 0) {
        tbody.innerHTML = '<tr class="empty-state"><td colspan="7"><p>ยังไม่มีข้อมูลการดูแล</p></td></tr>';
        return;
    }
    
    tbody.innerHTML = cares.map((c, index) => `
        <tr>
            <td>${c.care_id}</td>
            <td>${c.plant_id}</td>
            <td>${c.start_date}</td>
            <td>${c.end_date}</td>
            <td>${c.care_round}</td>
            <td>${c.notes || '-'}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn btn-edit" onclick="editCare(${index})">✏️ แก้ไข</button>
                    <button class="btn btn-delete" onclick="deleteCare('${c.care_id}')">🗑️ ลบ</button>
                </div>
            </td>
        </tr>
    `).join('');
}

function editCare(index) {
    const care = cares[index];
    document.getElementById('careId').value = care.care_id;
    document.getElementById('careIdDisplay').value = care.care_id;
    document.getElementById('carePlantId').value = care.plant_id;
    document.getElementById('careStartDate').value = care.start_date;
    document.getElementById('careEndDate').value = care.end_date;
    document.getElementById('careCycle').value = care.care_round;
    document.getElementById('careNote').value = care.notes || '';
    document.getElementById('careEditIndex').value = index;
    document.getElementById('careSubmitBtn').textContent = '💾 บันทึกการแก้ไข';
    document.getElementById('careCancelBtn').style.display = 'inline-flex';
    
    document.getElementById('care').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function deleteCare(careId) {
    if (!confirm('คุณต้องการลบข้อมูลการดูแลนี้ใช่หรือไม่?')) return;
    
    const result = await apiCall('delete', 'care_records', { care_id: careId });
    if (result.success) {
        showAlert(result.message, 'success');
        await loadAllData();
        renderCares();
        updateSummary();
    } else {
        showAlert(result.message, 'error');
    }
}

function cancelEditCare() {
    document.getElementById('careForm').reset();
    document.getElementById('careEditIndex').value = '';
    document.getElementById('careSubmitBtn').textContent = '➕ เพิ่มข้อมูลการดูแล';
    document.getElementById('careCancelBtn').style.display = 'none';
    updateAutoIdDisplays();
}

document.getElementById('careForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const editIndex = document.getElementById('careEditIndex').value;
    
    const data = {
        plant_id: document.getElementById('carePlantId').value,
        start_date: document.getElementById('careStartDate').value,
        end_date: document.getElementById('careEndDate').value,
        care_round: document.getElementById('careCycle').value,
        notes: document.getElementById('careNote').value
    };
    
    let result;
    if (editIndex !== '') {
        data.care_id = document.getElementById('careId').value;
        result = await apiCall('update', 'care_records', data);
        cancelEditCare();
    } else {
        result = await apiCall('add', 'care_records', data);
        this.reset();
    }
    
    if (result.success) {
        showAlert(result.message, 'success');
        await loadAllData();
        renderCares();
        updateSummary();
    } else {
        showAlert(result.message, 'error');
    }
});

// ============================================
// HARVESTS - การเก็บเกี่ยว
// ============================================

function renderHarvests() {
    const tbody = document.getElementById('harvestTableBody');
    if (harvests.length === 0) {
        tbody.innerHTML = '<tr class="empty-state"><td colspan="8"><p>ยังไม่มีข้อมูลการเก็บเกี่ยว</p></td></tr>';
        return;
    }
    
    tbody.innerHTML = harvests.map((h, index) => `
        <tr>
            <td>${h.harvest_id}</td>
            <td>${h.plant_id}</td>
            <td>${h.cycle_no}</td>
            <td>${h.harvest_date}</td>
            <td>${h.harvested_amount}</td>
            <td>${h.diseased_amount}</td>
            <td>${h.dead_amount}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn btn-edit" onclick="editHarvest(${index})">✏️ แก้ไข</button>
                    <button class="btn btn-delete" onclick="deleteHarvest('${h.harvest_id}')">🗑️ ลบ</button>
                </div>
            </td>
        </tr>
    `).join('');
    
    updateHarvestSelects();
}

function editHarvest(index) {
    const harvest = harvests[index];
    document.getElementById('harvestId').value = harvest.harvest_id;
    document.getElementById('harvestIdDisplay').value = harvest.harvest_id;
    document.getElementById('harvestPlantId').value = harvest.plant_id;
    document.getElementById('harvestCycleNo').value = harvest.cycle_no;
    document.getElementById('harvestDate').value = harvest.harvest_date;
    document.getElementById('harvestAmount').value = harvest.harvested_amount;
    document.getElementById('harvestDisease').value = harvest.diseased_amount;
    document.getElementById('harvestDead').value = harvest.dead_amount;
    document.getElementById('harvestEditIndex').value = index;
    document.getElementById('harvestSubmitBtn').textContent = '💾 บันทึกการแก้ไข';
    document.getElementById('harvestCancelBtn').style.display = 'inline-flex';
    
    document.getElementById('harvest').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function deleteHarvest(harvestId) {
    if (!confirm('คุณต้องการลบข้อมูลการเก็บเกี่ยวนี้ใช่หรือไม่?')) return;
    
    const result = await apiCall('delete', 'harvests', { harvest_id: harvestId });
    if (result.success) {
        showAlert(result.message, 'success');
        await loadAllData();
        renderHarvests();
        updateSummary();
    } else {
        showAlert(result.message, 'error');
    }
}

function cancelEditHarvest() {
    document.getElementById('harvestForm').reset();
    document.getElementById('harvestEditIndex').value = '';
    document.getElementById('harvestSubmitBtn').textContent = '➕ เพิ่มข้อมูลการเก็บเกี่ยว';
    document.getElementById('harvestCancelBtn').style.display = 'none';
    updateAutoIdDisplays();
}

document.getElementById('harvestForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const editIndex = document.getElementById('harvestEditIndex').value;
    
    const data = {
        plant_id: document.getElementById('harvestPlantId').value,
        cycle_no: document.getElementById('harvestCycleNo').value,
        harvest_date: document.getElementById('harvestDate').value,
        harvested_amount: document.getElementById('harvestAmount').value,
        diseased_amount: document.getElementById('harvestDisease').value,
        dead_amount: document.getElementById('harvestDead').value
    };
    
    let result;
    if (editIndex !== '') {
        data.harvest_id = document.getElementById('harvestId').value;
        result = await apiCall('update', 'harvests', data);
        cancelEditHarvest();
    } else {
        result = await apiCall('add', 'harvests', data);
        this.reset();
    }
    
    if (result.success) {
        showAlert(result.message, 'success');
        await loadAllData();
        renderHarvests();
        updateSummary();
    } else {
        showAlert(result.message, 'error');
    }
});

// ============================================
// SALES - การขาย
// ============================================

function renderSales() {
    const tbody = document.getElementById('salesTableBody');
    if (sales.length === 0) {
        tbody.innerHTML = '<tr class="empty-state"><td colspan="4"><p>ยังไม่มีข้อมูลการขาย</p></td></tr>';
        return;
    }
    
    tbody.innerHTML = sales.map((s, index) => `
        <tr>
            <td>${s.sale_id}</td>
            <td>${s.sale_date}</td>
            <td>${parseFloat(s.total_amount).toFixed(2)}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn btn-edit" onclick="editSale(${index})">✏️ แก้ไข</button>
                    <button class="btn btn-delete" onclick="deleteSale('${s.sale_id}')">🗑️ ลบ</button>
                </div>
            </td>
        </tr>
    `).join('');
    
    updateSalesSelects();
}

function editSale(index) {
    const sale = sales[index];
    document.getElementById('saleId').value = sale.sale_id;
    document.getElementById('saleIdDisplay').value = sale.sale_id;
    document.getElementById('saleDate').value = sale.sale_date;
    document.getElementById('saleAmount').value = sale.total_amount;
    document.getElementById('saleEditIndex').value = index;
    document.getElementById('saleSubmitBtn').textContent = '💾 บันทึกการแก้ไข';
    document.getElementById('saleCancelBtn').style.display = 'inline-flex';
    
    document.getElementById('sales').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function deleteSale(saleId) {
    if (!confirm('คุณต้องการลบข้อมูลการขายนี้ใช่หรือไม่?')) return;
    
    const result = await apiCall('delete', 'sales', { sale_id: saleId });
    if (result.success) {
        showAlert(result.message, 'success');
        await loadAllData();
        renderSales();
        updateSummary();
    } else {
        showAlert(result.message, 'error');
    }
}

function cancelEditSale() {
    document.getElementById('salesForm').reset();
    document.getElementById('saleEditIndex').value = '';
    document.getElementById('saleSubmitBtn').textContent = '➕ เพิ่มข้อมูลการขาย';
    document.getElementById('saleCancelBtn').style.display = 'none';
    updateAutoIdDisplays();
}

document.getElementById('salesForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const editIndex = document.getElementById('saleEditIndex').value;
    
    const data = {
        sale_date: document.getElementById('saleDate').value,
        total_amount: document.getElementById('saleAmount').value
    };
    
    let result;
    if (editIndex !== '') {
        data.sale_id = document.getElementById('saleId').value;
        result = await apiCall('update', 'sales', data);
        cancelEditSale();
    } else {
        result = await apiCall('add', 'sales', data);
        this.reset();
    }
    
    if (result.success) {
        showAlert(result.message, 'success');
        await loadAllData();
        renderSales();
        updateSummary();
    } else {
        showAlert(result.message, 'error');
    }
});

// ============================================
// SALES DETAILS - รายละเอียดการขาย
// ============================================

function renderSalesDetails() {
    const tbody = document.getElementById('salesDetailTableBody');
    if (salesDetails.length === 0) {
        tbody.innerHTML = '<tr class="empty-state"><td colspan="6"><p>ยังไม่มีรายละเอียดการขาย</p></td></tr>';
        return;
    }
    
    tbody.innerHTML = salesDetails.map((d, index) => `
        <tr>
            <td>${d.detail_id}</td>
            <td>${d.harvest_id}</td>
            <td>${d.sale_id}</td>
            <td>${d.quantity}</td>
            <td>${parseFloat(d.subtotal).toFixed(2)}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn btn-edit" onclick="editDetail(${index})">✏️ แก้ไข</button>
                    <button class="btn btn-delete" onclick="deleteDetail(${d.detail_id})">🗑️ ลบ</button>
                </div>
            </td>
        </tr>
    `).join('');
}

function editDetail(index) {
    const detail = salesDetails[index];
    document.getElementById('detailOrder').value = detail.detail_id;
    document.getElementById('detailOrderDisplay').value = detail.detail_id;
    document.getElementById('detailHarvestId').value = detail.harvest_id;
    document.getElementById('detailSaleId').value = detail.sale_id;
    document.getElementById('detailQuantity').value = detail.quantity;
    document.getElementById('detailTotal').value = detail.subtotal;
    document.getElementById('detailEditIndex').value = index;
    document.getElementById('detailSubmitBtn').textContent = '💾 บันทึกการแก้ไข';
    document.getElementById('detailCancelBtn').style.display = 'inline-flex';
    
    document.getElementById('salesDetails').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function deleteDetail(detailId) {
    if (!confirm('คุณต้องการลบรายละเอียดการขายนี้ใช่หรือไม่?')) return;
    
    const result = await apiCall('delete', 'sales_details', { detail_id: detailId });
    if (result.success) {
        showAlert(result.message, 'success');
        await loadAllData();
        renderSalesDetails();
        updateSummary();
    } else {
        showAlert(result.message, 'error');
    }
}

function cancelEditDetail() {
    document.getElementById('salesDetailForm').reset();
    document.getElementById('detailEditIndex').value = '';
    document.getElementById('detailSubmitBtn').textContent = '➕ เพิ่มรายละเอียดการขาย';
    document.getElementById('detailCancelBtn').style.display = 'none';
    updateAutoIdDisplays();
}

document.getElementById('salesDetailForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const editIndex = document.getElementById('detailEditIndex').value;
    
    const data = {
        harvest_id: document.getElementById('detailHarvestId').value,
        sale_id: document.getElementById('detailSaleId').value,
        quantity: document.getElementById('detailQuantity').value,
        subtotal: document.getElementById('detailTotal').value
    };
    
    let result;
    if (editIndex !== '') {
        data.detail_id = document.getElementById('detailOrder').value;
        result = await apiCall('update', 'sales_details', data);
        cancelEditDetail();
    } else {
        result = await apiCall('add', 'sales_details', data);
        this.reset();
    }
    
    if (result.success) {
        showAlert(result.message, 'success');
        await loadAllData();
        renderSalesDetails();
        updateSummary();
    } else {
        showAlert(result.message, 'error');
    }
});

// ============================================
// UPDATE DROPDOWNS
// ============================================

function updateVegetableSelects() {
    const select = document.getElementById('plantVegId');
    select.innerHTML = '<option value="">-- เลือกผัก --</option>' +
        vegetables.map(v => `<option value="${v.veg_id}">${v.veg_id} - ${v.veg_name}</option>`).join('');
}

function updatePlantingSelects() {
    const selects = [
        document.getElementById('carePlantId'),
        document.getElementById('harvestPlantId')
    ];
    
    selects.forEach(select => {
        if (select) {
            select.innerHTML = '<option value="">-- เลือกการปลูก --</option>' +
                plantings.map(p => `<option value="${p.plant_id}">${p.plant_id} - ${p.plot_name}</option>`).join('');
        }
    });
}

function updateHarvestSelects() {
    const select = document.getElementById('detailHarvestId');
    if (select) {
        select.innerHTML = '<option value="">-- เลือกการเก็บเกี่ยว --</option>' +
            harvests.map(h => `<option value="${h.harvest_id}">${h.harvest_id} - ${h.harvest_date}</option>`).join('');
    }
}

function updateSalesSelects() {
    const select = document.getElementById('detailSaleId');
    if (select) {
        select.innerHTML = '<option value="">-- เลือกการขาย --</option>' +
            sales.map(s => `<option value="${s.sale_id}">${s.sale_id} - ${s.sale_date}</option>`).join('');
    }
}

// ============================================
// SUMMARY - สรุปภาพรวม
// ============================================

async function updateSummary() {
    const result = await apiCall('getSummary', '');
    if (result.success) {
        const data = result.data;
        document.getElementById('totalVegetables').textContent = data.total_vegetables;
        document.getElementById('totalCycles').textContent = data.total_cycles;
        document.getElementById('totalPlantings').textContent = data.total_plantings;
        document.getElementById('totalCares').textContent = data.total_cares;
        document.getElementById('totalHarvests').textContent = data.total_harvests;
        document.getElementById('totalHarvestAmount').textContent = data.total_harvest_amount;
        document.getElementById('totalDisease').textContent = data.total_disease;
        document.getElementById('totalDead').textContent = data.total_dead;
        document.getElementById('totalSalesCount').textContent = data.total_sales;
        document.getElementById('totalSalesAmount').textContent = parseFloat(data.total_sales_amount).toFixed(2);
        document.getElementById('totalSalesDetails').textContent = data.total_sales_details;
    }
}

// ============================================
// TAB NAVIGATION
// ============================================

function openTab(tabName) {
    const contents = document.querySelectorAll('.tab-content');
    contents.forEach(content => content.classList.remove('active'));
    
    const tabs = document.querySelectorAll('.tab-btn');
    tabs.forEach(tab => tab.classList.remove('active'));
    
    document.getElementById(tabName).classList.add('active');
    event.target.classList.add('active');
}

// ============================================
// ALERT NOTIFICATION
// ============================================

function showAlert(message, type = 'info') {
    const alert = document.createElement('div');
    alert.className = `alert alert-${type}`;
    alert.textContent = message;
    alert.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 25px;
        background: ${type === 'success' ? '#28a745' : type === 'error' ? '#dc3545' : '#17a2b8'};
        color: white;
        border-radius: 5px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 9999;
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(alert);
    
    setTimeout(() => {
        alert.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => alert.remove(), 300);
    }, 3000);
}

// ============================================
// SEARCH FUNCTION
// ============================================

function searchTable(searchId, dataArray, renderFunction) {
    const searchInput = document.getElementById(searchId);
    if (!searchInput) return;
    
    searchInput.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase();
        // Simple search - reload and render filtered data
        renderFunction();
    });
}

// ============================================
// INITIALIZE
// ============================================

async function initialize() {
    await loadAllData();
    renderVegetables();
    renderPlantingCycles();
    renderPlantings();
    renderCares();
    renderHarvests();
    renderSales();
    renderSalesDetails();
    updateSummary();
    
    // Initialize search
    searchTable('searchVegetable', vegetables, renderVegetables);
    searchTable('searchCycle', plantingCycles, renderPlantingCycles);
    searchTable('searchPlanting', plantings, renderPlantings);
    searchTable('searchCare', cares, renderCares);
    searchTable('searchHarvest', harvests, renderHarvests);
    searchTable('searchSales', sales, renderSales);
    searchTable('searchSalesDetail', salesDetails, renderSalesDetails);
}

// Start the application
initialize();
