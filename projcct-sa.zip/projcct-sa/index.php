<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ระบบจัดการผัก</title>
    <link rel="stylesheet" href="style.css">
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@300;400;500;600&family=Cormorant+Garamond:wght@400;500;600;700&display=swap"
        rel="stylesheet">

    <style>
        * {
            font-family: 'Bai Jamjuree', 'Cormorant Garamond', serif;
        }
    </style>
</head>

<body>
    <div class="container">
        <header>
            <h1>🌱 ระบบจัดการผัก</h1>
            <p>ระบบบริหารจัดการการปลูกและขายผักครบวงจร</p>
        </header>

        <nav class="nav-tabs">
            <button class="tab-btn active" onclick="openTab('vegetables')">ข้อมูลผัก</button>
            <button class="tab-btn" onclick="openTab('plantingCycles')">รอบการปลูก</button>
            <button class="tab-btn" onclick="openTab('planting')">การปลูก</button>
            <button class="tab-btn" onclick="openTab('care')">การดูแล</button>
            <button class="tab-btn" onclick="openTab('harvest')">การเก็บเกี่ยว</button>
            <button class="tab-btn" onclick="openTab('sales')">การขาย</button>
            <button class="tab-btn" onclick="openTab('salesDetails')">รายละเอียดขาย</button>
            <button class="tab-btn" onclick="openTab('summary')">📊 สรุปภาพรวม</button>
        </nav>

        <!-- ข้อมูลผัก -->
        <div id="vegetables" class="tab-content active">
            <h2 class="section-title">ข้อมูลผัก</h2>

            <div class="search-container">
                <input type="text" id="searchVegetable" class="search-input"
                    placeholder="🔍 ค้นหาผัก (รหัส, ชื่อ, ราคา)...">
            </div>

            <div class="form-container">
                <form id="vegetableForm">
                    <input type="hidden" id="vegEditIndex" value="">
                    <input type="hidden" id="vegId" value="">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="vegIdDisplay">รหัสผัก (สร้างอัตโนมัติ)</label>
                            <input type="text" id="vegIdDisplay" readonly
                                style="background: #e9ecef; cursor: not-allowed;" placeholder="VEG001, VEG002, ...">
                        </div>
                        <div class="form-group">
                            <label for="vegName">ชื่อผัก *</label>
                            <input type="text" id="vegName" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="vegDuration">ระยะเวลาการปลูก (วัน) *</label>
                            <input type="number" id="vegDuration" min="1" required>
                        </div>
                        <div class="form-group">
                            <label for="vegPrice">ราคาขายต่อหน่วย (บาท) *</label>
                            <input type="number" id="vegPrice" min="0" step="0.01" required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary" id="vegSubmitBtn">➕ เพิ่มข้อมูลผัก</button>
                    <button type="button" class="btn btn-cancel" id="vegCancelBtn" style="display:none;"
                        onclick="cancelEditVegetable()">✖ ยกเลิก</button>
                </form>
            </div>
            <div class="data-table-container">
                <table>
                    <thead>
                        <tr>
                            <th>รหัสผัก</th>
                            <th>ชื่อผัก</th>
                            <th>ระยะเวลาการปลูก (วัน)</th>
                            <th>ราคาขายต่อหน่วย (บาท)</th>
                            <th style="text-align: center; width: 180px;">การจัดการ</th>
                        </tr>
                    </thead>
                    <tbody id="vegetableTableBody">
                        <tr class="empty-state">
                            <td colspan="5">
                                <p>ยังไม่มีข้อมูลผัก</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- การปลูก -->
        <div id="planting" class="tab-content">
            <h2 class="section-title">ข้อมูลการปลูก</h2>

            <div class="search-container">
                <input type="text" id="searchPlanting" class="search-input"
                    placeholder="🔍 ค้นหาการปลูก (รหัส, รอบที่, รหัสผัก, แปลง)...">
            </div>

            <div class="form-container">
                <form id="plantingForm">
                    <input type="hidden" id="plantEditIndex" value="">
                    <input type="hidden" id="plantId" value="">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="plantIdDisplay">รหัสการปลูก (สร้างอัตโนมัติ)</label>
                            <input type="text" id="plantIdDisplay" readonly
                                style="background: #e9ecef; cursor: not-allowed;" placeholder="PLT001, PLT002, ...">
                        </div>
                        <div class="form-group">
                            <label for="plantCycleNo">รอบการปลูกที่ *</label>
                            <input type="number" id="plantCycleNo" min="1" required>
                        </div>
                        <div class="form-group">
                            <label for="plantVegId">รหัสผัก *</label>
                            <select id="plantVegId" required>
                                <option value="">-- เลือกผัก --</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="plantQuantity">จำนวนต้น *</label>
                            <input type="number" id="plantQuantity" min="1" required>
                        </div>
                        <div class="form-group">
                            <label for="plantPlot">แปลง *</label>
                            <input type="text" id="plantPlot" required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary" id="plantSubmitBtn">➕ เพิ่มข้อมูลการปลูก</button>
                    <button type="button" class="btn btn-cancel" id="plantCancelBtn" style="display:none;"
                        onclick="cancelEditPlanting()">✖ ยกเลิก</button>
                </form>
            </div>
            <div class="data-table-container">
                <table>
                    <thead>
                        <tr>
                            <th>รหัสการปลูก</th>
                            <th>รอบการปลูกที่</th>
                            <th>รหัสผัก</th>
                            <th>จำนวนต้น</th>
                            <th>แปลง</th>
                            <th style="text-align: center; width: 180px;">การจัดการ</th>
                        </tr>
                    </thead>
                    <tbody id="plantingTableBody">
                        <tr class="empty-state">
                            <td colspan="6">
                                <p>ยังไม่มีข้อมูลการปลูก</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- รอบการปลูก -->
        <div id="plantingCycles" class="tab-content">
            <h2 class="section-title">รอบการปลูก</h2>

            <div class="search-container">
                <input type="text" id="searchCycle" class="search-input"
                    placeholder="🔍 ค้นหารอบการปลูก (รอบที่, วันที่, จำนวน)...">
            </div>

            <div class="form-container">
                <form id="plantingCycleForm">
                    <input type="hidden" id="cycleEditIndex" value="">
                    <input type="hidden" id="cycleNo" value="">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="cycleNoDisplay">รอบการปลูกที่ (สร้างอัตโนมัติ)</label>
                            <input type="text" id="cycleNoDisplay" readonly
                                style="background: #e9ecef; cursor: not-allowed;" placeholder="1, 2, 3, ...">
                        </div>
                        <div class="form-group">
                            <label for="cycleDate">วันที่ปลูก *</label>
                            <input type="date" id="cycleDate" required>
                        </div>
                        <div class="form-group">
                            <label for="cycleAmount">จำนวน (ต้น) *</label>
                            <input type="number" id="cycleAmount" min="1" required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary" id="cycleSubmitBtn">➕ เพิ่มรอบการปลูก</button>
                    <button type="button" class="btn btn-cancel" id="cycleCancelBtn" style="display:none;"
                        onclick="cancelEditCycle()">✖ ยกเลิก</button>
                </form>
            </div>
            <div class="data-table-container">
                <table>
                    <thead>
                        <tr>
                            <th>รอบการปลูกที่</th>
                            <th>วันที่ปลูก</th>
                            <th>จำนวน (ต้น)</th>
                            <th style="text-align: center; width: 180px;">การจัดการ</th>
                        </tr>
                    </thead>
                    <tbody id="plantingCycleTableBody">
                        <tr class="empty-state">
                            <td colspan="4">
                                <p>ยังไม่มีข้อมูลรอบการปลูก</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>


        <!-- การดูแล -->
        <div id="care" class="tab-content">
            <h2 class="section-title">ข้อมูลการดูแล</h2>

            <div class="search-container">
                <input type="text" id="searchCare" class="search-input"
                    placeholder="🔍 ค้นหาการดูแล (รหัส, วันที่, หมายเหตุ)...">
            </div>

            <div class="form-container">
                <form id="careForm">
                    <input type="hidden" id="careEditIndex" value="">
                    <input type="hidden" id="careId" value="">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="careIdDisplay">รหัสดูแล (สร้างอัตโนมัติ)</label>
                            <input type="text" id="careIdDisplay" readonly
                                style="background: #e9ecef; cursor: not-allowed;" placeholder="CARE001, CARE002, ...">
                        </div>
                        <div class="form-group">
                            <label for="carePlantId">รหัสการปลูก *</label>
                            <select id="carePlantId" required>
                                <option value="">-- เลือกการปลูก --</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="careCycle">รอบการดูแล (ครั้งที่) *</label>
                            <input type="number" id="careCycle" min="1" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="careStartDate">วันที่เริ่มการดูแล *</label>
                            <input type="date" id="careStartDate" required>
                        </div>
                        <div class="form-group">
                            <label for="careEndDate">วันที่สิ้นสุดการดูแล *</label>
                            <input type="date" id="careEndDate" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="careNote">หมายเหตุ</label>
                        <textarea id="careNote" rows="3"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary" id="careSubmitBtn">➕ เพิ่มข้อมูลการดูแล</button>
                    <button type="button" class="btn btn-cancel" id="careCancelBtn" style="display:none;"
                        onclick="cancelEditCare()">✖ ยกเลิก</button>
                </form>
            </div>
            <div class="data-table-container">
                <table>
                    <thead>
                        <tr>
                            <th>รหัสดูแล</th>
                            <th>รหัสการปลูก</th>
                            <th>วันที่เริ่ม</th>
                            <th>วันที่สิ้นสุด</th>
                            <th>รอบการดูแล (ครั้งที่)</th>
                            <th>หมายเหตุ</th>
                            <th style="text-align: center; width: 180px;">การจัดการ</th>
                        </tr>
                    </thead>
                    <tbody id="careTableBody">
                        <tr class="empty-state">
                            <td colspan="7">
                                <p>ยังไม่มีข้อมูลการดูแล</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- การเก็บเกี่ยว -->
        <div id="harvest" class="tab-content">
            <h2 class="section-title">ข้อมูลการเก็บเกี่ยว</h2>

            <div class="search-container">
                <input type="text" id="searchHarvest" class="search-input"
                    placeholder="🔍 ค้นหาการเก็บเกี่ยว (รหัส, วันที่, จำนวน)...">
            </div>

            <div class="form-container">
                <form id="harvestForm">
                    <input type="hidden" id="harvestEditIndex" value="">
                    <input type="hidden" id="harvestId" value="">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="harvestIdDisplay">รหัสการเก็บเกี่ยว (สร้างอัตโนมัติ)</label>
                            <input type="text" id="harvestIdDisplay" readonly
                                style="background: #e9ecef; cursor: not-allowed;" placeholder="HRV001, HRV002, ...">
                        </div>
                        <div class="form-group">
                            <label for="harvestPlantId">รหัสการปลูก *</label>
                            <select id="harvestPlantId" required>
                                <option value="">-- เลือกการปลูก --</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="harvestCycleNo">รอบการปลูกที่ *</label>
                            <input type="number" id="harvestCycleNo" min="1" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="harvestDate">วันที่เก็บเกี่ยว *</label>
                            <input type="date" id="harvestDate" required>
                        </div>
                        <div class="form-group">
                            <label for="harvestAmount">จำนวนที่เก็บได้ *</label>
                            <input type="number" id="harvestAmount" min="0" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="harvestDisease">จำนวนที่ติดโรค</label>
                            <input type="number" id="harvestDisease" min="0" value="0">
                        </div>
                        <div class="form-group">
                            <label for="harvestDead">จำนวนที่ตาย</label>
                            <input type="number" id="harvestDead" min="0" value="0">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary" id="harvestSubmitBtn">➕
                        เพิ่มข้อมูลการเก็บเกี่ยว</button>
                    <button type="button" class="btn btn-cancel" id="harvestCancelBtn" style="display:none;"
                        onclick="cancelEditHarvest()">✖ ยกเลิก</button>
                </form>
            </div>
            <div class="data-table-container">
                <table>
                    <thead>
                        <tr>
                            <th>รหัสการเก็บเกี่ยว</th>
                            <th>รหัสการปลูก</th>
                            <th>รอบการปลูกที่</th>
                            <th>วันที่เก็บเกี่ยว</th>
                            <th>จำนวนที่เก็บได้</th>
                            <th>จำนวนที่ติดโรค</th>
                            <th>จำนวนที่ตาย</th>
                            <th style="text-align: center; width: 180px;">การจัดการ</th>
                        </tr>
                    </thead>
                    <tbody id="harvestTableBody">
                        <tr class="empty-state">
                            <td colspan="8">
                                <p>ยังไม่มีข้อมูลการเก็บเกี่ยว</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- การขาย -->
        <div id="sales" class="tab-content">
            <h2 class="section-title">ข้อมูลการขาย</h2>

            <div class="search-container">
                <input type="text" id="searchSales" class="search-input"
                    placeholder="🔍 ค้นหาการขาย (รหัส, วันที่, ยอดขาย)...">
            </div>

            <div class="form-container">
                <form id="salesForm">
                    <input type="hidden" id="saleEditIndex" value="">
                    <input type="hidden" id="saleId" value="">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="saleIdDisplay">รหัสการขาย (สร้างอัตโนมัติ)</label>
                            <input type="text" id="saleIdDisplay" readonly
                                style="background: #e9ecef; cursor: not-allowed;" placeholder="SALE001, SALE002, ...">
                        </div>
                        <div class="form-group">
                            <label for="saleDate">วันที่ขาย *</label>
                            <input type="date" id="saleDate" required>
                        </div>
                        <div class="form-group">
                            <label for="saleAmount">ยอดขาย (บาท) *</label>
                            <input type="number" id="saleAmount" min="0" step="0.01" required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary" id="saleSubmitBtn">➕ เพิ่มข้อมูลการขาย</button>
                    <button type="button" class="btn btn-cancel" id="saleCancelBtn" style="display:none;"
                        onclick="cancelEditSale()">✖ ยกเลิก</button>
                </form>
            </div>
            <div class="data-table-container">
                <table>
                    <thead>
                        <tr>
                            <th>รหัสการขาย</th>
                            <th>วันที่ขาย</th>
                            <th>ยอดขาย (บาท)</th>
                            <th style="text-align: center; width: 180px;">การจัดการ</th>
                        </tr>
                    </thead>
                    <tbody id="salesTableBody">
                        <tr class="empty-state">
                            <td colspan="4">
                                <p>ยังไม่มีข้อมูลการขาย</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- รายละเอียดรายการขาย -->
        <div id="salesDetails" class="tab-content">
            <h2 class="section-title">รายละเอียดรายการขาย</h2>

            <div class="search-container">
                <input type="text" id="searchSalesDetail" class="search-input"
                    placeholder="🔍 ค้นหารายละเอียดการขาย (ลำดับ, รหัส, จำนวน)...">
            </div>

            <div class="form-container">
                <form id="salesDetailForm">
                    <input type="hidden" id="detailEditIndex" value="">
                    <input type="hidden" id="detailOrder" value="">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="detailOrderDisplay">ลำดับ (สร้างอัตโนมัติ)</label>
                            <input type="text" id="detailOrderDisplay" readonly
                                style="background: #e9ecef; cursor: not-allowed;" placeholder="1, 2, 3, ...">
                        </div>
                        <div class="form-group">
                            <label for="detailHarvestId">รหัสการเก็บเกี่ยว *</label>
                            <select id="detailHarvestId" required>
                                <option value="">-- เลือกการเก็บเกี่ยว --</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="detailSaleId">รหัสการขาย *</label>
                            <select id="detailSaleId" required>
                                <option value="">-- เลือกการขาย --</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="detailQuantity">จำนวนการขาย *</label>
                            <input type="number" id="detailQuantity" min="1" required>
                        </div>
                        <div class="form-group">
                            <label for="detailTotal">รวม (บาท) *</label>
                            <input type="number" id="detailTotal" min="0" step="0.01" required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary" id="detailSubmitBtn">➕ เพิ่มรายละเอียดการขาย</button>
                    <button type="button" class="btn btn-cancel" id="detailCancelBtn" style="display:none;"
                        onclick="cancelEditDetail()">✖ ยกเลิก</button>
                </form>
            </div>
            <div class="data-table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ลำดับ</th>
                            <th>รหัสการเก็บเกี่ยว</th>
                            <th>รหัสการขาย</th>
                            <th>จำนวนการขาย</th>
                            <th>รวม (บาท)</th>
                            <th style="text-align: center; width: 180px;">การจัดการ</th>
                        </tr>
                    </thead>
                    <tbody id="salesDetailTableBody">
                        <tr class="empty-state">
                            <td colspan="6">
                                <p>ยังไม่มีรายละเอียดการขาย</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- สรุปภาพรวม -->
        <div id="summary" class="tab-content">
            <h2 class="section-title">📊 สรุปภาพรวมระบบ</h2>

            <div class="stats-grid">
                <div class="stat-card stat-card-green">
                    <h3>ข้อมูลผักทั้งหมด</h3>
                    <div class="stat-value" id="totalVegetables">0</div>
                    <div class="stat-label">ชนิด</div>
                </div>
                <div class="stat-card stat-card-blue">
                    <h3>รอบการปลูกทั้งหมด</h3>
                    <div class="stat-value" id="totalCycles">0</div>
                    <div class="stat-label">รอบ</div>
                </div>
                <div class="stat-card stat-card-purple">
                    <h3>การปลูกทั้งหมด</h3>
                    <div class="stat-value" id="totalPlantings">0</div>
                    <div class="stat-label">ครั้ง</div>
                </div>
                <div class="stat-card stat-card-orange">
                    <h3>การดูแลทั้งหมด</h3>
                    <div class="stat-value" id="totalCares">0</div>
                    <div class="stat-label">ครั้ง</div>
                </div>
            </div>

            <div class="summary-section">
                <h3 class="summary-title">🌾 สรุปการเก็บเกี่ยว</h3>
                <div class="summary-cards">
                    <div class="summary-card">
                        <div class="summary-label">จำนวนครั้งทั้งหมด</div>
                        <div class="summary-value" id="totalHarvests">0</div>
                    </div>
                    <div class="summary-card">
                        <div class="summary-label">ผลผลิตที่เก็บได้</div>
                        <div class="summary-value" id="totalHarvestAmount">0</div>
                    </div>
                    <div class="summary-card">
                        <div class="summary-label">ติดโรคทั้งหมด</div>
                        <div class="summary-value text-warning" id="totalDisease">0</div>
                    </div>
                    <div class="summary-card">
                        <div class="summary-label">ตายทั้งหมด</div>
                        <div class="summary-value text-danger" id="totalDead">0</div>
                    </div>
                </div>
            </div>

            <div class="summary-section">
                <h3 class="summary-title">💰 สรุปการขาย</h3>
                <div class="summary-cards">
                    <div class="summary-card">
                        <div class="summary-label">จำนวนการขายทั้งหมด</div>
                        <div class="summary-value" id="totalSalesCount">0</div>
                    </div>
                    <div class="summary-card">
                        <div class="summary-label">ยอดขายรวม</div>
                        <div class="summary-value text-success" id="totalSalesAmount">0.00</div>
                        <div class="summary-unit">บาท</div>
                    </div>
                    <div class="summary-card">
                        <div class="summary-label">รายการขายทั้งหมด</div>
                        <div class="summary-value" id="totalSalesDetails">0</div>
                    </div>
                </div>
            </div>

            <div class="summary-section">
                <h3 class="summary-title">📋 กิจกรรมล่าสุด</h3>
                <div class="recent-activities">
                    <div class="activity-item">
                        <span class="activity-icon">🌾</span>
                        <div class="activity-content">
                            <div class="activity-title">การเก็บเกี่ยวล่าสุด</div>
                            <div class="activity-text" id="latestHarvestText">ยังไม่มีข้อมูล</div>
                        </div>
                    </div>
                    <div class="activity-item">
                        <span class="activity-icon">💰</span>
                        <div class="activity-content">
                            <div class="activity-title">การขายล่าสุด</div>
                            <div class="activity-text" id="latestSaleText">ยังไม่มีข้อมูล</div>
                        </div>
                    </div>
                    <div class="activity-item">
                        <span class="activity-icon">🌱</span>
                        <div class="activity-content">
                            <div class="activity-title">การดูแลล่าสุด</div>
                            <div class="activity-text" id="latestCareText">ยังไม่มีข้อมูล</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="app-database.js"></script>
</body>

</html>