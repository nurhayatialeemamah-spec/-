-- ============================================
-- ระบบจัดการผัก (Vegetable Management System)
-- ไฟล์ SQL สำหรับสร้างฐานข้อมูลและข้อมูลตัวอย่าง
-- ============================================

-- สร้างฐานข้อมูล
DROP DATABASE IF EXISTS vegetable_management;
CREATE DATABASE vegetable_management CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE vegetable_management;

-- ============================================
-- ตาราง: ข้อมูลผัก (vegetables)
-- ============================================
CREATE TABLE vegetables (
    veg_id VARCHAR(10) PRIMARY KEY,
    veg_name VARCHAR(100) NOT NULL,
    duration INT NOT NULL COMMENT 'ระยะเวลาการปลูก (วัน)',
    price_per_unit DECIMAL(10,2) NOT NULL COMMENT 'ราคาขายต่อหน่วย (บาท)',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='ข้อมูลผัก';

-- ============================================
-- ตาราง: รอบการปลูก (planting_cycles)
-- ============================================
CREATE TABLE planting_cycles (
    cycle_no INT PRIMARY KEY AUTO_INCREMENT,
    planting_date DATE NOT NULL COMMENT 'วันที่ปลูก',
    total_plants INT NOT NULL COMMENT 'จำนวนต้นทั้งหมด',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='รอบการปลูก';

-- ============================================
-- ตาราง: ข้อมูลการปลูก (plantings)
-- ============================================
CREATE TABLE plantings (
    plant_id VARCHAR(10) PRIMARY KEY,
    cycle_no INT NOT NULL,
    veg_id VARCHAR(10) NOT NULL,
    quantity INT NOT NULL COMMENT 'จำนวนต้น',
    plot_name VARCHAR(50) NOT NULL COMMENT 'แปลง',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (cycle_no) REFERENCES planting_cycles(cycle_no) ON DELETE CASCADE,
    FOREIGN KEY (veg_id) REFERENCES vegetables(veg_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='ข้อมูลการปลูก';

-- ============================================
-- ตาราง: ข้อมูลการดูแล (care_records)
-- ============================================
CREATE TABLE care_records (
    care_id VARCHAR(10) PRIMARY KEY,
    plant_id VARCHAR(10) NOT NULL,
    start_date DATE NOT NULL COMMENT 'วันที่เริ่มการดูแล',
    end_date DATE NOT NULL COMMENT 'วันที่สิ้นสุดการดูแล',
    care_round INT NOT NULL COMMENT 'รอบการดูแล (ครั้งที่)',
    notes TEXT COMMENT 'หมายเหตุ',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (plant_id) REFERENCES plantings(plant_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='ข้อมูลการดูแล';

-- ============================================
-- ตาราง: ข้อมูลการเก็บเกี่ยว (harvests)
-- ============================================
CREATE TABLE harvests (
    harvest_id VARCHAR(10) PRIMARY KEY,
    plant_id VARCHAR(10) NOT NULL,
    cycle_no INT NOT NULL,
    harvest_date DATE NOT NULL COMMENT 'วันที่เก็บเกี่ยว',
    harvested_amount INT NOT NULL COMMENT 'จำนวนที่เก็บได้',
    diseased_amount INT DEFAULT 0 COMMENT 'จำนวนที่ติดโรค',
    dead_amount INT DEFAULT 0 COMMENT 'จำนวนที่ตาย',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (plant_id) REFERENCES plantings(plant_id) ON DELETE CASCADE,
    FOREIGN KEY (cycle_no) REFERENCES planting_cycles(cycle_no) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='ข้อมูลการเก็บเกี่ยว';

-- ============================================
-- ตาราง: ข้อมูลการขาย (sales)
-- ============================================
CREATE TABLE sales (
    sale_id VARCHAR(10) PRIMARY KEY,
    sale_date DATE NOT NULL COMMENT 'วันที่ขาย',
    total_amount DECIMAL(10,2) NOT NULL COMMENT 'ยอดขาย',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='ข้อมูลการขาย';

-- ============================================
-- ตาราง: รายละเอียดรายการขาย (sales_details)
-- ============================================
CREATE TABLE sales_details (
    detail_id INT PRIMARY KEY AUTO_INCREMENT,
    harvest_id VARCHAR(10) NOT NULL,
    sale_id VARCHAR(10) NOT NULL,
    quantity INT NOT NULL COMMENT 'จำนวนการขาย',
    subtotal DECIMAL(10,2) NOT NULL COMMENT 'รวม',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (harvest_id) REFERENCES harvests(harvest_id) ON DELETE CASCADE,
    FOREIGN KEY (sale_id) REFERENCES sales(sale_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='รายละเอียดรายการขาย';

-- ============================================
-- เพิ่มข้อมูลผัก (30 รายการ)
-- ============================================
INSERT INTO vegetables (veg_id, veg_name, duration, price_per_unit) VALUES
('VEG001', 'ผักกาดหอม', 30, 25.00),
('VEG002', 'คะน้า', 45, 30.00),
('VEG003', 'ผักบุ้ง', 25, 20.00),
('VEG004', 'กวางตุ้ง', 35, 28.00),
('VEG005', 'ผักชี', 40, 35.00),
('VEG006', 'ผักกาดขาว', 50, 22.00),
('VEG007', 'ผักกาดเขียว', 35, 24.00),
('VEG008', 'ตำลึง', 30, 26.00),
('VEG009', 'ผักบุ้งจีน', 28, 23.00),
('VEG010', 'ผักชีฝรั่ง', 45, 38.00),
('VEG011', 'ผักกาดหัว', 55, 32.00),
('VEG012', 'คะน้าจีน', 40, 29.00),
('VEG013', 'ผักโขม', 30, 21.00),
('VEG014', 'ผักกวางตุ้งญี่ปุ่น', 38, 33.00),
('VEG015', 'ผักกาดแก้ว', 32, 27.00),
('VEG016', 'ผักสลัด', 35, 45.00),
('VEG017', 'ผักกาดหอมแดง', 33, 28.00),
('VEG018', 'ผักบุ้งเหลือง', 27, 22.00),
('VEG019', 'เรดโอ๊ค', 40, 50.00),
('VEG020', 'กรีนโอ๊ค', 40, 48.00),
('VEG021', 'บัตเตอร์เฮด', 38, 42.00),
('VEG022', 'ฟริลลิส', 35, 46.00),
('VEG023', 'คอสเลตุช', 42, 44.00),
('VEG024', 'ผักกาดหอมม้วน', 45, 36.00),
('VEG025', 'ผักบุ้งต้นอ่อน', 20, 18.00),
('VEG026', 'ผักกาดเด็ก', 25, 24.00),
('VEG027', 'ผักชีลาว', 38, 32.00),
('VEG028', 'คะน้าฮ่องกง', 43, 31.00),
('VEG029', 'ผักกาดหอมสีม่วง', 36, 52.00),
('VEG030', 'ผักบุ้งไฮโดรโปนิกส์', 30, 40.00);

-- ============================================
-- เพิ่มรอบการปลูก (30 รายการ)
-- ============================================
INSERT INTO planting_cycles (planting_date, total_plants) VALUES
('2024-01-05', 500),
('2024-01-15', 600),
('2024-01-25', 550),
('2024-02-05', 700),
('2024-02-15', 650),
('2024-02-25', 580),
('2024-03-05', 620),
('2024-03-15', 590),
('2024-03-25', 610),
('2024-04-05', 640),
('2024-04-15', 670),
('2024-04-25', 630),
('2024-05-05', 660),
('2024-05-15', 680),
('2024-05-25', 600),
('2024-06-05', 720),
('2024-06-15', 690),
('2024-06-25', 710),
('2024-07-05', 650),
('2024-07-15', 630),
('2024-07-25', 670),
('2024-08-05', 700),
('2024-08-15', 680),
('2024-08-25', 640),
('2024-09-05', 690),
('2024-09-15', 710),
('2024-09-25', 660),
('2024-10-05', 720),
('2024-10-15', 700),
('2024-10-25', 680);

-- ============================================
-- เพิ่มข้อมูลการปลูก (30 รายการ)
-- ============================================
INSERT INTO plantings (plant_id, cycle_no, veg_id, quantity, plot_name) VALUES
('PLT001', 1, 'VEG001', 100, 'แปลง A1'),
('PLT002', 1, 'VEG002', 120, 'แปลง A2'),
('PLT003', 2, 'VEG003', 150, 'แปลง B1'),
('PLT004', 2, 'VEG004', 130, 'แปลง B2'),
('PLT005', 3, 'VEG005', 140, 'แปลง C1'),
('PLT006', 3, 'VEG006', 110, 'แปลง C2'),
('PLT007', 4, 'VEG007', 160, 'แปลง D1'),
('PLT008', 4, 'VEG008', 135, 'แปลง D2'),
('PLT009', 5, 'VEG009', 145, 'แปลง E1'),
('PLT010', 5, 'VEG010', 125, 'แปลง E2'),
('PLT011', 6, 'VEG011', 155, 'แปลง F1'),
('PLT012', 6, 'VEG012', 140, 'แปลง F2'),
('PLT013', 7, 'VEG013', 130, 'แปลง G1'),
('PLT014', 7, 'VEG014', 150, 'แปลง G2'),
('PLT015', 8, 'VEG015', 145, 'แปลง H1'),
('PLT016', 8, 'VEG016', 120, 'แปลง H2'),
('PLT017', 9, 'VEG017', 135, 'แปลง I1'),
('PLT018', 9, 'VEG018', 155, 'แปลง I2'),
('PLT019', 10, 'VEG019', 140, 'แปลง J1'),
('PLT020', 10, 'VEG020', 160, 'แปลง J2'),
('PLT021', 11, 'VEG021', 150, 'แปลง K1'),
('PLT022', 11, 'VEG022', 145, 'แปลง K2'),
('PLT023', 12, 'VEG023', 130, 'แปลง L1'),
('PLT024', 12, 'VEG024', 125, 'แปลง L2'),
('PLT025', 13, 'VEG025', 170, 'แปลง M1'),
('PLT026', 13, 'VEG026', 135, 'แปลง M2'),
('PLT027', 14, 'VEG027', 155, 'แปลง N1'),
('PLT028', 14, 'VEG028', 140, 'แปลง N2'),
('PLT029', 15, 'VEG029', 145, 'แปลง O1'),
('PLT030', 15, 'VEG030', 160, 'แปลง O2');

-- ============================================
-- เพิ่มข้อมูลการดูแล (30 รายการ)
-- ============================================
INSERT INTO care_records (care_id, plant_id, start_date, end_date, care_round, notes) VALUES
('CARE001', 'PLT001', '2024-01-10', '2024-01-15', 1, 'รดน้ำ ใส่ปุ๋ย กำจัดวัชพืช'),
('CARE002', 'PLT001', '2024-01-16', '2024-01-20', 2, 'ฉีดพ่นกำจัดแมลง ตรวจสอบโรค'),
('CARE003', 'PLT002', '2024-01-18', '2024-01-23', 1, 'รดน้ำเช้า-เย็น ใส่ปุ๋ยอินทรีย์'),
('CARE004', 'PLT003', '2024-01-28', '2024-02-02', 1, 'ตัดแต่งใบ ถอนแซง'),
('CARE005', 'PLT004', '2024-02-08', '2024-02-13', 1, 'รดน้ำ ใส่ปุ๋ยสูตร 15-15-15'),
('CARE006', 'PLT005', '2024-02-20', '2024-02-25', 1, 'กำจัดหนอนใบ พ่นปุ๋ยใบ'),
('CARE007', 'PLT006', '2024-02-28', '2024-03-05', 1, 'รดน้ำ คลุมดิน ป้องกันโรค'),
('CARE008', 'PLT007', '2024-03-08', '2024-03-13', 1, 'ใส่ปุ๋ยคอก ตัดแต่งกิ่ง'),
('CARE009', 'PLT008', '2024-03-18', '2024-03-23', 1, 'รดน้ำ พรวนดิน ถอนวัชพืช'),
('CARE010', 'PLT009', '2024-03-28', '2024-04-02', 1, 'ใส่ปุ๋ยเคมี ตรวจสอบศัตรูพืช'),
('CARE011', 'PLT010', '2024-04-08', '2024-04-13', 1, 'รดน้ำเช้า-เย็น พ่นปุ๋ยไมโคไรซ่า'),
('CARE012', 'PLT011', '2024-04-18', '2024-04-23', 1, 'กำจัดเพลี้ยอ่อน คลุมพลาสติก'),
('CARE013', 'PLT012', '2024-04-28', '2024-05-03', 1, 'รดน้ำ ใส่ปุ๋ยหมัก'),
('CARE014', 'PLT013', '2024-05-08', '2024-05-13', 1, 'ตัดใบเหลือง พ่นสารป้องกันโรค'),
('CARE015', 'PLT014', '2024-05-18', '2024-05-23', 1, 'รดน้ำ คลุมฟาง ถอนแซง'),
('CARE016', 'PLT015', '2024-05-28', '2024-06-02', 1, 'ใส่ปุ๋ยแคลเซียม กำจัดหอยทาก'),
('CARE017', 'PLT016', '2024-06-08', '2024-06-13', 1, 'รดน้ำเช้า-เย็น ป้องกันโรคราน้ำค้าง'),
('CARE018', 'PLT017', '2024-06-18', '2024-06-23', 1, 'ตัดแต่งใบ ใส่ปุ๋ยอินทรีย์'),
('CARE019', 'PLT018', '2024-06-28', '2024-07-03', 1, 'รดน้ำ กำจัดหนอนเจาะลำต้น'),
('CARE020', 'PLT019', '2024-07-08', '2024-07-13', 1, 'พ่นปุ๋ยใบ ถอนวัชพืช'),
('CARE021', 'PLT020', '2024-07-18', '2024-07-23', 1, 'รดน้ำ ใส่ปุ๋ยไนโตรเจน'),
('CARE022', 'PLT021', '2024-07-28', '2024-08-02', 1, 'คลุมดิน ป้องกันโรครากเน่า'),
('CARE023', 'PLT022', '2024-08-08', '2024-08-13', 1, 'รดน้ำเช้า-เย็น ตัดยอดอ่อน'),
('CARE024', 'PLT023', '2024-08-18', '2024-08-23', 1, 'ใส่ปุ๋ยฟอสฟอรัส กำจัดเพลี้ย'),
('CARE025', 'PLT024', '2024-08-28', '2024-09-02', 1, 'รดน้ำ พ่นสารชีวภาพ'),
('CARE026', 'PLT025', '2024-09-08', '2024-09-13', 1, 'ถอนแซง ใส่ปุ๋ยคอก'),
('CARE027', 'PLT026', '2024-09-18', '2024-09-23', 1, 'รดน้ำ ตรวจสอบโรคใบจุด'),
('CARE028', 'PLT027', '2024-09-28', '2024-10-03', 1, 'กำจัดหนอนใบ คลุมฟาง'),
('CARE029', 'PLT028', '2024-10-08', '2024-10-13', 1, 'รดน้ำเช้า-เย็น ใส่ปุ๋ย 16-16-16'),
('CARE030', 'PLT029', '2024-10-18', '2024-10-23', 1, 'พรวนดิน พ่นสารกำจัดหอยทาก');

-- ============================================
-- เพิ่มข้อมูลการเก็บเกี่ยว (30 รายการ)
-- ============================================
INSERT INTO harvests (harvest_id, plant_id, cycle_no, harvest_date, harvested_amount, diseased_amount, dead_amount) VALUES
('HRV001', 'PLT001', 1, '2024-02-04', 95, 3, 2),
('HRV002', 'PLT002', 1, '2024-03-01', 115, 2, 3),
('HRV003', 'PLT003', 2, '2024-02-19', 145, 4, 1),
('HRV004', 'PLT004', 2, '2024-03-11', 125, 3, 2),
('HRV005', 'PLT005', 3, '2024-03-06', 135, 2, 3),
('HRV006', 'PLT006', 3, '2024-04-14', 105, 3, 2),
('HRV007', 'PLT007', 4, '2024-03-21', 155, 4, 1),
('HRV008', 'PLT008', 4, '2024-04-09', 130, 2, 3),
('HRV009', 'PLT009', 5, '2024-03-31', 140, 3, 2),
('HRV010', 'PLT010', 5, '2024-05-04', 120, 3, 2),
('HRV011', 'PLT011', 6, '2024-04-21', 150, 2, 3),
('HRV012', 'PLT012', 6, '2024-05-11', 135, 4, 1),
('HRV013', 'PLT013', 7, '2024-04-09', 125, 3, 2),
('HRV014', 'PLT014', 7, '2024-05-19', 145, 2, 3),
('HRV015', 'PLT015', 8, '2024-04-29', 140, 3, 2),
('HRV016', 'PLT016', 8, '2024-05-29', 115, 3, 2),
('HRV017', 'PLT017', 9, '2024-05-09', 130, 2, 3),
('HRV018', 'PLT018', 9, '2024-06-02', 150, 4, 1),
('HRV019', 'PLT019', 10, '2024-05-25', 135, 3, 2),
('HRV020', 'PLT020', 10, '2024-06-19', 155, 2, 3),
('HRV021', 'PLT021', 11, '2024-06-09', 145, 3, 2),
('HRV022', 'PLT022', 11, '2024-06-29', 140, 2, 3),
('HRV023', 'PLT023', 12, '2024-06-16', 125, 3, 2),
('HRV024', 'PLT024', 12, '2024-07-09', 120, 4, 1),
('HRV025', 'PLT025', 13, '2024-05-30', 165, 3, 2),
('HRV026', 'PLT026', 13, '2024-06-14', 130, 2, 3),
('HRV027', 'PLT027', 14, '2024-07-04', 150, 3, 2),
('HRV028', 'PLT028', 14, '2024-07-28', 135, 2, 3),
('HRV029', 'PLT029', 15, '2024-07-16', 140, 3, 2),
('HRV030', 'PLT030', 15, '2024-08-09', 155, 2, 3);

-- ============================================
-- เพิ่มข้อมูลการขาย (30 รายการ)
-- ============================================
INSERT INTO sales (sale_id, sale_date, total_amount) VALUES
('SALE001', '2024-02-05', 2375.00),
('SALE002', '2024-03-02', 3450.00),
('SALE003', '2024-02-20', 2900.00),
('SALE004', '2024-03-12', 3500.00),
('SALE005', '2024-03-07', 4725.00),
('SALE006', '2024-04-15', 2310.00),
('SALE007', '2024-03-22', 4030.00),
('SALE008', '2024-04-10', 3380.00),
('SALE009', '2024-04-01', 3220.00),
('SALE010', '2024-05-05', 4560.00),
('SALE011', '2024-04-22', 4800.00),
('SALE012', '2024-05-12', 3915.00),
('SALE013', '2024-04-10', 2625.00),
('SALE014', '2024-05-20', 4785.00),
('SALE015', '2024-04-30', 3780.00),
('SALE016', '2024-05-30', 5175.00),
('SALE017', '2024-05-10', 3640.00),
('SALE018', '2024-06-03', 3000.00),
('SALE019', '2024-05-26', 6750.00),
('SALE020', '2024-06-20', 7440.00),
('SALE021', '2024-06-10', 6090.00),
('SALE022', '2024-06-30', 6440.00),
('SALE023', '2024-06-17', 5500.00),
('SALE024', '2024-07-10', 5040.00),
('SALE025', '2024-05-31', 2970.00),
('SALE026', '2024-06-15', 3120.00),
('SALE027', '2024-07-05', 4800.00),
('SALE028', '2024-07-29', 4185.00),
('SALE029', '2024-07-17', 7280.00),
('SALE030', '2024-08-10', 6200.00);

-- ============================================
-- เพิ่มรายละเอียดรายการขาย (30 รายการ)
-- ============================================
INSERT INTO sales_details (harvest_id, sale_id, quantity, subtotal) VALUES
('HRV001', 'SALE001', 95, 2375.00),
('HRV002', 'SALE002', 115, 3450.00),
('HRV003', 'SALE003', 145, 2900.00),
('HRV004', 'SALE004', 125, 3500.00),
('HRV005', 'SALE005', 135, 4725.00),
('HRV006', 'SALE006', 105, 2310.00),
('HRV007', 'SALE007', 155, 4030.00),
('HRV008', 'SALE008', 130, 3380.00),
('HRV009', 'SALE009', 140, 3220.00),
('HRV010', 'SALE010', 120, 4560.00),
('HRV011', 'SALE011', 150, 4800.00),
('HRV012', 'SALE012', 135, 3915.00),
('HRV013', 'SALE013', 125, 2625.00),
('HRV014', 'SALE014', 145, 4785.00),
('HRV015', 'SALE015', 140, 3780.00),
('HRV016', 'SALE016', 115, 5175.00),
('HRV017', 'SALE017', 130, 3640.00),
('HRV018', 'SALE018', 150, 3000.00),
('HRV019', 'SALE019', 135, 6750.00),
('HRV020', 'SALE020', 155, 7440.00),
('HRV021', 'SALE021', 145, 6090.00),
('HRV022', 'SALE022', 140, 6440.00),
('HRV023', 'SALE023', 125, 5500.00),
('HRV024', 'SALE024', 120, 5040.00),
('HRV025', 'SALE025', 165, 2970.00),
('HRV026', 'SALE026', 130, 3120.00),
('HRV027', 'SALE027', 150, 4800.00),
('HRV028', 'SALE028', 135, 4185.00),
('HRV029', 'SALE029', 140, 7280.00),
('HRV030', 'SALE030', 155, 6200.00);

-- ============================================
-- สร้าง INDEX เพื่อเพิ่มประสิทธิภาพ
-- ============================================
CREATE INDEX idx_planting_cycle ON plantings(cycle_no);
CREATE INDEX idx_planting_veg ON plantings(veg_id);
CREATE INDEX idx_care_plant ON care_records(plant_id);
CREATE INDEX idx_harvest_plant ON harvests(plant_id);
CREATE INDEX idx_harvest_cycle ON harvests(cycle_no);
CREATE INDEX idx_harvest_date ON harvests(harvest_date);
CREATE INDEX idx_sale_date ON sales(sale_date);
CREATE INDEX idx_detail_harvest ON sales_details(harvest_id);
CREATE INDEX idx_detail_sale ON sales_details(sale_id);

-- ============================================
-- VIEW: สรุปภาพรวม
-- ============================================
CREATE VIEW v_summary AS
SELECT 
    (SELECT COUNT(*) FROM vegetables) AS total_vegetables,
    (SELECT COUNT(*) FROM planting_cycles) AS total_cycles,
    (SELECT COUNT(*) FROM plantings) AS total_plantings,
    (SELECT COUNT(*) FROM care_records) AS total_cares,
    (SELECT COUNT(*) FROM harvests) AS total_harvests,
    (SELECT SUM(harvested_amount) FROM harvests) AS total_harvested,
    (SELECT SUM(diseased_amount) FROM harvests) AS total_diseased,
    (SELECT SUM(dead_amount) FROM harvests) AS total_dead,
    (SELECT COUNT(*) FROM sales) AS total_sales,
    (SELECT SUM(total_amount) FROM sales) AS total_revenue,
    (SELECT COUNT(*) FROM sales_details) AS total_sale_items;

-- ============================================
-- VIEW: รายละเอียดการปลูกพร้อมชื่อผัก
-- ============================================
CREATE VIEW v_planting_details AS
SELECT 
    p.plant_id,
    p.cycle_no,
    pc.planting_date,
    v.veg_id,
    v.veg_name,
    v.duration,
    p.quantity,
    p.plot_name,
    p.created_at
FROM plantings p
JOIN vegetables v ON p.veg_id = v.veg_id
JOIN planting_cycles pc ON p.cycle_no = pc.cycle_no
ORDER BY p.plant_id;

-- ============================================
-- VIEW: รายละเอียดการเก็บเกี่ยวพร้อมข้อมูลผัก
-- ============================================
CREATE VIEW v_harvest_details AS
SELECT 
    h.harvest_id,
    h.plant_id,
    p.plot_name,
    v.veg_name,
    h.harvest_date,
    h.harvested_amount,
    h.diseased_amount,
    h.dead_amount,
    (h.harvested_amount + h.diseased_amount + h.dead_amount) AS total_plants,
    ROUND((h.harvested_amount * 100.0) / (h.harvested_amount + h.diseased_amount + h.dead_amount), 2) AS success_rate
FROM harvests h
JOIN plantings p ON h.plant_id = p.plant_id
JOIN vegetables v ON p.veg_id = v.veg_id
ORDER BY h.harvest_date DESC;

-- ============================================
-- VIEW: รายละเอียดการขายพร้อมข้อมูลผัก
-- ============================================
CREATE VIEW v_sales_report AS
SELECT 
    s.sale_id,
    s.sale_date,
    sd.harvest_id,
    v.veg_name,
    sd.quantity,
    v.price_per_unit,
    sd.subtotal,
    s.total_amount
FROM sales s
JOIN sales_details sd ON s.sale_id = sd.sale_id
JOIN harvests h ON sd.harvest_id = h.harvest_id
JOIN plantings p ON h.plant_id = p.plant_id
JOIN vegetables v ON p.veg_id = v.veg_id
ORDER BY s.sale_date DESC;

-- ============================================
-- STORED PROCEDURE: เพิ่มข้อมูลการปลูก
-- ============================================
DELIMITER //
CREATE PROCEDURE sp_add_planting(
    IN p_cycle_no INT,
    IN p_veg_id VARCHAR(10),
    IN p_quantity INT,
    IN p_plot_name VARCHAR(50)
)
BEGIN
    DECLARE new_plant_id VARCHAR(10);
    DECLARE max_num INT;
    
    -- สร้าง plant_id อัตโนมัติ
    SELECT COALESCE(MAX(CAST(SUBSTRING(plant_id, 4) AS UNSIGNED)), 0) INTO max_num
    FROM plantings;
    
    SET new_plant_id = CONCAT('PLT', LPAD(max_num + 1, 3, '0'));
    
    -- เพิ่มข้อมูล
    INSERT INTO plantings (plant_id, cycle_no, veg_id, quantity, plot_name)
    VALUES (new_plant_id, p_cycle_no, p_veg_id, p_quantity, p_plot_name);
    
    SELECT new_plant_id AS plant_id;
END //
DELIMITER ;

-- ============================================
-- STORED PROCEDURE: เพิ่มข้อมูลการเก็บเกี่ยว
-- ============================================
DELIMITER //
CREATE PROCEDURE sp_add_harvest(
    IN p_plant_id VARCHAR(10),
    IN p_cycle_no INT,
    IN p_harvest_date DATE,
    IN p_harvested_amount INT,
    IN p_diseased_amount INT,
    IN p_dead_amount INT
)
BEGIN
    DECLARE new_harvest_id VARCHAR(10);
    DECLARE max_num INT;
    
    -- สร้าง harvest_id อัตโนมัติ
    SELECT COALESCE(MAX(CAST(SUBSTRING(harvest_id, 4) AS UNSIGNED)), 0) INTO max_num
    FROM harvests;
    
    SET new_harvest_id = CONCAT('HRV', LPAD(max_num + 1, 3, '0'));
    
    -- เพิ่มข้อมูล
    INSERT INTO harvests (harvest_id, plant_id, cycle_no, harvest_date, harvested_amount, diseased_amount, dead_amount)
    VALUES (new_harvest_id, p_plant_id, p_cycle_no, p_harvest_date, p_harvested_amount, p_diseased_amount, p_dead_amount);
    
    SELECT new_harvest_id AS harvest_id;
END //
DELIMITER ;

-- ============================================
-- STORED PROCEDURE: เพิ่มข้อมูลการขาย
-- ============================================
DELIMITER //
CREATE PROCEDURE sp_add_sale(
    IN p_sale_date DATE,
    IN p_total_amount DECIMAL(10,2)
)
BEGIN
    DECLARE new_sale_id VARCHAR(10);
    DECLARE max_num INT;
    
    -- สร้าง sale_id อัตโนมัติ
    SELECT COALESCE(MAX(CAST(SUBSTRING(sale_id, 5) AS UNSIGNED)), 0) INTO max_num
    FROM sales;
    
    SET new_sale_id = CONCAT('SALE', LPAD(max_num + 1, 3, '0'));
    
    -- เพิ่มข้อมูล
    INSERT INTO sales (sale_id, sale_date, total_amount)
    VALUES (new_sale_id, p_sale_date, p_total_amount);
    
    SELECT new_sale_id AS sale_id;
END //
DELIMITER ;

-- ============================================
-- แสดงสรุปข้อมูล
-- ============================================
SELECT '✅ สร้างฐานข้อมูลและข้อมูลตัวอย่างสำเร็จ!' AS status;
SELECT * FROM v_summary;

SELECT 'ข้อมูลทั้งหมด:' AS info;
SELECT 'ผัก: 30 ชนิด' AS detail
UNION ALL SELECT 'รอบการปลูก: 30 รอบ'
UNION ALL SELECT 'การปลูก: 30 ครั้ง'
UNION ALL SELECT 'การดูแล: 30 ครั้ง'
UNION ALL SELECT 'การเก็บเกี่ยว: 30 ครั้ง'
UNION ALL SELECT 'การขาย: 30 ครั้ง'
UNION ALL SELECT 'รายละเอียดการขาย: 30 รายการ';
