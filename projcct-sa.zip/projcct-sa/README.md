# 🌱 ระบบจัดการผัก (Vegetable Management System)

## 📌 ภาพรวม

ระบบจัดการผักแบบครบวงจร สำหรับบริหารจัดการตั้งแต่การปลูก การดูแล การเก็บเกี่ยว ไปจนถึงการขาย พร้อมระบบรายงานและสรุปผลแบบเรียลไทม์

### ✨ จุดเด่น
- ✅ **ระบบ Auto ID** - รหัสสร้างอัตโนมัติทั้งหมด
- ✅ **เชื่อมต่อฐานข้อมูล** - ใช้ MySQL/MariaDB
- ✅ **ข้อมูลตัวอย่าง** - มีข้อมูลพร้อมใช้ 30 รายการ
- ✅ **ข้อมูลเชื่อมโยง** - Foreign Keys ครบถ้วน
- ✅ **UI สวยงาม** - ใช้งานง่าย รองรับภาษาไทย
- ✅ **RESTful API** - แยก Backend/Frontend ชัดเจน
- ✅ **รายงานเรียลไทม์** - สรุปผลทันที

---

## 📦 ไฟล์ในแพ็กเกจ

```
vegetable-system/
│
├── 📄 create.php              ← สร้างฐานข้อมูล + ข้อมูลตัวอย่าง
├── 📄 vegetable_database.sql  ← ไฟล์ SQL (ทางเลือก)
│
├── 🌐 index.php               ← หน้าหลัก (Frontend)
├── ⚙️ config.php              ← การเชื่อมต่อฐานข้อมูล
├── 🔌 api.php                 ← API Backend
├── 💻 app-database.js         ← JavaScript สำหรับเรียก API
│
├── 📚 DATABASE_GUIDE.md       ← คู่มือฐานข้อมูล
├── 📖 INSTALL_GUIDE.md        ← คู่มือติดตั้ง
└── 📝 README.md               ← ไฟล์นี้
```

---

## 🚀 เริ่มต้นใช้งานเร็ว (Quick Start)

### **1. ติดตั้งฐานข้อมูล**
```bash
# วางไฟล์ทั้งหมดใน htdocs
C:\xampp\htdocs\vegetable-system\

# เปิดเบราว์เซอร์
http://localhost/vegetable-system/create.php

# รอสักครู่... ✅ เสร็จแล้ว!
```

### **2. เข้าใช้งานระบบ**
```bash
http://localhost/vegetable-system/
```

### **3. เริ่มใช้งาน!** 🎉

---

## 💻 ความต้องการของระบบ

| ซอฟต์แวร์ | เวอร์ชันขั้นต่ำ | แนะนำ |
|-----------|----------------|-------|
| PHP | 7.4+ | 8.0+ |
| MySQL/MariaDB | 5.7+ | 8.0+ |
| Web Server | Apache/Nginx | Apache 2.4+ |
| Browser | Chrome 90+ | Chrome/Firefox ล่าสุด |

**แพ็กเกจแนะนำ:** XAMPP, WAMP, MAMP, LAMP

---

## 📊 ฟีเจอร์หลัก

### **1. จัดการข้อมูลผัก**
- 🌱 เพิ่ม/แก้ไข/ลบ ข้อมูลผัก
- 📝 ระบุระยะเวลาการปลูกและราคา
- 🔍 ค้นหาข้อมูล

### **2. รอบการปลูก**
- 🔄 บันทึกรอบการปลูกพร้อมวันที่
- 📈 ติดตามจำนวนต้นแต่ละรอบ

### **3. การปลูก**
- 🌾 บันทึกการปลูกแต่ละแปลง
- 🔗 เชื่อมโยงกับผักและรอบการปลูก
- 📍 ระบุตำแหน่งแปลง

### **4. การดูแล**
- 💚 บันทึกการดูแลแต่ละครั้ง
- 📅 ระบุช่วงเวลา
- 📝 เพิ่มหมายเหตุ

### **5. การเก็บเกี่ยว**
- 🌾 บันทึกผลผลิตที่เก็บได้
- ⚠️ บันทึกจำนวนที่ติดโรค/ตาย
- 📊 คำนวณอัตราความสำเร็จ

### **6. การขาย**
- 💰 บันทึกยอดขาย
- 🔗 เชื่อมโยงกับการเก็บเกี่ยว
- 📈 สรุปรายได้

### **7. รายงานสรุป**
- 📊 สถิติแบบเรียลไทม์
- 🌾 สรุปการเก็บเกี่ยว
- 💰 สรุปยอดขาย
- 📋 กิจกรรมล่าสุด

---

## 🗄️ โครงสร้างฐานข้อมูล

### **ตาราง (7 ตาราง)**
```
1. vegetables        - ข้อมูลผัก (30 รายการ)
2. planting_cycles   - รอบการปลูก (30 รายการ)
3. plantings         - การปลูก (30 รายการ)
4. care_records      - การดูแล (30 รายการ)
5. harvests          - การเก็บเกี่ยว (30 รายการ)
6. sales             - การขาย (30 รายการ)
7. sales_details     - รายละเอียดขาย (30 รายการ)
```

### **ความสัมพันธ์**
```
vegetables (1:N) → plantings (1:N) → care_records
                       ↓ (1:N)
                   harvests (1:N) → sales_details (N:1) → sales
                       ↑ (N:1)
                planting_cycles
```

---

## 🎯 ตัวอย่างการใช้งาน

### **เพิ่มผักใหม่**
1. คลิกแท็บ "ข้อมูลผัก"
2. กรอกชื่อผัก, ระยะเวลา, ราคา
3. คลิก "เพิ่มข้อมูลผัก"
4. ระบบจะสร้างรหัสอัตโนมัติ (เช่น VEG031)

### **บันทึกการเก็บเกี่ยว**
1. คลิกแท็บ "การเก็บเกี่ยว"
2. เลือกรหัสการปลูกและรอบ
3. ระบุวันที่และจำนวน
4. บันทึกจำนวนที่ติดโรค/ตาย (ถ้ามี)
5. คลิก "เพิ่มข้อมูลการเก็บเกี่ยว"

### **ดูรายงาน**
1. คลิกแท็บ "สรุปภาพรวม"
2. ดูสถิติทั้งหมด
3. ตรวจสอบกิจกรรมล่าสุด

---

## 📱 API Reference

### **Base URL**
```
http://localhost/vegetable-system/api.php
```

### **Endpoints**

#### **GET - ดึงข้อมูล**
```
GET api.php?action=getAll&table=vegetables
GET api.php?action=getSummary
GET api.php?action=getNextIds
```

#### **POST - เพิ่มข้อมูล**
```javascript
// เพิ่มผัก
POST api.php
{
    action: 'add',
    table: 'vegetables',
    veg_name: 'ผักใหม่',
    duration: 30,
    price: 25.00
}
```

#### **POST - แก้ไขข้อมูล**
```javascript
// แก้ไขผัก
POST api.php
{
    action: 'update',
    table: 'vegetables',
    veg_id: 'VEG001',
    veg_name: 'ผักแก้ไข',
    duration: 35,
    price: 28.00
}
```

#### **POST - ลบข้อมูล**
```javascript
// ลบผัก
POST api.php
{
    action: 'delete',
    table: 'vegetables',
    veg_id: 'VEG001'
}
```

### **Response Format**
```json
{
    "success": true,
    "message": "ข้อความ",
    "data": {...}
}
```

---

## 🔧 การตั้งค่า

### **1. แก้ไข config.php**
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');       // เปลี่ยนตาม Username
define('DB_PASS', '');            // เปลี่ยนตาม Password
define('DB_NAME', 'vegetable_management');
```

### **2. สิทธิ์ไฟล์ (Linux)**
```bash
chmod 755 index.php
chmod 644 config.php api.php
chmod 644 app-database.js
```

### **3. URL Rewriting (Optional)**
สร้างไฟล์ `.htaccess`:
```apache
RewriteEngine On
RewriteBase /vegetable-system/

# Remove .php extension
RewriteCond %{REQUEST_FILENAME} !-d
RewriteCond %{REQUEST_FILENAME}.php -f
RewriteRule ^(.*)$ $1.php [L]

# Redirect to index
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ index.php [L]
```

---

## 📸 ภาพตัวอย่าง

### **หน้าจัดการผัก**
- แสดงตารางข้อมูลผัก
- ฟอร์มเพิ่ม/แก้ไข
- ปุ่มลบและแก้ไข

### **หน้าสรุปภาพรวม**
- สถิติแบบเรียลไทม์
- กราฟแสดงผล (ถ้ามี)
- กิจกรรมล่าสุด

---

## 🐛 การแก้ปัญหา

### **ปัญหาที่พบบ่อย**

| ปัญหา | สาเหตุ | วิธีแก้ |
|-------|--------|---------|
| ไม่เชื่อมต่อ DB | รหัสผ่านผิด | ตรวจสอบ config.php |
| ภาษาไทยผิด | Charset ผิด | ตั้ง utf8mb4 |
| Auto ID ไม่ทำงาน | ไม่มีข้อมูล | รัน create.php |
| Foreign Key Error | ลำดับผิด | ลบข้อมูลตามลำดับ |
| 404 Error | Path ผิด | ตรวจสอบ URL |

ดูรายละเอียดใน **INSTALL_GUIDE.md**

---

## 📚 เอกสารเพิ่มเติม

| เอกสาร | รายละเอียด |
|--------|-----------|
| **DATABASE_GUIDE.md** | โครงสร้างฐานข้อมูล, Queries, Views |
| **INSTALL_GUIDE.md** | คู่มือติดตั้งฉบับสมบูรณ์ |
| **API_REFERENCE.md** | API Documentation (ถ้ามี) |

---

## 🔒 ความปลอดภัย

### **ที่ทำแล้ว:**
- ✅ Escape input ด้วย `real_escape_string`
- ✅ Validation พื้นฐาน
- ✅ Error handling

### **ควรเพิ่ม:**
- 🔐 Prepared Statements
- 🔑 Authentication System
- 🛡️ CSRF Protection
- 📝 Input Validation เพิ่มเติม
- 🔒 HTTPS

---

## 📈 การ Backup

### **Manual Backup**
```bash
# Backup database
mysqldump -u root -p vegetable_management > backup_$(date +%Y%m%d).sql

# Backup files
tar -czf vegetable-system-backup.tar.gz /path/to/vegetable-system
```

### **Auto Backup (Cron)**
```bash
# เพิ่มใน crontab
0 2 * * * /path/to/backup-script.sh
```

---

## 🚧 การพัฒนาต่อ

### **ฟีเจอร์ที่ควรเพิ่ม:**
- [ ] ระบบ Login/Authentication
- [ ] การอัปโหลดรูปภาพ
- [ ] Export เป็น PDF/Excel
- [ ] กราฟและ Charts
- [ ] Notifications
- [ ] Multi-user Support
- [ ] Mobile App
- [ ] API Documentation (Swagger)

---

## 📊 สถิติโครงการ

| รายการ | จำนวน |
|--------|------|
| ตาราง | 7 |
| ไฟล์ PHP | 3 |
| ไฟล์ JS | 1 |
| ข้อมูลตัวอย่าง | 210 rows |
| API Endpoints | 23 |
| บรรทัดโค้ด | ~2,500 |

---

## 👥 ทีมพัฒนา

**Vegetable Management System Team**
- 🌱 Full-Stack Development
- 🗄️ Database Design
- 🎨 UI/UX Design

---

## 📞 ติดต่อ & สนับสนุน

- 📧 **Email**: support@vegetable-system.com
- 💬 **Forum**: https://forum.vegetable-system.com
- 🐛 **Bug Report**: https://github.com/vegetable-system/issues
- 📖 **Documentation**: https://docs.vegetable-system.com

---

## 📜 License

**MIT License**

```
Copyright (c) 2024 Vegetable Management System Team

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction...
```

ใช้งานได้ฟรีสำหรับโครงการทุกประเภท

---

## 🎉 ขอบคุณ

ขอบคุณที่ใช้ระบบจัดการผัก!  
หากชอบโปรเจกต์นี้ อย่าลืม ⭐ Star บน GitHub

---

**เวอร์ชัน**: 1.0.0  
**วันที่อัปเดต**: 26 ตุลาคม 2024  
**สถานะ**: ✅ Stable

---

## 📝 Changelog

### Version 1.0.0 (2024-10-26)
- ✨ เปิดตัวระบบครั้งแรก
- ✅ ฟีเจอร์ครบถ้วน 7 โมดูล
- ✅ ข้อมูลตัวอย่าง 30 รายการ
- ✅ API สมบูรณ์
- ✅ เอกสารครบถ้วน

---

**Made with ❤️ in Thailand 🇹🇭**
