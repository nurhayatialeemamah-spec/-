<?php
/**
 * ============================================
 * API สำหรับจัดการข้อมูลระบบผัก
 * Vegetable Management System API
 * ============================================
 */

require_once 'config.php';

// รับข้อมูลจาก request
$action = isset($_POST['action']) ? $_POST['action'] : (isset($_GET['action']) ? $_GET['action'] : '');
$table = isset($_POST['table']) ? $_POST['table'] : (isset($_GET['table']) ? $_GET['table'] : '');

// ==================== VEGETABLES ====================
if ($table === 'vegetables') {
    
    // GET - ดึงข้อมูลทั้งหมด
    if ($action === 'getAll') {
        $result = $conn->query("SELECT * FROM vegetables ORDER BY veg_id");
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        sendResponse(true, 'ดึงข้อมูลสำเร็จ', $data);
    }
    
    // ADD - เพิ่มข้อมูล
    if ($action === 'add') {
        $veg_id = generateVegId($conn);
        $veg_name = clean($conn, $_POST['veg_name']);
        $duration = intval($_POST['duration']);
        $price = floatval($_POST['price']);
        
        $sql = "INSERT INTO vegetables (veg_id, veg_name, duration, price_per_unit) 
                VALUES ('$veg_id', '$veg_name', $duration, $price)";
        
        if ($conn->query($sql) === TRUE) {
            sendResponse(true, 'เพิ่มข้อมูลผักสำเร็จ', ['veg_id' => $veg_id]);
        } else {
            sendResponse(false, 'เกิดข้อผิดพลาด: ' . $conn->error);
        }
    }
    
    // UPDATE - แก้ไขข้อมูล
    if ($action === 'update') {
        $veg_id = clean($conn, $_POST['veg_id']);
        $veg_name = clean($conn, $_POST['veg_name']);
        $duration = intval($_POST['duration']);
        $price = floatval($_POST['price']);
        
        $sql = "UPDATE vegetables 
                SET veg_name='$veg_name', duration=$duration, price_per_unit=$price 
                WHERE veg_id='$veg_id'";
        
        if ($conn->query($sql) === TRUE) {
            sendResponse(true, 'แก้ไขข้อมูลผักสำเร็จ');
        } else {
            sendResponse(false, 'เกิดข้อผิดพลาด: ' . $conn->error);
        }
    }
    
    // DELETE - ลบข้อมูล
    if ($action === 'delete') {
        $veg_id = clean($conn, $_POST['veg_id']);
        
        $sql = "DELETE FROM vegetables WHERE veg_id='$veg_id'";
        
        if ($conn->query($sql) === TRUE) {
            sendResponse(true, 'ลบข้อมูลผักสำเร็จ');
        } else {
            sendResponse(false, 'เกิดข้อผิดพลาด: ' . $conn->error);
        }
    }
}

// ==================== PLANTING CYCLES ====================
if ($table === 'planting_cycles') {
    
    if ($action === 'getAll') {
        $result = $conn->query("SELECT * FROM planting_cycles ORDER BY cycle_no");
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        sendResponse(true, 'ดึงข้อมูลสำเร็จ', $data);
    }
    
    if ($action === 'add') {
        $planting_date = clean($conn, $_POST['planting_date']);
        $total_plants = intval($_POST['total_plants']);
        
        $sql = "INSERT INTO planting_cycles (planting_date, total_plants) 
                VALUES ('$planting_date', $total_plants)";
        
        if ($conn->query($sql) === TRUE) {
            sendResponse(true, 'เพิ่มรอบการปลูกสำเร็จ', ['cycle_no' => $conn->insert_id]);
        } else {
            sendResponse(false, 'เกิดข้อผิดพลาด: ' . $conn->error);
        }
    }
    
    if ($action === 'update') {
        $cycle_no = intval($_POST['cycle_no']);
        $planting_date = clean($conn, $_POST['planting_date']);
        $total_plants = intval($_POST['total_plants']);
        
        $sql = "UPDATE planting_cycles 
                SET planting_date='$planting_date', total_plants=$total_plants 
                WHERE cycle_no=$cycle_no";
        
        if ($conn->query($sql) === TRUE) {
            sendResponse(true, 'แก้ไขรอบการปลูกสำเร็จ');
        } else {
            sendResponse(false, 'เกิดข้อผิดพลาด: ' . $conn->error);
        }
    }
    
    if ($action === 'delete') {
        $cycle_no = intval($_POST['cycle_no']);
        
        $sql = "DELETE FROM planting_cycles WHERE cycle_no=$cycle_no";
        
        if ($conn->query($sql) === TRUE) {
            sendResponse(true, 'ลบรอบการปลูกสำเร็จ');
        } else {
            sendResponse(false, 'เกิดข้อผิดพลาด: ' . $conn->error);
        }
    }
}

// ==================== PLANTINGS ====================
if ($table === 'plantings') {
    
    if ($action === 'getAll') {
        $result = $conn->query("SELECT * FROM plantings ORDER BY plant_id");
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        sendResponse(true, 'ดึงข้อมูลสำเร็จ', $data);
    }
    
    if ($action === 'add') {
        $plant_id = generatePlantId($conn);
        $cycle_no = intval($_POST['cycle_no']);
        $veg_id = clean($conn, $_POST['veg_id']);
        $quantity = intval($_POST['quantity']);
        $plot_name = clean($conn, $_POST['plot_name']);
        
        $sql = "INSERT INTO plantings (plant_id, cycle_no, veg_id, quantity, plot_name) 
                VALUES ('$plant_id', $cycle_no, '$veg_id', $quantity, '$plot_name')";
        
        if ($conn->query($sql) === TRUE) {
            sendResponse(true, 'เพิ่มข้อมูลการปลูกสำเร็จ', ['plant_id' => $plant_id]);
        } else {
            sendResponse(false, 'เกิดข้อผิดพลาด: ' . $conn->error);
        }
    }
    
    if ($action === 'update') {
        $plant_id = clean($conn, $_POST['plant_id']);
        $cycle_no = intval($_POST['cycle_no']);
        $veg_id = clean($conn, $_POST['veg_id']);
        $quantity = intval($_POST['quantity']);
        $plot_name = clean($conn, $_POST['plot_name']);
        
        $sql = "UPDATE plantings 
                SET cycle_no=$cycle_no, veg_id='$veg_id', quantity=$quantity, plot_name='$plot_name' 
                WHERE plant_id='$plant_id'";
        
        if ($conn->query($sql) === TRUE) {
            sendResponse(true, 'แก้ไขข้อมูลการปลูกสำเร็จ');
        } else {
            sendResponse(false, 'เกิดข้อผิดพลาด: ' . $conn->error);
        }
    }
    
    if ($action === 'delete') {
        $plant_id = clean($conn, $_POST['plant_id']);
        
        $sql = "DELETE FROM plantings WHERE plant_id='$plant_id'";
        
        if ($conn->query($sql) === TRUE) {
            sendResponse(true, 'ลบข้อมูลการปลูกสำเร็จ');
        } else {
            sendResponse(false, 'เกิดข้อผิดพลาด: ' . $conn->error);
        }
    }
}

// ==================== CARE RECORDS ====================
if ($table === 'care_records') {
    
    if ($action === 'getAll') {
        $result = $conn->query("SELECT * FROM care_records ORDER BY care_id");
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        sendResponse(true, 'ดึงข้อมูลสำเร็จ', $data);
    }
    
    if ($action === 'add') {
        $care_id = generateCareId($conn);
        $plant_id = clean($conn, $_POST['plant_id']);
        $start_date = clean($conn, $_POST['start_date']);
        $end_date = clean($conn, $_POST['end_date']);
        $care_round = intval($_POST['care_round']);
        $notes = clean($conn, $_POST['notes']);
        
        $sql = "INSERT INTO care_records (care_id, plant_id, start_date, end_date, care_round, notes) 
                VALUES ('$care_id', '$plant_id', '$start_date', '$end_date', $care_round, '$notes')";
        
        if ($conn->query($sql) === TRUE) {
            sendResponse(true, 'เพิ่มข้อมูลการดูแลสำเร็จ', ['care_id' => $care_id]);
        } else {
            sendResponse(false, 'เกิดข้อผิดพลาด: ' . $conn->error);
        }
    }
    
    if ($action === 'update') {
        $care_id = clean($conn, $_POST['care_id']);
        $plant_id = clean($conn, $_POST['plant_id']);
        $start_date = clean($conn, $_POST['start_date']);
        $end_date = clean($conn, $_POST['end_date']);
        $care_round = intval($_POST['care_round']);
        $notes = clean($conn, $_POST['notes']);
        
        $sql = "UPDATE care_records 
                SET plant_id='$plant_id', start_date='$start_date', end_date='$end_date', 
                    care_round=$care_round, notes='$notes' 
                WHERE care_id='$care_id'";
        
        if ($conn->query($sql) === TRUE) {
            sendResponse(true, 'แก้ไขข้อมูลการดูแลสำเร็จ');
        } else {
            sendResponse(false, 'เกิดข้อผิดพลาด: ' . $conn->error);
        }
    }
    
    if ($action === 'delete') {
        $care_id = clean($conn, $_POST['care_id']);
        
        $sql = "DELETE FROM care_records WHERE care_id='$care_id'";
        
        if ($conn->query($sql) === TRUE) {
            sendResponse(true, 'ลบข้อมูลการดูแลสำเร็จ');
        } else {
            sendResponse(false, 'เกิดข้อผิดพลาด: ' . $conn->error);
        }
    }
}

// ==================== HARVESTS ====================
if ($table === 'harvests') {
    
    if ($action === 'getAll') {
        $result = $conn->query("SELECT * FROM harvests ORDER BY harvest_id");
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        sendResponse(true, 'ดึงข้อมูลสำเร็จ', $data);
    }
    
    if ($action === 'add') {
        $harvest_id = generateHarvestId($conn);
        $plant_id = clean($conn, $_POST['plant_id']);
        $cycle_no = intval($_POST['cycle_no']);
        $harvest_date = clean($conn, $_POST['harvest_date']);
        $harvested_amount = intval($_POST['harvested_amount']);
        $diseased_amount = intval($_POST['diseased_amount']);
        $dead_amount = intval($_POST['dead_amount']);
        
        $sql = "INSERT INTO harvests (harvest_id, plant_id, cycle_no, harvest_date, harvested_amount, diseased_amount, dead_amount) 
                VALUES ('$harvest_id', '$plant_id', $cycle_no, '$harvest_date', $harvested_amount, $diseased_amount, $dead_amount)";
        
        if ($conn->query($sql) === TRUE) {
            sendResponse(true, 'เพิ่มข้อมูลการเก็บเกี่ยวสำเร็จ', ['harvest_id' => $harvest_id]);
        } else {
            sendResponse(false, 'เกิดข้อผิดพลาด: ' . $conn->error);
        }
    }
    
    if ($action === 'update') {
        $harvest_id = clean($conn, $_POST['harvest_id']);
        $plant_id = clean($conn, $_POST['plant_id']);
        $cycle_no = intval($_POST['cycle_no']);
        $harvest_date = clean($conn, $_POST['harvest_date']);
        $harvested_amount = intval($_POST['harvested_amount']);
        $diseased_amount = intval($_POST['diseased_amount']);
        $dead_amount = intval($_POST['dead_amount']);
        
        $sql = "UPDATE harvests 
                SET plant_id='$plant_id', cycle_no=$cycle_no, harvest_date='$harvest_date', 
                    harvested_amount=$harvested_amount, diseased_amount=$diseased_amount, dead_amount=$dead_amount 
                WHERE harvest_id='$harvest_id'";
        
        if ($conn->query($sql) === TRUE) {
            sendResponse(true, 'แก้ไขข้อมูลการเก็บเกี่ยวสำเร็จ');
        } else {
            sendResponse(false, 'เกิดข้อผิดพลาด: ' . $conn->error);
        }
    }
    
    if ($action === 'delete') {
        $harvest_id = clean($conn, $_POST['harvest_id']);
        
        $sql = "DELETE FROM harvests WHERE harvest_id='$harvest_id'";
        
        if ($conn->query($sql) === TRUE) {
            sendResponse(true, 'ลบข้อมูลการเก็บเกี่ยวสำเร็จ');
        } else {
            sendResponse(false, 'เกิดข้อผิดพลาด: ' . $conn->error);
        }
    }
}

// ==================== SALES ====================
if ($table === 'sales') {
    
    if ($action === 'getAll') {
        $result = $conn->query("SELECT * FROM sales ORDER BY sale_id");
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        sendResponse(true, 'ดึงข้อมูลสำเร็จ', $data);
    }
    
    if ($action === 'add') {
        $sale_id = generateSaleId($conn);
        $sale_date = clean($conn, $_POST['sale_date']);
        $total_amount = floatval($_POST['total_amount']);
        
        $sql = "INSERT INTO sales (sale_id, sale_date, total_amount) 
                VALUES ('$sale_id', '$sale_date', $total_amount)";
        
        if ($conn->query($sql) === TRUE) {
            sendResponse(true, 'เพิ่มข้อมูลการขายสำเร็จ', ['sale_id' => $sale_id]);
        } else {
            sendResponse(false, 'เกิดข้อผิดพลาด: ' . $conn->error);
        }
    }
    
    if ($action === 'update') {
        $sale_id = clean($conn, $_POST['sale_id']);
        $sale_date = clean($conn, $_POST['sale_date']);
        $total_amount = floatval($_POST['total_amount']);
        
        $sql = "UPDATE sales 
                SET sale_date='$sale_date', total_amount=$total_amount 
                WHERE sale_id='$sale_id'";
        
        if ($conn->query($sql) === TRUE) {
            sendResponse(true, 'แก้ไขข้อมูลการขายสำเร็จ');
        } else {
            sendResponse(false, 'เกิดข้อผิดพลาด: ' . $conn->error);
        }
    }
    
    if ($action === 'delete') {
        $sale_id = clean($conn, $_POST['sale_id']);
        
        $sql = "DELETE FROM sales WHERE sale_id='$sale_id'";
        
        if ($conn->query($sql) === TRUE) {
            sendResponse(true, 'ลบข้อมูลการขายสำเร็จ');
        } else {
            sendResponse(false, 'เกิดข้อผิดพลาด: ' . $conn->error);
        }
    }
}

// ==================== SALES DETAILS ====================
if ($table === 'sales_details') {
    
    if ($action === 'getAll') {
        $result = $conn->query("SELECT * FROM sales_details ORDER BY detail_id");
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        sendResponse(true, 'ดึงข้อมูลสำเร็จ', $data);
    }
    
    if ($action === 'add') {
        $harvest_id = clean($conn, $_POST['harvest_id']);
        $sale_id = clean($conn, $_POST['sale_id']);
        $quantity = intval($_POST['quantity']);
        $subtotal = floatval($_POST['subtotal']);
        
        $sql = "INSERT INTO sales_details (harvest_id, sale_id, quantity, subtotal) 
                VALUES ('$harvest_id', '$sale_id', $quantity, $subtotal)";
        
        if ($conn->query($sql) === TRUE) {
            sendResponse(true, 'เพิ่มรายละเอียดการขายสำเร็จ', ['detail_id' => $conn->insert_id]);
        } else {
            sendResponse(false, 'เกิดข้อผิดพลาด: ' . $conn->error);
        }
    }
    
    if ($action === 'update') {
        $detail_id = intval($_POST['detail_id']);
        $harvest_id = clean($conn, $_POST['harvest_id']);
        $sale_id = clean($conn, $_POST['sale_id']);
        $quantity = intval($_POST['quantity']);
        $subtotal = floatval($_POST['subtotal']);
        
        $sql = "UPDATE sales_details 
                SET harvest_id='$harvest_id', sale_id='$sale_id', quantity=$quantity, subtotal=$subtotal 
                WHERE detail_id=$detail_id";
        
        if ($conn->query($sql) === TRUE) {
            sendResponse(true, 'แก้ไขรายละเอียดการขายสำเร็จ');
        } else {
            sendResponse(false, 'เกิดข้อผิดพลาด: ' . $conn->error);
        }
    }
    
    if ($action === 'delete') {
        $detail_id = intval($_POST['detail_id']);
        
        $sql = "DELETE FROM sales_details WHERE detail_id=$detail_id";
        
        if ($conn->query($sql) === TRUE) {
            sendResponse(true, 'ลบรายละเอียดการขายสำเร็จ');
        } else {
            sendResponse(false, 'เกิดข้อผิดพลาด: ' . $conn->error);
        }
    }
}

// ==================== GET NEXT IDs ====================
if ($action === 'getNextIds') {
    $data = [
        'veg_id' => generateVegId($conn),
        'plant_id' => generatePlantId($conn),
        'care_id' => generateCareId($conn),
        'harvest_id' => generateHarvestId($conn),
        'sale_id' => generateSaleId($conn),
        'cycle_no' => getNextCycleNo($conn),
        'detail_order' => getNextDetailOrder($conn)
    ];
    sendResponse(true, 'ดึงข้อมูลรหัสถัดไปสำเร็จ', $data);
}

// ==================== GET SUMMARY ====================
if ($action === 'getSummary') {
    $summary = [];
    
    // นับจำนวนทั้งหมด
    $result = $conn->query("SELECT COUNT(*) as count FROM vegetables");
    $summary['total_vegetables'] = $result->fetch_assoc()['count'];
    
    $result = $conn->query("SELECT COUNT(*) as count FROM planting_cycles");
    $summary['total_cycles'] = $result->fetch_assoc()['count'];
    
    $result = $conn->query("SELECT COUNT(*) as count FROM plantings");
    $summary['total_plantings'] = $result->fetch_assoc()['count'];
    
    $result = $conn->query("SELECT COUNT(*) as count FROM care_records");
    $summary['total_cares'] = $result->fetch_assoc()['count'];
    
    $result = $conn->query("SELECT COUNT(*) as count FROM harvests");
    $summary['total_harvests'] = $result->fetch_assoc()['count'];
    
    $result = $conn->query("SELECT SUM(harvested_amount) as total FROM harvests");
    $summary['total_harvest_amount'] = $result->fetch_assoc()['total'] ?? 0;
    
    $result = $conn->query("SELECT SUM(diseased_amount) as total FROM harvests");
    $summary['total_disease'] = $result->fetch_assoc()['total'] ?? 0;
    
    $result = $conn->query("SELECT SUM(dead_amount) as total FROM harvests");
    $summary['total_dead'] = $result->fetch_assoc()['total'] ?? 0;
    
    $result = $conn->query("SELECT COUNT(*) as count FROM sales");
    $summary['total_sales'] = $result->fetch_assoc()['count'];
    
    $result = $conn->query("SELECT SUM(total_amount) as total FROM sales");
    $summary['total_sales_amount'] = $result->fetch_assoc()['total'] ?? 0;
    
    $result = $conn->query("SELECT COUNT(*) as count FROM sales_details");
    $summary['total_sales_details'] = $result->fetch_assoc()['count'];
    
    sendResponse(true, 'ดึงข้อมูลสรุปสำเร็จ', $summary);
}

// ถ้าไม่มี action ที่ตรงกัน
sendResponse(false, 'ไม่พบคำสั่งที่ต้องการ');

$conn->close();
?>
