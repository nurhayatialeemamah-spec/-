# 📚 คู่มือฐานข้อมูลระบบจัดการผัก
# Vegetable Management System Database Guide

## 📋 สารบัญ
1. [ข้อมูลทั่วไป](#ข้อมูลทั่วไป)
2. [โครงสร้างฐานข้อมูล](#โครงสร้างฐานข้อมูล)
3. [ความสัมพันธ์ระหว่างตาราง](#ความสัมพันธ์ระหว่างตาราง)
4. [วิธีการติดตั้ง](#วิธีการติดตั้ง)
5. [ตัวอย่างการใช้งาน](#ตัวอย่างการใช้งาน)
6. [Stored Procedures](#stored-procedures)
7. [Views](#views)

---

## 📊 ข้อมูลทั่วไป

### ชื่อฐานข้อมูล
`vegetable_management`

### ข้อมูลตัวอย่าง
- ✅ **30 รายการ** ในทุกตาราง
- ✅ ข้อมูล**เชื่อมโยงกัน**อย่างสมบูรณ์
- ✅ มี Foreign Keys ทั้งหมด
- ✅ พร้อม Index เพื่อประสิทธิภาพ

### สถิติข้อมูล
- 🌱 **ผัก**: 30 ชนิด
- 🔄 **รอบการปลูก**: 30 รอบ (ม.ค. - ต.ค. 2024)
- 🌾 **การปลูก**: 30 ครั้ง (แปลง A-O)
- 💚 **การดูแล**: 30 ครั้ง
- 🌾 **การเก็บเกี่ยว**: 30 ครั้ง (รวม 4,125 หน่วย)
- 💰 **การขาย**: 30 ครั้ง (รวม 133,825 บาท)
- 📝 **รายละเอียดขาย**: 30 รายการ

---

## 🗂️ โครงสร้างฐานข้อมูล

### 1️⃣ ตาราง `vegetables` (ข้อมูลผัก)
```sql
- veg_id VARCHAR(10) PRIMARY KEY
- veg_name VARCHAR(100)
- duration INT (ระยะเวลาการปลูก วัน)
- price_per_unit DECIMAL(10,2) (ราคาต่อหน่วย)
- created_at TIMESTAMP
- updated_at TIMESTAMP
```

**ตัวอย่างข้อมูล:**
| veg_id | veg_name | duration | price_per_unit |
|--------|----------|----------|----------------|
| VEG001 | ผักกาดหอม | 30 | 25.00 |
| VEG002 | คะน้า | 45 | 30.00 |
| VEG003 | ผักบุ้ง | 25 | 20.00 |

---

### 2️⃣ ตาราง `planting_cycles` (รอบการปลูก)
```sql
- cycle_no INT PRIMARY KEY AUTO_INCREMENT
- planting_date DATE
- total_plants INT
- created_at TIMESTAMP
- updated_at TIMESTAMP
```

**ตัวอย่างข้อมูล:**
| cycle_no | planting_date | total_plants |
|----------|---------------|--------------|
| 1 | 2024-01-05 | 500 |
| 2 | 2024-01-15 | 600 |
| 3 | 2024-01-25 | 550 |

---

### 3️⃣ ตาราง `plantings` (ข้อมูลการปลูก)
```sql
- plant_id VARCHAR(10) PRIMARY KEY
- cycle_no INT (FK → planting_cycles)
- veg_id VARCHAR(10) (FK → vegetables)
- quantity INT
- plot_name VARCHAR(50)
- created_at TIMESTAMP
- updated_at TIMESTAMP
```

**ความสัมพันธ์:**
- 1 รอบการปลูก → N การปลูก
- 1 ชนิดผัก → N การปลูก

**ตัวอย่างข้อมูล:**
| plant_id | cycle_no | veg_id | quantity | plot_name |
|----------|----------|--------|----------|-----------|
| PLT001 | 1 | VEG001 | 100 | แปลง A1 |
| PLT002 | 1 | VEG002 | 120 | แปลง A2 |

---

### 4️⃣ ตาราง `care_records` (ข้อมูลการดูแล)
```sql
- care_id VARCHAR(10) PRIMARY KEY
- plant_id VARCHAR(10) (FK → plantings)
- start_date DATE
- end_date DATE
- care_round INT
- notes TEXT
- created_at TIMESTAMP
- updated_at TIMESTAMP
```

**ความสัมพันธ์:**
- 1 การปลูก → N การดูแล

---

### 5️⃣ ตาราง `harvests` (ข้อมูลการเก็บเกี่ยว)
```sql
- harvest_id VARCHAR(10) PRIMARY KEY
- plant_id VARCHAR(10) (FK → plantings)
- cycle_no INT (FK → planting_cycles)
- harvest_date DATE
- harvested_amount INT
- diseased_amount INT
- dead_amount INT
- created_at TIMESTAMP
- updated_at TIMESTAMP
```

**ความสัมพันธ์:**
- 1 การปลูก → N การเก็บเกี่ยว
- 1 รอบการปลูก → N การเก็บเกี่ยว

---

### 6️⃣ ตาราง `sales` (ข้อมูลการขาย)
```sql
- sale_id VARCHAR(10) PRIMARY KEY
- sale_date DATE
- total_amount DECIMAL(10,2)
- created_at TIMESTAMP
- updated_at TIMESTAMP
```

---

### 7️⃣ ตาราง `sales_details` (รายละเอียดรายการขาย)
```sql
- detail_id INT PRIMARY KEY AUTO_INCREMENT
- harvest_id VARCHAR(10) (FK → harvests)
- sale_id VARCHAR(10) (FK → sales)
- quantity INT
- subtotal DECIMAL(10,2)
- created_at TIMESTAMP
- updated_at TIMESTAMP
```

**ความสัมพันธ์:**
- 1 การขาย → N รายละเอียดการขาย
- 1 การเก็บเกี่ยว → N รายละเอียดการขาย

---

## 🔗 ความสัมพันธ์ระหว่างตาราง (ERD)

```
vegetables (1) ←→ (N) plantings (N) ←→ (1) planting_cycles
    ↓
plantings (1) ←→ (N) care_records
    ↓
plantings (1) ←→ (N) harvests (N) ←→ (1) sales_details (N) ←→ (1) sales
```

---

## 🛠️ วิธีการติดตั้ง

### ขั้นตอนที่ 1: เตรียม MySQL/MariaDB
```bash
# ตรวจสอบว่าติดตั้ง MySQL แล้ว
mysql --version
```

### ขั้นตอนที่ 2: Import ฐานข้อมูล
```bash
# เข้า MySQL
mysql -u root -p

# หรือ Import โดยตรง
mysql -u root -p < vegetable_database.sql
```

### ขั้นตอนที่ 3: ตรวจสอบการติดตั้ง
```sql
USE vegetable_management;
SHOW TABLES;
SELECT * FROM v_summary;
```

---

## 💻 ตัวอย่างการใช้งาน

### 1. ดูข้อมูลผักทั้งหมด
```sql
SELECT * FROM vegetables ORDER BY veg_id;
```

### 2. ดูรอบการปลูกในเดือนมกราคม 2024
```sql
SELECT * FROM planting_cycles 
WHERE planting_date BETWEEN '2024-01-01' AND '2024-01-31';
```

### 3. ดูการปลูกพร้อมชื่อผัก
```sql
SELECT * FROM v_planting_details;
```

### 4. ดูสรุปการเก็บเกี่ยวพร้อมอัตราความสำเร็จ
```sql
SELECT * FROM v_harvest_details 
ORDER BY success_rate DESC;
```

### 5. ดูรายงานการขายรายเดือน
```sql
SELECT 
    DATE_FORMAT(sale_date, '%Y-%m') AS month,
    COUNT(*) AS total_sales,
    SUM(total_amount) AS revenue
FROM sales
GROUP BY DATE_FORMAT(sale_date, '%Y-%m')
ORDER BY month;
```

### 6. ดูผักที่ขายดีที่สุด (Top 10)
```sql
SELECT 
    v.veg_name,
    SUM(sd.quantity) AS total_sold,
    SUM(sd.subtotal) AS total_revenue
FROM sales_details sd
JOIN harvests h ON sd.harvest_id = h.harvest_id
JOIN plantings p ON h.plant_id = p.plant_id
JOIN vegetables v ON p.veg_id = v.veg_id
GROUP BY v.veg_name
ORDER BY total_revenue DESC
LIMIT 10;
```

### 7. ดูแปลงที่มีผลผลิตสูงสุด
```sql
SELECT 
    p.plot_name,
    SUM(h.harvested_amount) AS total_harvest,
    COUNT(*) AS harvest_count,
    AVG(h.harvested_amount) AS avg_harvest
FROM harvests h
JOIN plantings p ON h.plant_id = p.plant_id
GROUP BY p.plot_name
ORDER BY total_harvest DESC;
```

### 8. วิเคราะห์อัตราการเสียหาย
```sql
SELECT 
    v.veg_name,
    SUM(h.harvested_amount) AS success,
    SUM(h.diseased_amount) AS diseased,
    SUM(h.dead_amount) AS dead,
    ROUND(
        (SUM(h.diseased_amount + h.dead_amount) * 100.0) / 
        (SUM(h.harvested_amount + h.diseased_amount + h.dead_amount)),
        2
    ) AS loss_rate_percent
FROM harvests h
JOIN plantings p ON h.plant_id = p.plant_id
JOIN vegetables v ON p.veg_id = v.veg_id
GROUP BY v.veg_name
ORDER BY loss_rate_percent DESC;
```

---

## 📦 Stored Procedures

### 1. เพิ่มข้อมูลการปลูก (Auto ID)
```sql
CALL sp_add_planting(1, 'VEG001', 150, 'แปลง P1');
```

### 2. เพิ่มข้อมูลการเก็บเกี่ยว (Auto ID)
```sql
CALL sp_add_harvest('PLT001', 1, '2024-11-01', 140, 5, 5);
```

### 3. เพิ่มข้อมูลการขาย (Auto ID)
```sql
CALL sp_add_sale('2024-11-01', 5000.00);
```

---

## 👁️ Views

### 1. `v_summary` - สรุปภาพรวมระบบ
```sql
SELECT * FROM v_summary;
```
แสดง: จำนวนทั้งหมดของทุกตาราง, ยอดขาย, ผลผลิต

### 2. `v_planting_details` - รายละเอียดการปลูกแบบเต็ม
```sql
SELECT * FROM v_planting_details WHERE veg_name LIKE '%ผักกาด%';
```

### 3. `v_harvest_details` - รายละเอียดการเก็บเกี่ยว + อัตราความสำเร็จ
```sql
SELECT * FROM v_harvest_details WHERE success_rate > 90;
```

### 4. `v_sales_report` - รายงานการขายแบบละเอียด
```sql
SELECT * FROM v_sales_report WHERE sale_date >= '2024-06-01';
```

---

## 🔐 สิทธิ์การใช้งาน

### สร้าง User สำหรับระบบ
```sql
-- User แอดมิน (เต็มสิทธิ์)
CREATE USER 'veg_admin'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON vegetable_management.* TO 'veg_admin'@'localhost';

-- User พนักงาน (อ่านและเพิ่มข้อมูล)
CREATE USER 'veg_staff'@'localhost' IDENTIFIED BY 'your_password';
GRANT SELECT, INSERT, UPDATE ON vegetable_management.* TO 'veg_staff'@'localhost';

-- User รายงาน (อ่านอย่างเดียว)
CREATE USER 'veg_report'@'localhost' IDENTIFIED BY 'your_password';
GRANT SELECT ON vegetable_management.* TO 'veg_report'@'localhost';

FLUSH PRIVILEGES;
```

---

## 📈 การสำรองข้อมูล (Backup)

### Backup ทั้งฐานข้อมูล
```bash
mysqldump -u root -p vegetable_management > backup_$(date +%Y%m%d).sql
```

### Restore จาก Backup
```bash
mysql -u root -p vegetable_management < backup_20241026.sql
```

---

## 🧪 ทดสอบฐานข้อมูล

### ตรวจสอบความถูกต้องของข้อมูล
```sql
-- ตรวจสอบ Foreign Keys
SELECT 
    TABLE_NAME,
    CONSTRAINT_NAME,
    REFERENCED_TABLE_NAME
FROM information_schema.KEY_COLUMN_USAGE
WHERE TABLE_SCHEMA = 'vegetable_management'
AND REFERENCED_TABLE_NAME IS NOT NULL;

-- ตรวจสอบจำนวนข้อมูล
SELECT 
    'vegetables' AS table_name, COUNT(*) AS count FROM vegetables
UNION ALL
SELECT 'planting_cycles', COUNT(*) FROM planting_cycles
UNION ALL
SELECT 'plantings', COUNT(*) FROM plantings
UNION ALL
SELECT 'care_records', COUNT(*) FROM care_records
UNION ALL
SELECT 'harvests', COUNT(*) FROM harvests
UNION ALL
SELECT 'sales', COUNT(*) FROM sales
UNION ALL
SELECT 'sales_details', COUNT(*) FROM sales_details;
```

---

## ⚠️ ข้อควรระวัง

1. **Foreign Key Constraints**: ลบข้อมูลจะต้องเรียงลำดับ (sales_details → sales, harvests → plantings → vegetables)
2. **Auto Increment**: รอบการปลูกและรายละเอียดการขายใช้ AUTO_INCREMENT
3. **Date Format**: ใช้รูปแบบ 'YYYY-MM-DD'
4. **Character Set**: ฐานข้อมูลใช้ utf8mb4 รองรับภาษาไทย

---

## 📞 การติดต่อ

หากพบปัญหาหรือต้องการความช่วยเหลือ:
- 📧 Email: support@vegetable-system.com
- 📖 Documentation: https://docs.vegetable-system.com
- 💬 Community: https://forum.vegetable-system.com

---

## 📝 License

MIT License - ใช้งานได้ฟรีสำหรับโครงการทุกประเภท

---

**สร้างโดย**: Vegetable Management System Team  
**เวอร์ชัน**: 1.0.0  
**วันที่อัปเดต**: 26 ตุลาคม 2024
