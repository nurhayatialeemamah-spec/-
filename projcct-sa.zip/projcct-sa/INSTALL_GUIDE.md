# 🌱 คู่มือติดตั้งและใช้งานระบบจัดการผัก
# Vegetable Management System - Installation Guide

## 📋 สารบัญ
1. [ไฟล์ที่ได้รับ](#ไฟล์ที่ได้รับ)
2. [ความต้องการของระบบ](#ความต้องการของระบบ)
3. [การติดตั้ง](#การติดตั้ง)
4. [การตั้งค่า](#การตั้งค่า)
5. [การใช้งาน](#การใช้งาน)
6. [โครงสร้างไฟล์](#โครงสร้างไฟล์)
7. [การแก้ปัญหา](#การแก้ปัญหา)

---

## 📦 ไฟล์ที่ได้รับ

### **1. ไฟล์สร้างฐานข้อมูล**
- `create.php` - สร้างฐานข้อมูลและข้อมูลตัวอย่าง 30 รายการ
- `vegetable_database.sql` - ไฟล์ SQL สำหรับ Import

### **2. ไฟล์ระบบหลัก**
- `index.php` - หน้าหลักของระบบ (Frontend)
- `config.php` - การตั้งค่าการเชื่อมต่อฐานข้อมูล
- `api.php` - API สำหรับจัดการข้อมูล (Backend)
- `app-database.js` - JavaScript เชื่อมต่อกับ API
- `style.css` - ไฟล์ CSS (ถ้ามี)

### **3. เอกสารประกอบ**
- `DATABASE_GUIDE.md` - คู่มือฐานข้อมูล
- `INSTALL_GUIDE.md` - คู่มือนี้

---

## 💻 ความต้องการของระบบ

### **ซอฟต์แวร์ที่จำเป็น:**
- ✅ **PHP** เวอร์ชัน 7.4 ขึ้นไป
- ✅ **MySQL** / **MariaDB** เวอร์ชัน 5.7 ขึ้นไป
- ✅ **Web Server**: Apache หรือ Nginx
- ✅ **phpMyAdmin** (แนะนำสำหรับจัดการฐานข้อมูล)

### **แพ็กเกจที่แนะนำ:**
- 🔧 **XAMPP** (Windows/Mac/Linux)
- 🔧 **WAMP** (Windows)
- 🔧 **MAMP** (Mac)
- 🔧 **LAMP** (Linux)

---

## 🚀 การติดตั้ง

### **วิธีที่ 1: ใช้ create.php (แนะนำ)**

#### **ขั้นตอนที่ 1: วางไฟล์**
```
C:\xampp\htdocs\vegetable-system\
├── create.php
├── config.php
├── api.php
├── index.php
├── app-database.js
└── style.css (ถ้ามี)
```

#### **ขั้นตอนที่ 2: แก้ไขการเชื่อมต่อในไฟล์ create.php**
เปิดไฟล์ `create.php` แก้บรรทัด 15-18:
```php
define('DB_HOST', 'localhost');      // ชื่อโฮสต์
define('DB_USER', 'root');            // Username
define('DB_PASS', '');                // Password
define('DB_NAME', 'vegetable_management');
```

#### **ขั้นตอนที่ 3: รัน create.php**
เปิดเบราว์เซอร์แล้วเข้า:
```
http://localhost/vegetable-system/create.php
```

จะเห็นหน้าจอสร้างฐานข้อมูลพร้อมสถิติ ✅

#### **ขั้นตอนที่ 4: ลบ create.php**
**สำคัญ!** หลังสร้างฐานข้อมูลเรียบร้อยแล้ว ให้ลบไฟล์ `create.php` ทิ้ง

---

### **วิธีที่ 2: ใช้ไฟล์ SQL**

#### **ขั้นตอนที่ 1: เข้า phpMyAdmin**
```
http://localhost/phpmyadmin
```

#### **ขั้นตอนที่ 2: Import ฐานข้อมูล**
1. คลิก "Import" ที่แท็บด้านบน
2. เลือกไฟล์ `vegetable_database.sql`
3. คลิก "Go" หรือ "นำเข้า"

#### **ขั้นตอนที่ 3: ตรวจสอบ**
```sql
USE vegetable_management;
SHOW TABLES;
SELECT COUNT(*) FROM vegetables;
```

---

## ⚙️ การตั้งค่า

### **1. แก้ไขไฟล์ config.php**
เปิดไฟล์ `config.php` แก้บรรทัด 10-13:
```php
define('DB_HOST', 'localhost');      
define('DB_USER', 'root');           // เปลี่ยนตาม Username ของคุณ
define('DB_PASS', '');                // เปลี่ยนตาม Password ของคุณ
define('DB_NAME', 'vegetable_management');
```

### **2. ตรวจสอบการเชื่อมต่อ**
สร้างไฟล์ `test-connection.php`:
```php
<?php
require_once 'config.php';
echo "✅ เชื่อมต่อสำเร็จ!";
$conn->close();
?>
```

เข้า: `http://localhost/vegetable-system/test-connection.php`

---

## 🎯 การใช้งาน

### **เข้าสู่ระบบ**
```
http://localhost/vegetable-system/index.php
```
หรือ
```
http://localhost/vegetable-system/
```

### **ฟีเจอร์หลัก**

#### **1. ข้อมูลผัก (Vegetables)**
- ✨ รหัสผักสร้างอัตโนมัติ (VEG001, VEG002...)
- ➕ เพิ่ม / ✏️ แก้ไข / 🗑️ ลบ
- 🔍 ค้นหา

#### **2. รอบการปลูก (Planting Cycles)**
- ✨ รอบปลูกสร้างอัตโนมัติ (1, 2, 3...)
- ระบุวันที่ปลูกและจำนวนต้น

#### **3. การปลูก (Plantings)**
- ✨ รหัสการปลูกอัตโนมัติ (PLT001, PLT002...)
- เชื่อมโยงกับ: รอบการปลูก + ผัก
- ระบุจำนวนและแปลง

#### **4. การดูแล (Care Records)**
- ✨ รหัสการดูแลอัตโนมัติ (CARE001, CARE002...)
- เชื่อมโยงกับ: การปลูก
- บันทึกวันที่และหมายเหตุ

#### **5. การเก็บเกี่ยว (Harvests)**
- ✨ รหัสการเก็บเกี่ยวอัตโนมัติ (HRV001, HRV002...)
- เชื่อมโยงกับ: การปลูก + รอบการปลูก
- บันทึกผลผลิต / โรค / ตาย

#### **6. การขาย (Sales)**
- ✨ รหัสการขายอัตโนมัติ (SALE001, SALE002...)
- บันทึกวันที่และยอดขาย

#### **7. รายละเอียดการขาย (Sales Details)**
- ✨ ลำดับอัตโนมัติ (1, 2, 3...)
- เชื่อมโยงกับ: การเก็บเกี่ยว + การขาย
- คำนวณยอดรวม

#### **8. สรุปภาพรวม (Summary)**
- 📊 สถิติแบบเรียลไทม์
- 🌾 สรุปการเก็บเกี่ยว
- 💰 สรุปการขาย

---

## 📁 โครงสร้างไฟล์

```
vegetable-system/
│
├── index.php              ← หน้าหลัก (Frontend)
├── config.php             ← การเชื่อมต่อฐานข้อมูล
├── api.php                ← API Backend
├── app-database.js        ← JavaScript
├── style.css              ← CSS (ถ้ามี)
│
├── create.php             ← สร้างฐานข้อมูล (ลบหลังใช้)
└── vegetable_database.sql ← ไฟล์ SQL
```

---

## 🗄️ โครงสร้างฐานข้อมูล

```
vegetable_management
│
├── vegetables           (30 rows) - ข้อมูลผัก
├── planting_cycles      (30 rows) - รอบการปลูก
├── plantings            (30 rows) - การปลูก
├── care_records         (30 rows) - การดูแล
├── harvests             (30 rows) - การเก็บเกี่ยว
├── sales                (30 rows) - การขาย
└── sales_details        (30 rows) - รายละเอียดขาย
```

### **ความสัมพันธ์:**
```
vegetables → plantings → care_records
           ↓
plantings → harvests → sales_details → sales
           ↑
planting_cycles ───────┘
```

---

## 🔧 การแก้ปัญหา

### **❌ ปัญหา: ไม่สามารถเชื่อมต่อฐานข้อมูล**
**แก้ไข:**
1. ตรวจสอบ MySQL/MariaDB เปิดอยู่หรือไม่
2. ตรวจสอบ Username/Password ใน `config.php`
3. ตรวจสอบชื่อฐานข้อมูลถูกต้อง

### **❌ ปัญหา: รหัสไม่อัตโนมัติ**
**แก้ไข:**
1. ตรวจสอบฟังก์ชัน `getNextIds` ใน `api.php`
2. เรียกใช้ `updateAutoIdDisplays()` ใน JavaScript

### **❌ ปัญหา: ภาษาไทยแสดงผิด**
**แก้ไข:**
1. ตรวจสอบ charset ในฐานข้อมูล
```sql
ALTER DATABASE vegetable_management 
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```
2. เพิ่มใน `config.php`:
```php
$conn->set_charset("utf8mb4");
```

### **❌ ปัญหา: Foreign Key Error**
**แก้ไข:**
ลบข้อมูลตามลำดับ:
1. sales_details
2. sales / harvests
3. care_records / harvests
4. plantings
5. vegetables / planting_cycles

### **❌ ปัญหา: ไม่แสดงข้อมูล**
**แก้ไข:**
1. เปิด Console (F12) ดู Error
2. ตรวจสอบ `api.php` ทำงานหรือไม่
3. ทดสอบ: `http://localhost/vegetable-system/api.php?action=getSummary`

---

## 📊 ตัวอย่างการใช้งาน API

### **1. ดึงข้อมูลผักทั้งหมด**
```javascript
const result = await apiCall('getAll', 'vegetables');
console.log(result.data);
```

### **2. เพิ่มผักใหม่**
```javascript
const data = {
    veg_name: 'ผักใหม่',
    duration: 30,
    price: 25.00
};
const result = await apiCall('add', 'vegetables', data);
```

### **3. แก้ไขผัก**
```javascript
const data = {
    veg_id: 'VEG001',
    veg_name: 'ผักกาดหอม (แก้ไข)',
    duration: 35,
    price: 28.00
};
const result = await apiCall('update', 'vegetables', data);
```

### **4. ลบผัก**
```javascript
const result = await apiCall('delete', 'vegetables', { veg_id: 'VEG001' });
```

### **5. ดึงรหัสถัดไป**
```javascript
const result = await apiCall('getNextIds', '');
console.log(result.data.veg_id); // VEG031
```

---

## 🔒 ความปลอดภัย

### **1. ปกป้องไฟล์สำคัญ**
สร้างไฟล์ `.htaccess`:
```apache
# ป้องกันเข้าถึง config.php
<Files "config.php">
    Require all denied
</Files>

# ป้องกัน SQL injection
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteCond %{QUERY_STRING} [a-zA-Z0-9_]=http:// [OR]
    RewriteCond %{QUERY_STRING} [a-zA-Z0-9_]=(\.\.//?)+ [OR]
    RewriteCond %{QUERY_STRING} [a-zA-Z0-9_]=/([a-z0-9_.]//?)+ [NC]
    RewriteRule .* - [F]
</IfModule>
```

### **2. ใช้ Prepared Statements**
ในอนาคตควรอัพเกรดเป็น:
```php
$stmt = $conn->prepare("INSERT INTO vegetables (veg_name) VALUES (?)");
$stmt->bind_param("s", $veg_name);
$stmt->execute();
```

### **3. Validation**
เพิ่มการตรวจสอบข้อมูลใน JavaScript และ PHP

---

## 📈 การ Backup

### **1. Backup ฐานข้อมูล**
```bash
# Command Line
mysqldump -u root -p vegetable_management > backup.sql

# Windows (XAMPP)
C:\xampp\mysql\bin\mysqldump -u root vegetable_management > backup.sql
```

### **2. Restore**
```bash
mysql -u root -p vegetable_management < backup.sql
```

### **3. Backup อัตโนมัติ**
ตั้งค่า Cron Job (Linux):
```bash
0 2 * * * mysqldump -u root -p[password] vegetable_management > /path/to/backup_$(date +\%Y\%m\%d).sql
```

---

## 🎓 เอกสารเพิ่มเติม

- 📖 **DATABASE_GUIDE.md** - คู่มือฐานข้อมูลฉบับสมบูรณ์
- 🌐 **PHP Documentation**: https://www.php.net/docs.php
- 🗄️ **MySQL Documentation**: https://dev.mysql.com/doc/
- 📚 **JavaScript Guide**: https://developer.mozilla.org/

---

## 📞 การติดต่อ

หากพบปัญหาหรือต้องการความช่วยเหลือ:
- 📧 Email: support@vegetable-system.com
- 💬 Forum: https://forum.vegetable-system.com

---

## 📝 สรุป

### **ขั้นตอนการติดตั้งแบบรวดเร็ว:**
1. ✅ วางไฟล์ใน htdocs
2. ✅ แก้ไข `config.php`
3. ✅ รัน `create.php`
4. ✅ ลบ `create.php`
5. ✅ เข้า `index.php`
6. ✅ เริ่มใช้งาน! 🎉

---

**เวอร์ชัน**: 1.0.0  
**วันที่อัปเดต**: 26 ตุลาคม 2024  
**สร้างโดย**: Vegetable Management System Team

**License**: MIT License - ใช้งานได้ฟรี
