<?php
/**
 * ============================================
 * ไฟล์การตั้งค่าการเชื่อมต่อฐานข้อมูล
 * Database Configuration File
 * ============================================
 */

// ตั้งค่าการเชื่อมต่อฐานข้อมูล
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'vegetable_management');

// สร้างการเชื่อมต่อ
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// ตรวจสอบการเชื่อมต่อ
if ($conn->connect_error) {
    die(json_encode([
        'success' => false,
        'message' => 'การเชื่อมต่อฐานข้อมูลล้มเหลว: ' . $conn->connect_error
    ]));
}

// ตั้งค่า charset เป็น UTF-8
$conn->set_charset("utf8mb4");

// ฟังก์ชันสำหรับ escape string
function clean($conn, $data) {
    return $conn->real_escape_string(trim($data));
}

// ฟังก์ชันสร้าง response JSON
function sendResponse($success, $message = '', $data = null) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// ฟังก์ชันสร้างรหัสอัตโนมัติ
function generateVegId($conn) {
    $result = $conn->query("SELECT veg_id FROM vegetables ORDER BY veg_id DESC LIMIT 1");
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $lastId = intval(substr($row['veg_id'], 3));
        return 'VEG' . str_pad($lastId + 1, 3, '0', STR_PAD_LEFT);
    }
    return 'VEG001';
}

function generatePlantId($conn) {
    $result = $conn->query("SELECT plant_id FROM plantings ORDER BY plant_id DESC LIMIT 1");
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $lastId = intval(substr($row['plant_id'], 3));
        return 'PLT' . str_pad($lastId + 1, 3, '0', STR_PAD_LEFT);
    }
    return 'PLT001';
}

function generateCareId($conn) {
    $result = $conn->query("SELECT care_id FROM care_records ORDER BY care_id DESC LIMIT 1");
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $lastId = intval(substr($row['care_id'], 4));
        return 'CARE' . str_pad($lastId + 1, 3, '0', STR_PAD_LEFT);
    }
    return 'CARE001';
}

function generateHarvestId($conn) {
    $result = $conn->query("SELECT harvest_id FROM harvests ORDER BY harvest_id DESC LIMIT 1");
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $lastId = intval(substr($row['harvest_id'], 3));
        return 'HRV' . str_pad($lastId + 1, 3, '0', STR_PAD_LEFT);
    }
    return 'HRV001';
}

function generateSaleId($conn) {
    $result = $conn->query("SELECT sale_id FROM sales ORDER BY sale_id DESC LIMIT 1");
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $lastId = intval(substr($row['sale_id'], 4));
        return 'SALE' . str_pad($lastId + 1, 3, '0', STR_PAD_LEFT);
    }
    return 'SALE001';
}

function getNextCycleNo($conn) {
    $result = $conn->query("SELECT cycle_no FROM planting_cycles ORDER BY cycle_no DESC LIMIT 1");
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['cycle_no'] + 1;
    }
    return 1;
}

function getNextDetailOrder($conn) {
    $result = $conn->query("SELECT detail_id FROM sales_details ORDER BY detail_id DESC LIMIT 1");
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['detail_id'] + 1;
    }
    return 1;
}
?>
