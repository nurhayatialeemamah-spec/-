<?php
// ====== ตั้งค่าการเชื่อมต่อ ======
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'vegetable_management');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

// ====== ลบและสร้างฐานข้อมูลใหม่ ======
$conn->query("DROP DATABASE IF EXISTS " . DB_NAME);
$conn->query("CREATE DATABASE " . DB_NAME . " CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
$conn->select_db(DB_NAME);

// ====== ตาราง vegetables ======
$conn->query("CREATE TABLE vegetables (
    veg_id VARCHAR(10) PRIMARY KEY,
    veg_name VARCHAR(100) NOT NULL,
    duration INT NOT NULL,
    price_per_unit DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ====== ตาราง planting_cycles ======
$conn->query("CREATE TABLE planting_cycles (
    cycle_no INT PRIMARY KEY AUTO_INCREMENT,
    planting_date DATE NOT NULL,
    total_plants INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ====== ตาราง plantings ======
$conn->query("CREATE TABLE plantings (
    plant_id VARCHAR(10) PRIMARY KEY,
    cycle_no INT NOT NULL,
    veg_id VARCHAR(10) NOT NULL,
    quantity INT NOT NULL,
    plot_name VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (cycle_no) REFERENCES planting_cycles(cycle_no) ON DELETE CASCADE,
    FOREIGN KEY (veg_id) REFERENCES vegetables(veg_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ====== ตาราง care_records ======
$conn->query("CREATE TABLE care_records (
    care_id VARCHAR(10) PRIMARY KEY,
    plant_id VARCHAR(10) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    care_round INT NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (plant_id) REFERENCES plantings(plant_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ====== ตาราง harvests ======
$conn->query("CREATE TABLE harvests (
    harvest_id VARCHAR(10) PRIMARY KEY,
    plant_id VARCHAR(10) NOT NULL,
    cycle_no INT NOT NULL,
    harvest_date DATE NOT NULL,
    harvested_amount INT NOT NULL,
    diseased_amount INT DEFAULT 0,
    dead_amount INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (plant_id) REFERENCES plantings(plant_id) ON DELETE CASCADE,
    FOREIGN KEY (cycle_no) REFERENCES planting_cycles(cycle_no) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ====== ตาราง sales ======
$conn->query("CREATE TABLE sales (
    sale_id VARCHAR(10) PRIMARY KEY,
    sale_date DATE NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ====== ตาราง sales_details ======
$conn->query("CREATE TABLE sales_details (
    detail_id INT PRIMARY KEY AUTO_INCREMENT,
    harvest_id VARCHAR(10) NOT NULL,
    sale_id VARCHAR(10) NOT NULL,
    quantity INT NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (harvest_id) REFERENCES harvests(harvest_id) ON DELETE CASCADE,
    FOREIGN KEY (sale_id) REFERENCES sales(sale_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ====== เพิ่มข้อมูลตัวอย่างผัก ======
$vegetables = [
    ['VEG001', 'ผักกาดหอม', 30, 25.00],
    ['VEG002', 'คะน้า', 45, 30.00],
    ['VEG003', 'ผักบุ้ง', 25, 20.00],
    ['VEG004', 'กวางตุ้ง', 35, 28.00],
    ['VEG005', 'ผักชี', 40, 35.00]
];
foreach ($vegetables as $v) {
    $conn->query("INSERT INTO vegetables (veg_id, veg_name, duration, price_per_unit)
                  VALUES ('{$v[0]}', '{$v[1]}', {$v[2]}, {$v[3]})");
}

// ปิดการเชื่อมต่อ
$conn->close();
?>
