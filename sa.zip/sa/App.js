// Data Storage
let vegetables = [];
let plantingCycles = [];
let plantings = [];
let cares = [];
let harvests = [];
let sales = [];
let salesDetails = [];

// Load data from localStorage
function loadData() {
    vegetables = JSON.parse(localStorage.getItem('vegetables') || '[]');
    plantingCycles = JSON.parse(localStorage.getItem('plantingCycles') || '[]');
    plantings = JSON.parse(localStorage.getItem('plantings') || '[]');
    cares = JSON.parse(localStorage.getItem('cares') || '[]');
    harvests = JSON.parse(localStorage.getItem('harvests') || '[]');
    sales = JSON.parse(localStorage.getItem('sales') || '[]');
    salesDetails = JSON.parse(localStorage.getItem('salesDetails') || '[]');
}

// Save data to localStorage
function saveData(key, data) {
    localStorage.setItem(key, JSON.stringify(data));
}

// ==================== AUTO ID GENERATION ====================
function generateVegetableId() {
    const maxId = vegetables.reduce((max, v) => {
        const num = parseInt(v.id.replace('VEG', ''));
        return num > max ? num : max;
    }, 0);
    return 'VEG' + String(maxId + 1).padStart(3, '0');
}

function generateCycleNo() {
    const maxNo = plantingCycles.reduce((max, c) => {
        const num = parseInt(c.cycleNo);
        return num > max ? num : max;
    }, 0);
    return String(maxNo + 1);
}

function generatePlantingId() {
    const maxId = plantings.reduce((max, p) => {
        const num = parseInt(p.id.replace('PLT', ''));
        return num > max ? num : max;
    }, 0);
    return 'PLT' + String(maxId + 1).padStart(3, '0');
}

function generateCareId() {
    const maxId = cares.reduce((max, c) => {
        const num = parseInt(c.id.replace('CARE', ''));
        return num > max ? num : max;
    }, 0);
    return 'CARE' + String(maxId + 1).padStart(3, '0');
}

function generateHarvestId() {
    const maxId = harvests.reduce((max, h) => {
        const num = parseInt(h.id.replace('HRV', ''));
        return num > max ? num : max;
    }, 0);
    return 'HRV' + String(maxId + 1).padStart(3, '0');
}

function generateSaleId() {
    const maxId = sales.reduce((max, s) => {
        const num = parseInt(s.id.replace('SALE', ''));
        return num > max ? num : max;
    }, 0);
    return 'SALE' + String(maxId + 1).padStart(3, '0');
}

function generateDetailOrder() {
    const maxOrder = salesDetails.reduce((max, d) => {
        const num = parseInt(d.order);
        return num > max ? num : max;
    }, 0);
    return String(maxOrder + 1);
}

// Update display fields with next auto ID
function updateAutoIdDisplays() {
    document.getElementById('vegIdDisplay').value = generateVegetableId();
    document.getElementById('cycleNoDisplay').value = generateCycleNo();
    document.getElementById('plantIdDisplay').value = generatePlantingId();
    document.getElementById('careIdDisplay').value = generateCareId();
    document.getElementById('harvestIdDisplay').value = generateHarvestId();
    document.getElementById('saleIdDisplay').value = generateSaleId();
    document.getElementById('detailOrderDisplay').value = generateDetailOrder();
}

// Tab Navigation
function openTab(tabName) {
    const tabs = document.querySelectorAll('.tab-content');
    const buttons = document.querySelectorAll('.tab-btn');
    
    tabs.forEach(tab => tab.classList.remove('active'));
    buttons.forEach(btn => btn.classList.remove('active'));
    
    document.getElementById(tabName).classList.add('active');
    event.target.classList.add('active');
    
    // Update summary when opening summary tab
    if (tabName === 'summary') {
        updateSummary();
    }
}

// ==================== VEGETABLES ====================
function renderVegetables() {
    const tbody = document.getElementById('vegetableTableBody');
    if (vegetables.length === 0) {
        tbody.innerHTML = '<tr class="empty-state"><td colspan="5"><p>ยังไม่มีข้อมูลผัก</p></td></tr>';
        return;
    }
    
    tbody.innerHTML = vegetables.map((v, index) => `
        <tr>
            <td>${v.id}</td>
            <td>${v.name}</td>
            <td>${v.duration}</td>
            <td>${parseFloat(v.price).toFixed(2)}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn btn-edit" onclick="editVegetable(${index})">✏️ แก้ไข</button>
                    <button class="btn btn-delete" onclick="deleteVegetable(${index})">🗑️ ลบ</button>
                </div>
            </td>
        </tr>
    `).join('');
    
    updateVegetableSelects();
}

function editVegetable(index) {
    const veg = vegetables[index];
    document.getElementById('vegId').value = veg.id;
    document.getElementById('vegIdDisplay').value = veg.id;
    document.getElementById('vegName').value = veg.name;
    document.getElementById('vegDuration').value = veg.duration;
    document.getElementById('vegPrice').value = veg.price;
    document.getElementById('vegEditIndex').value = index;
    document.getElementById('vegSubmitBtn').textContent = '💾 บันทึกการแก้ไข';
    document.getElementById('vegCancelBtn').style.display = 'inline-flex';
    
    // Scroll to form
    document.getElementById('vegetables').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function deleteVegetable(index) {
    if (confirm('คุณต้องการลบข้อมูลผักนี้ใช่หรือไม่?')) {
        vegetables.splice(index, 1);
        saveData('vegetables', vegetables);
        renderVegetables();
        updateSummary();
        showAlert('ลบข้อมูลผักสำเร็จ', 'success');
    }
}

function cancelEditVegetable() {
    document.getElementById('vegetableForm').reset();
    document.getElementById('vegEditIndex').value = '';
    document.getElementById('vegSubmitBtn').textContent = '➕ เพิ่มข้อมูลผัก';
    document.getElementById('vegCancelBtn').style.display = 'none';
    updateAutoIdDisplays();
}

// ==================== PLANTING CYCLES ====================
function renderPlantingCycles() {
    const tbody = document.getElementById('plantingCycleTableBody');
    if (plantingCycles.length === 0) {
        tbody.innerHTML = '<tr class="empty-state"><td colspan="4"><p>ยังไม่มีข้อมูลรอบการปลูก</p></td></tr>';
        return;
    }
    
    tbody.innerHTML = plantingCycles.map((c, index) => `
        <tr>
            <td>${c.cycleNo}</td>
            <td>${c.date}</td>
            <td>${c.amount}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn btn-edit" onclick="editCycle(${index})">✏️ แก้ไข</button>
                    <button class="btn btn-delete" onclick="deleteCycle(${index})">🗑️ ลบ</button>
                </div>
            </td>
        </tr>
    `).join('');
}

function editCycle(index) {
    const cycle = plantingCycles[index];
    document.getElementById('cycleNo').value = cycle.cycleNo;
    document.getElementById('cycleNoDisplay').value = cycle.cycleNo;
    document.getElementById('cycleDate').value = cycle.date;
    document.getElementById('cycleAmount').value = cycle.amount;
    document.getElementById('cycleEditIndex').value = index;
    document.getElementById('cycleSubmitBtn').textContent = '💾 บันทึกการแก้ไข';
    document.getElementById('cycleCancelBtn').style.display = 'inline-flex';
    
    document.getElementById('plantingCycles').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function deleteCycle(index) {
    if (confirm('คุณต้องการลบรอบการปลูกนี้ใช่หรือไม่?')) {
        plantingCycles.splice(index, 1);
        saveData('plantingCycles', plantingCycles);
        renderPlantingCycles();
        updateSummary();
        updateAutoIdDisplays();
        showAlert('ลบรอบการปลูกสำเร็จ', 'success');
    }
}

function cancelEditCycle() {
    document.getElementById('plantingCycleForm').reset();
    document.getElementById('cycleEditIndex').value = '';
    document.getElementById('cycleSubmitBtn').textContent = '➕ เพิ่มรอบการปลูก';
    document.getElementById('cycleCancelBtn').style.display = 'none';
    updateAutoIdDisplays();
}

// ==================== PLANTING ====================
function renderPlantings() {
    const tbody = document.getElementById('plantingTableBody');
    if (plantings.length === 0) {
        tbody.innerHTML = '<tr class="empty-state"><td colspan="6"><p>ยังไม่มีข้อมูลการปลูก</p></td></tr>';
        return;
    }
    
    tbody.innerHTML = plantings.map((p, index) => `
        <tr>
            <td>${p.id}</td>
            <td>${p.cycleNo}</td>
            <td>${p.vegId}</td>
            <td>${p.quantity}</td>
            <td>${p.plot}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn btn-edit" onclick="editPlanting(${index})">✏️ แก้ไข</button>
                    <button class="btn btn-delete" onclick="deletePlanting(${index})">🗑️ ลบ</button>
                </div>
            </td>
        </tr>
    `).join('');
    
    updatePlantingSelects();
}

function editPlanting(index) {
    const planting = plantings[index];
    document.getElementById('plantId').value = planting.id;
    document.getElementById('plantIdDisplay').value = planting.id;
    document.getElementById('plantCycleNo').value = planting.cycleNo;
    document.getElementById('plantVegId').value = planting.vegId;
    document.getElementById('plantQuantity').value = planting.quantity;
    document.getElementById('plantPlot').value = planting.plot;
    document.getElementById('plantEditIndex').value = index;
    document.getElementById('plantSubmitBtn').textContent = '💾 บันทึกการแก้ไข';
    document.getElementById('plantCancelBtn').style.display = 'inline-flex';
    
    document.getElementById('planting').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function deletePlanting(index) {
    if (confirm('คุณต้องการลบข้อมูลการปลูกนี้ใช่หรือไม่?')) {
        plantings.splice(index, 1);
        saveData('plantings', plantings);
        renderPlantings();
        updateSummary();
        updateAutoIdDisplays();
        showAlert('ลบข้อมูลการปลูกสำเร็จ', 'success');
    }
}

function cancelEditPlanting() {
    document.getElementById('plantingForm').reset();
    document.getElementById('plantEditIndex').value = '';
    document.getElementById('plantSubmitBtn').textContent = '➕ เพิ่มข้อมูลการปลูก';
    document.getElementById('plantCancelBtn').style.display = 'none';
    updateAutoIdDisplays();
}

// ==================== CARE ====================
function renderCares() {
    const tbody = document.getElementById('careTableBody');
    if (cares.length === 0) {
        tbody.innerHTML = '<tr class="empty-state"><td colspan="7"><p>ยังไม่มีข้อมูลการดูแล</p></td></tr>';
        return;
    }
    
    tbody.innerHTML = cares.map((c, index) => `
        <tr>
            <td>${c.id}</td>
            <td>${c.plantId}</td>
            <td>${c.startDate}</td>
            <td>${c.endDate}</td>
            <td>${c.cycle}</td>
            <td>${c.note || '-'}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn btn-edit" onclick="editCare(${index})">✏️ แก้ไข</button>
                    <button class="btn btn-delete" onclick="deleteCare(${index})">🗑️ ลบ</button>
                </div>
            </td>
        </tr>
    `).join('');
}

function editCare(index) {
    const care = cares[index];
    document.getElementById('careId').value = care.id;
    document.getElementById('careIdDisplay').value = care.id;
    document.getElementById('carePlantId').value = care.plantId;
    document.getElementById('careStartDate').value = care.startDate;
    document.getElementById('careEndDate').value = care.endDate;
    document.getElementById('careCycle').value = care.cycle;
    document.getElementById('careNote').value = care.note || '';
    document.getElementById('careEditIndex').value = index;
    document.getElementById('careSubmitBtn').textContent = '💾 บันทึกการแก้ไข';
    document.getElementById('careCancelBtn').style.display = 'inline-flex';
    
    document.getElementById('care').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function deleteCare(index) {
    if (confirm('คุณต้องการลบข้อมูลการดูแลนี้ใช่หรือไม่?')) {
        cares.splice(index, 1);
        saveData('cares', cares);
        renderCares();
        updateSummary();
        updateAutoIdDisplays();
        showAlert('ลบข้อมูลการดูแลสำเร็จ', 'success');
    }
}

function cancelEditCare() {
    document.getElementById('careForm').reset();
    document.getElementById('careEditIndex').value = '';
    document.getElementById('careSubmitBtn').textContent = '➕ เพิ่มข้อมูลการดูแล';
    document.getElementById('careCancelBtn').style.display = 'none';
    updateAutoIdDisplays();
}

// ==================== HARVEST ====================
function renderHarvests() {
    const tbody = document.getElementById('harvestTableBody');
    if (harvests.length === 0) {
        tbody.innerHTML = '<tr class="empty-state"><td colspan="8"><p>ยังไม่มีข้อมูลการเก็บเกี่ยว</p></td></tr>';
        return;
    }
    
    tbody.innerHTML = harvests.map((h, index) => `
        <tr>
            <td>${h.id}</td>
            <td>${h.plantId}</td>
            <td>${h.cycleNo}</td>
            <td>${h.date}</td>
            <td>${h.amount}</td>
            <td>${h.disease}</td>
            <td>${h.dead}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn btn-edit" onclick="editHarvest(${index})">✏️ แก้ไข</button>
                    <button class="btn btn-delete" onclick="deleteHarvest(${index})">🗑️ ลบ</button>
                </div>
            </td>
        </tr>
    `).join('');
    
    updateHarvestSelects();
}

function editHarvest(index) {
    const harvest = harvests[index];
    document.getElementById('harvestId').value = harvest.id;
    document.getElementById('harvestIdDisplay').value = harvest.id;
    document.getElementById('harvestPlantId').value = harvest.plantId;
    document.getElementById('harvestCycleNo').value = harvest.cycleNo;
    document.getElementById('harvestDate').value = harvest.date;
    document.getElementById('harvestAmount').value = harvest.amount;
    document.getElementById('harvestDisease').value = harvest.disease;
    document.getElementById('harvestDead').value = harvest.dead;
    document.getElementById('harvestEditIndex').value = index;
    document.getElementById('harvestSubmitBtn').textContent = '💾 บันทึกการแก้ไข';
    document.getElementById('harvestCancelBtn').style.display = 'inline-flex';
    
    document.getElementById('harvest').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function deleteHarvest(index) {
    if (confirm('คุณต้องการลบข้อมูลการเก็บเกี่ยวนี้ใช่หรือไม่?')) {
        harvests.splice(index, 1);
        saveData('harvests', harvests);
        renderHarvests();
        updateSummary();
        updateAutoIdDisplays();
        showAlert('ลบข้อมูลการเก็บเกี่ยวสำเร็จ', 'success');
    }
}

function cancelEditHarvest() {
    document.getElementById('harvestForm').reset();
    document.getElementById('harvestEditIndex').value = '';
    document.getElementById('harvestSubmitBtn').textContent = '➕ เพิ่มข้อมูลการเก็บเกี่ยว';
    document.getElementById('harvestCancelBtn').style.display = 'none';
    updateAutoIdDisplays();
}

// ==================== SALES ====================
function renderSales() {
    const tbody = document.getElementById('salesTableBody');
    if (sales.length === 0) {
        tbody.innerHTML = '<tr class="empty-state"><td colspan="4"><p>ยังไม่มีข้อมูลการขาย</p></td></tr>';
        return;
    }
    
    tbody.innerHTML = sales.map((s, index) => `
        <tr>
            <td>${s.id}</td>
            <td>${s.date}</td>
            <td>${parseFloat(s.amount).toFixed(2)}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn btn-edit" onclick="editSale(${index})">✏️ แก้ไข</button>
                    <button class="btn btn-delete" onclick="deleteSale(${index})">🗑️ ลบ</button>
                </div>
            </td>
        </tr>
    `).join('');
    
    updateSalesSelects();
}

function editSale(index) {
    const sale = sales[index];
    document.getElementById('saleId').value = sale.id;
    document.getElementById('saleIdDisplay').value = sale.id;
    document.getElementById('saleDate').value = sale.date;
    document.getElementById('saleAmount').value = sale.amount;
    document.getElementById('saleEditIndex').value = index;
    document.getElementById('saleSubmitBtn').textContent = '💾 บันทึกการแก้ไข';
    document.getElementById('saleCancelBtn').style.display = 'inline-flex';
    
    document.getElementById('sales').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function deleteSale(index) {
    if (confirm('คุณต้องการลบข้อมูลการขายนี้ใช่หรือไม่?')) {
        sales.splice(index, 1);
        saveData('sales', sales);
        renderSales();
        updateSummary();
        updateAutoIdDisplays();
        showAlert('ลบข้อมูลการขายสำเร็จ', 'success');
    }
}

function cancelEditSale() {
    document.getElementById('salesForm').reset();
    document.getElementById('saleEditIndex').value = '';
    document.getElementById('saleSubmitBtn').textContent = '➕ เพิ่มข้อมูลการขาย';
    document.getElementById('saleCancelBtn').style.display = 'none';
    updateAutoIdDisplays();
}

// ==================== SALES DETAILS ====================
function renderSalesDetails() {
    const tbody = document.getElementById('salesDetailTableBody');
    if (salesDetails.length === 0) {
        tbody.innerHTML = '<tr class="empty-state"><td colspan="6"><p>ยังไม่มีรายละเอียดการขาย</p></td></tr>';
        return;
    }
    
    tbody.innerHTML = salesDetails.map((d, index) => `
        <tr>
            <td>${d.order}</td>
            <td>${d.harvestId}</td>
            <td>${d.saleId}</td>
            <td>${d.quantity}</td>
            <td>${parseFloat(d.total).toFixed(2)}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn btn-edit" onclick="editDetail(${index})">✏️ แก้ไข</button>
                    <button class="btn btn-delete" onclick="deleteDetail(${index})">🗑️ ลบ</button>
                </div>
            </td>
        </tr>
    `).join('');
}

function editDetail(index) {
    const detail = salesDetails[index];
    document.getElementById('detailOrder').value = detail.order;
    document.getElementById('detailOrderDisplay').value = detail.order;
    document.getElementById('detailHarvestId').value = detail.harvestId;
    document.getElementById('detailSaleId').value = detail.saleId;
    document.getElementById('detailQuantity').value = detail.quantity;
    document.getElementById('detailTotal').value = detail.total;
    document.getElementById('detailEditIndex').value = index;
    document.getElementById('detailSubmitBtn').textContent = '💾 บันทึกการแก้ไข';
    document.getElementById('detailCancelBtn').style.display = 'inline-flex';
    
    document.getElementById('salesDetails').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function deleteDetail(index) {
    if (confirm('คุณต้องการลบรายละเอียดการขายนี้ใช่หรือไม่?')) {
        salesDetails.splice(index, 1);
        saveData('salesDetails', salesDetails);
        renderSalesDetails();
        updateSummary();
        updateAutoIdDisplays();
        showAlert('ลบรายละเอียดการขายสำเร็จ', 'success');
    }
}

function cancelEditDetail() {
    document.getElementById('salesDetailForm').reset();
    document.getElementById('detailEditIndex').value = '';
    document.getElementById('detailSubmitBtn').textContent = '➕ เพิ่มรายละเอียดการขาย';
    document.getElementById('detailCancelBtn').style.display = 'none';
    updateAutoIdDisplays();
}

// ==================== UPDATE SELECTS ====================
function updateVegetableSelects() {
    const select = document.getElementById('plantVegId');
    select.innerHTML = '<option value="">-- เลือกผัก --</option>' +
        vegetables.map(v => `<option value="${v.id}">${v.id} - ${v.name}</option>`).join('');
}

function updatePlantingSelects() {
    const careSelect = document.getElementById('carePlantId');
    const harvestSelect = document.getElementById('harvestPlantId');
    
    const options = '<option value="">-- เลือกการปลูก --</option>' +
        plantings.map(p => `<option value="${p.id}">${p.id} - รอบที่ ${p.cycleNo}</option>`).join('');
    
    careSelect.innerHTML = options;
    harvestSelect.innerHTML = options;
}

function updateHarvestSelects() {
    const select = document.getElementById('detailHarvestId');
    select.innerHTML = '<option value="">-- เลือกการเก็บเกี่ยว --</option>' +
        harvests.map(h => `<option value="${h.id}">${h.id} - ${h.date}</option>`).join('');
}

function updateSalesSelects() {
    const select = document.getElementById('detailSaleId');
    select.innerHTML = '<option value="">-- เลือกการขาย --</option>' +
        sales.map(s => `<option value="${s.id}">${s.id} - ${s.date}</option>`).join('');
}

// ==================== SEARCH FUNCTIONS ====================
function searchTable(searchId, data, renderFunction) {
    const searchInput = document.getElementById(searchId);
    if (!searchInput) return;
    
    searchInput.addEventListener('input', function(e) {
        const searchTerm = e.target.value.toLowerCase();
        
        if (searchTerm === '') {
            renderFunction();
            return;
        }
        
        const filtered = data.filter(item => {
            return Object.values(item).some(value => 
                String(value).toLowerCase().includes(searchTerm)
            );
        });
        
        renderFilteredData(searchId, filtered);
    });
}

function renderFilteredData(searchId, filteredData) {
    let tbody, colspan;
    
    switch(searchId) {
        case 'searchVegetable':
            tbody = document.getElementById('vegetableTableBody');
            colspan = 5;
            if (filteredData.length === 0) {
                tbody.innerHTML = `<tr class="empty-state"><td colspan="${colspan}"><p>ไม่พบข้อมูลที่ค้นหา</p></td></tr>`;
                return;
            }
            tbody.innerHTML = filteredData.map((v, index) => `
                <tr>
                    <td>${v.id}</td>
                    <td>${v.name}</td>
                    <td>${v.duration}</td>
                    <td>${parseFloat(v.price).toFixed(2)}</td>
                    <td>
                        <div class="action-buttons">
                            <button class="btn btn-edit" onclick="editVegetable(${vegetables.indexOf(v)})">✏️ แก้ไข</button>
                            <button class="btn btn-delete" onclick="deleteVegetable(${vegetables.indexOf(v)})">🗑️ ลบ</button>
                        </div>
                    </td>
                </tr>
            `).join('');
            break;
            
        case 'searchCycle':
            tbody = document.getElementById('plantingCycleTableBody');
            colspan = 4;
            if (filteredData.length === 0) {
                tbody.innerHTML = `<tr class="empty-state"><td colspan="${colspan}"><p>ไม่พบข้อมูลที่ค้นหา</p></td></tr>`;
                return;
            }
            tbody.innerHTML = filteredData.map((c) => `
                <tr>
                    <td>${c.cycleNo}</td>
                    <td>${c.date}</td>
                    <td>${c.amount}</td>
                    <td>
                        <div class="action-buttons">
                            <button class="btn btn-edit" onclick="editCycle(${plantingCycles.indexOf(c)})">✏️ แก้ไข</button>
                            <button class="btn btn-delete" onclick="deleteCycle(${plantingCycles.indexOf(c)})">🗑️ ลบ</button>
                        </div>
                    </td>
                </tr>
            `).join('');
            break;
            
        case 'searchPlanting':
            tbody = document.getElementById('plantingTableBody');
            colspan = 6;
            if (filteredData.length === 0) {
                tbody.innerHTML = `<tr class="empty-state"><td colspan="${colspan}"><p>ไม่พบข้อมูลที่ค้นหา</p></td></tr>`;
                return;
            }
            tbody.innerHTML = filteredData.map((p) => `
                <tr>
                    <td>${p.id}</td>
                    <td>${p.cycleNo}</td>
                    <td>${p.vegId}</td>
                    <td>${p.quantity}</td>
                    <td>${p.plot}</td>
                    <td>
                        <div class="action-buttons">
                            <button class="btn btn-edit" onclick="editPlanting(${plantings.indexOf(p)})">✏️ แก้ไข</button>
                            <button class="btn btn-delete" onclick="deletePlanting(${plantings.indexOf(p)})">🗑️ ลบ</button>
                        </div>
                    </td>
                </tr>
            `).join('');
            break;
            
        case 'searchCare':
            tbody = document.getElementById('careTableBody');
            colspan = 7;
            if (filteredData.length === 0) {
                tbody.innerHTML = `<tr class="empty-state"><td colspan="${colspan}"><p>ไม่พบข้อมูลที่ค้นหา</p></td></tr>`;
                return;
            }
            tbody.innerHTML = filteredData.map((c) => `
                <tr>
                    <td>${c.id}</td>
                    <td>${c.plantId}</td>
                    <td>${c.startDate}</td>
                    <td>${c.endDate}</td>
                    <td>${c.cycle}</td>
                    <td>${c.note || '-'}</td>
                    <td>
                        <div class="action-buttons">
                            <button class="btn btn-edit" onclick="editCare(${cares.indexOf(c)})">✏️ แก้ไข</button>
                            <button class="btn btn-delete" onclick="deleteCare(${cares.indexOf(c)})">🗑️ ลบ</button>
                        </div>
                    </td>
                </tr>
            `).join('');
            break;
            
        case 'searchHarvest':
            tbody = document.getElementById('harvestTableBody');
            colspan = 8;
            if (filteredData.length === 0) {
                tbody.innerHTML = `<tr class="empty-state"><td colspan="${colspan}"><p>ไม่พบข้อมูลที่ค้นหา</p></td></tr>`;
                return;
            }
            tbody.innerHTML = filteredData.map((h) => `
                <tr>
                    <td>${h.id}</td>
                    <td>${h.plantId}</td>
                    <td>${h.cycleNo}</td>
                    <td>${h.date}</td>
                    <td>${h.amount}</td>
                    <td>${h.disease}</td>
                    <td>${h.dead}</td>
                    <td>
                        <div class="action-buttons">
                            <button class="btn btn-edit" onclick="editHarvest(${harvests.indexOf(h)})">✏️ แก้ไข</button>
                            <button class="btn btn-delete" onclick="deleteHarvest(${harvests.indexOf(h)})">🗑️ ลบ</button>
                        </div>
                    </td>
                </tr>
            `).join('');
            break;
            
        case 'searchSales':
            tbody = document.getElementById('salesTableBody');
            colspan = 4;
            if (filteredData.length === 0) {
                tbody.innerHTML = `<tr class="empty-state"><td colspan="${colspan}"><p>ไม่พบข้อมูลที่ค้นหา</p></td></tr>`;
                return;
            }
            tbody.innerHTML = filteredData.map((s) => `
                <tr>
                    <td>${s.id}</td>
                    <td>${s.date}</td>
                    <td>${parseFloat(s.amount).toFixed(2)}</td>
                    <td>
                        <div class="action-buttons">
                            <button class="btn btn-edit" onclick="editSale(${sales.indexOf(s)})">✏️ แก้ไข</button>
                            <button class="btn btn-delete" onclick="deleteSale(${sales.indexOf(s)})">🗑️ ลบ</button>
                        </div>
                    </td>
                </tr>
            `).join('');
            break;
            
        case 'searchSalesDetail':
            tbody = document.getElementById('salesDetailTableBody');
            colspan = 6;
            if (filteredData.length === 0) {
                tbody.innerHTML = `<tr class="empty-state"><td colspan="${colspan}"><p>ไม่พบข้อมูลที่ค้นหา</p></td></tr>`;
                return;
            }
            tbody.innerHTML = filteredData.map((d) => `
                <tr>
                    <td>${d.order}</td>
                    <td>${d.harvestId}</td>
                    <td>${d.saleId}</td>
                    <td>${d.quantity}</td>
                    <td>${parseFloat(d.total).toFixed(2)}</td>
                    <td>
                        <div class="action-buttons">
                            <button class="btn btn-edit" onclick="editDetail(${salesDetails.indexOf(d)})">✏️ แก้ไข</button>
                            <button class="btn btn-delete" onclick="deleteDetail(${salesDetails.indexOf(d)})">🗑️ ลบ</button>
                        </div>
                    </td>
                </tr>
            `).join('');
            break;
    }
}

// ==================== FORM HANDLERS ====================
document.getElementById('vegetableForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const editIndex = document.getElementById('vegEditIndex').value;
    
    const veg = {
        id: editIndex !== '' ? document.getElementById('vegId').value : generateVegetableId(),
        name: document.getElementById('vegName').value,
        duration: document.getElementById('vegDuration').value,
        price: document.getElementById('vegPrice').value
    };
    
    if (editIndex !== '') {
        vegetables[editIndex] = veg;
        showAlert('แก้ไขข้อมูลผักสำเร็จ', 'success');
        cancelEditVegetable();
    } else {
        vegetables.push(veg);
        showAlert('เพิ่มข้อมูลผักสำเร็จ', 'success');
        this.reset();
    }
    
    saveData('vegetables', vegetables);
    renderVegetables();
    updateSummary();
    updateAutoIdDisplays();
});

document.getElementById('plantingCycleForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const editIndex = document.getElementById('cycleEditIndex').value;
    
    const cycle = {
        cycleNo: editIndex !== '' ? document.getElementById('cycleNo').value : generateCycleNo(),
        date: document.getElementById('cycleDate').value,
        amount: document.getElementById('cycleAmount').value
    };
    
    if (editIndex !== '') {
        plantingCycles[editIndex] = cycle;
        showAlert('แก้ไขรอบการปลูกสำเร็จ', 'success');
        cancelEditCycle();
    } else {
        plantingCycles.push(cycle);
        showAlert('เพิ่มรอบการปลูกสำเร็จ', 'success');
        this.reset();
    }
    
    saveData('plantingCycles', plantingCycles);
    renderPlantingCycles();
    updateSummary();
    updateAutoIdDisplays();
});

document.getElementById('plantingForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const editIndex = document.getElementById('plantEditIndex').value;
    
    const planting = {
        id: editIndex !== '' ? document.getElementById('plantId').value : generatePlantingId(),
        cycleNo: document.getElementById('plantCycleNo').value,
        vegId: document.getElementById('plantVegId').value,
        quantity: document.getElementById('plantQuantity').value,
        plot: document.getElementById('plantPlot').value
    };
    
    if (editIndex !== '') {
        plantings[editIndex] = planting;
        showAlert('แก้ไขข้อมูลการปลูกสำเร็จ', 'success');
        cancelEditPlanting();
    } else {
        plantings.push(planting);
        showAlert('เพิ่มข้อมูลการปลูกสำเร็จ', 'success');
        this.reset();
    }
    
    saveData('plantings', plantings);
    renderPlantings();
    updateSummary();
    updateAutoIdDisplays();
});

document.getElementById('careForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const editIndex = document.getElementById('careEditIndex').value;
    
    const care = {
        id: editIndex !== '' ? document.getElementById('careId').value : generateCareId(),
        plantId: document.getElementById('carePlantId').value,
        startDate: document.getElementById('careStartDate').value,
        endDate: document.getElementById('careEndDate').value,
        cycle: document.getElementById('careCycle').value,
        note: document.getElementById('careNote').value
    };
    
    if (editIndex !== '') {
        cares[editIndex] = care;
        showAlert('แก้ไขข้อมูลการดูแลสำเร็จ', 'success');
        cancelEditCare();
    } else {
        cares.push(care);
        showAlert('เพิ่มข้อมูลการดูแลสำเร็จ', 'success');
        this.reset();
    }
    
    saveData('cares', cares);
    renderCares();
    updateSummary();
    updateAutoIdDisplays();
});

document.getElementById('harvestForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const editIndex = document.getElementById('harvestEditIndex').value;
    
    const harvest = {
        id: editIndex !== '' ? document.getElementById('harvestId').value : generateHarvestId(),
        plantId: document.getElementById('harvestPlantId').value,
        cycleNo: document.getElementById('harvestCycleNo').value,
        date: document.getElementById('harvestDate').value,
        amount: document.getElementById('harvestAmount').value,
        disease: document.getElementById('harvestDisease').value,
        dead: document.getElementById('harvestDead').value
    };
    
    if (editIndex !== '') {
        harvests[editIndex] = harvest;
        showAlert('แก้ไขข้อมูลการเก็บเกี่ยวสำเร็จ', 'success');
        cancelEditHarvest();
    } else {
        harvests.push(harvest);
        showAlert('เพิ่มข้อมูลการเก็บเกี่ยวสำเร็จ', 'success');
        this.reset();
    }
    
    saveData('harvests', harvests);
    renderHarvests();
    updateSummary();
    updateAutoIdDisplays();
});

document.getElementById('salesForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const editIndex = document.getElementById('saleEditIndex').value;
    
    const sale = {
        id: editIndex !== '' ? document.getElementById('saleId').value : generateSaleId(),
        date: document.getElementById('saleDate').value,
        amount: document.getElementById('saleAmount').value
    };
    
    if (editIndex !== '') {
        sales[editIndex] = sale;
        showAlert('แก้ไขข้อมูลการขายสำเร็จ', 'success');
        cancelEditSale();
    } else {
        sales.push(sale);
        showAlert('เพิ่มข้อมูลการขายสำเร็จ', 'success');
        this.reset();
    }
    
    saveData('sales', sales);
    renderSales();
    updateSummary();
    updateAutoIdDisplays();
});

document.getElementById('salesDetailForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const editIndex = document.getElementById('detailEditIndex').value;
    
    const detail = {
        order: editIndex !== '' ? document.getElementById('detailOrder').value : generateDetailOrder(),
        harvestId: document.getElementById('detailHarvestId').value,
        saleId: document.getElementById('detailSaleId').value,
        quantity: document.getElementById('detailQuantity').value,
        total: document.getElementById('detailTotal').value
    };
    
    if (editIndex !== '') {
        salesDetails[editIndex] = detail;
        showAlert('แก้ไขรายละเอียดการขายสำเร็จ', 'success');
        cancelEditDetail();
    } else {
        salesDetails.push(detail);
        showAlert('เพิ่มรายละเอียดการขายสำเร็จ', 'success');
        this.reset();
    }
    
    saveData('salesDetails', salesDetails);
    renderSalesDetails();
    updateSummary();
    updateAutoIdDisplays();
});

// ==================== ALERT FUNCTION ====================
function showAlert(message, type = 'success') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.innerHTML = `${type === 'success' ? '✅' : '❌'} ${message}`;
    
    const activeTab = document.querySelector('.tab-content.active');
    activeTab.insertBefore(alertDiv, activeTab.firstChild);
    
    setTimeout(() => alertDiv.remove(), 3000);
}

// ==================== SUMMARY FUNCTIONS ====================
function updateSummary() {
    // Basic counts
    document.getElementById('totalVegetables').textContent = vegetables.length;
    document.getElementById('totalCycles').textContent = plantingCycles.length;
    document.getElementById('totalPlantings').textContent = plantings.length;
    document.getElementById('totalCares').textContent = cares.length;
    
    // Harvest summary
    document.getElementById('totalHarvests').textContent = harvests.length;
    const totalHarvestAmount = harvests.reduce((sum, h) => sum + parseInt(h.amount || 0), 0);
    const totalDisease = harvests.reduce((sum, h) => sum + parseInt(h.disease || 0), 0);
    const totalDead = harvests.reduce((sum, h) => sum + parseInt(h.dead || 0), 0);
    
    document.getElementById('totalHarvestAmount').textContent = totalHarvestAmount;
    document.getElementById('totalDisease').textContent = totalDisease;
    document.getElementById('totalDead').textContent = totalDead;
    
    // Sales summary
    document.getElementById('totalSalesCount').textContent = sales.length;
    const totalSalesAmount = sales.reduce((sum, s) => sum + parseFloat(s.amount || 0), 0);
    document.getElementById('totalSalesAmount').textContent = totalSalesAmount.toFixed(2);
    document.getElementById('totalSalesDetails').textContent = salesDetails.length;
    
    // Recent activities
    if (harvests.length > 0) {
        const latest = harvests[harvests.length - 1];
        document.getElementById('latestHarvestText').textContent = 
            `รหัส ${latest.id} - เก็บได้ ${latest.amount} วันที่ ${latest.date}`;
    }
    
    if (sales.length > 0) {
        const latest = sales[sales.length - 1];
        document.getElementById('latestSaleText').textContent = 
            `รหัส ${latest.id} - ยอด ${parseFloat(latest.amount).toFixed(2)} บาท วันที่ ${latest.date}`;
    }
    
    if (cares.length > 0) {
        const latest = cares[cares.length - 1];
        document.getElementById('latestCareText').textContent = 
            `รหัส ${latest.id} - ครั้งที่ ${latest.cycle} (${latest.startDate} - ${latest.endDate})`;
    }
}

// ==================== INITIALIZE ====================
loadData();
renderVegetables();
renderPlantingCycles();
renderPlantings();
renderCares();
renderHarvests();
renderSales();
renderSalesDetails();

// Initialize search functions
searchTable('searchVegetable', vegetables, renderVegetables);
searchTable('searchCycle', plantingCycles, renderPlantingCycles);
searchTable('searchPlanting', plantings, renderPlantings);
searchTable('searchCare', cares, renderCares);
searchTable('searchHarvest', harvests, renderHarvests);
searchTable('searchSales', sales, renderSales);
searchTable('searchSalesDetail', salesDetails, renderSalesDetails);

// Update summary and auto IDs
updateSummary();
updateAutoIdDisplays();
// โหลดข้อมูลผัก
async function loadVegetables() {
    const res = await fetch("api/vegetables.php");
    const data = await res.json();
    const tbody = document.getElementById("vegetableTableBody");
    tbody.innerHTML = "";

    if (data.length === 0) {
        tbody.innerHTML = `<tr class="empty-state"><td colspan="5">ยังไม่มีข้อมูลผัก</td></tr>`;
        return;
    }

    data.forEach(v => {
        const row = `
            <tr>
                <td>${v.veg_id}</td>
                <td>${v.veg_name}</td>
                <td>${v.veg_duration}</td>
                <td>${v.veg_price}</td>
                <td style="text-align:center;">
                    <button onclick="editVegetable('${v.veg_id}')">✏ แก้ไข</button>
                    <button onclick="deleteVegetable('${v.veg_id}')">🗑 ลบ</button>
                </td>
            </tr>
        `;
        tbody.innerHTML += row;
    });
}

// เพิ่มข้อมูลผัก
document.getElementById("vegetableForm").addEventListener("submit", async e => {
    e.preventDefault();
    const name = document.getElementById("vegName").value;
    const duration = document.getElementById("vegDuration").value;
    const price = document.getElementById("vegPrice").value;

    const res = await fetch("api/vegetables.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ veg_name: name, veg_duration: duration, veg_price: price })
    });

    const result = await res.json();
    alert(result.message);
    loadVegetables();
    e.target.reset();
});

// ลบข้อมูล
async function deleteVegetable(id) {
    if (!confirm("ยืนยันการลบข้อมูลนี้?")) return;
    const res = await fetch("api/vegetables.php", {
        method: "DELETE",
        body: `veg_id=${id}`
    });
    const result = await res.json();
    alert(result.message);
    loadVegetables();
}

// เริ่มโหลดตอนเปิดหน้า
document.addEventListener("DOMContentLoaded", loadVegetables);