<?php
header('Content-Type: application/json');
require_once "config.php";

$action = $_POST['action'] ?? '';

if ($action === 'add') {
    $name = $_POST['vegName'];
    $duration = $_POST['vegDuration'];
    $price = $_POST['vegPrice'];

    $result = $conn->query("SELECT veg_id FROM vegetables ORDER BY veg_id DESC LIMIT 1");
    $nextId = 'VEG001';
    if ($result->num_rows > 0) {
        $lastId = $result->fetch_assoc()['veg_id'];
        $num = intval(substr($lastId, 3)) + 1;
        $nextId = 'VEG' . str_pad($num, 3, '0', STR_PAD_LEFT);
    }

    $stmt = $conn->prepare("INSERT INTO vegetables (veg_id, veg_name, duration, price_per_unit) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssid", $nextId, $name, $duration, $price);
    $ok = $stmt->execute();

    echo json_encode(['success' => $ok, 'veg_id' => $nextId]);
}

elseif ($action === 'get_all') {
    $data = [];
    $res = $conn->query("SELECT * FROM vegetables ORDER BY veg_id");
    while ($row = $res->fetch_assoc()) $data[] = $row;
    echo json_encode($data);
}

elseif ($action === 'delete') {
    $veg_id = $_POST['veg_id'];
    $ok = $conn->query("DELETE FROM vegetables WHERE veg_id='$veg_id'");
    echo json_encode(['success' => $ok]);
}

$conn->close();
?>
