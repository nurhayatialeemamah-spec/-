<?php
header('Content-Type: application/json');
require_once "config.php";

$action = $_POST['action'] ?? '';

if ($action === 'add') {
    $cycle = $_POST['cycle_no'];
    $veg = $_POST['veg_id'];
    $qty = $_POST['quantity'];
    $plot = $_POST['plot_name'];

    $res = $conn->query("SELECT plant_id FROM plantings ORDER BY plant_id DESC LIMIT 1");
    $next = 'PL001';
    if ($res->num_rows > 0) {
        $last = $res->fetch_assoc()['plant_id'];
        $num = intval(substr($last, 2)) + 1;
        $next = 'PL' . str_pad($num, 3, '0', STR_PAD_LEFT);
    }

    $stmt = $conn->prepare("INSERT INTO plantings (plant_id, cycle_no, veg_id, quantity, plot_name)
                            VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sisds", $next, $cycle, $veg, $qty, $plot);
    $ok = $stmt->execute();

    echo json_encode(['success' => $ok, 'plant_id' => $next]);
}

elseif ($action === 'get_all') {
    $data = [];
    $sql = "SELECT p.*, v.veg_name FROM plantings p
            JOIN vegetables v ON p.veg_id=v.veg_id
            ORDER BY p.plant_id DESC";
    $res = $conn->query($sql);
    while ($row = $res->fetch_assoc()) $data[] = $row;
    echo json_encode($data);
}

$conn->close();
?>
