<?php
header('Content-Type: application/json');
require_once "config.php";

$action = $_POST['action'] ?? '';

if ($action === 'add') {
    $harvest_id = $_POST['harvest_id'];
    $sale_id = $_POST['sale_id'];
    $qty = $_POST['quantity'];
    $subtotal = $_POST['subtotal'];

    $stmt = $conn->prepare("INSERT INTO sales_details (harvest_id, sale_id, quantity, subtotal)
                            VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssid", $harvest_id, $sale_id, $qty, $subtotal);
    $ok = $stmt->execute();
    echo json_encode(['success' => $ok]);
}

elseif ($action === 'get_all') {
    $data = [];
    $sql = "SELECT sd.*, s.sale_date, h.harvest_date 
            FROM sales_details sd 
            JOIN sales s ON sd.sale_id=s.sale_id 
            JOIN harvests h ON sd.harvest_id=h.harvest_id
            ORDER BY detail_id DESC";
    $res = $conn->query($sql);
    while ($row = $res->fetch_assoc()) $data[] = $row;
    echo json_encode($data);
}

$conn->close();
?>
