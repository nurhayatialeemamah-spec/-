<?php
header('Content-Type: application/json');
require_once "config.php";

$action = $_POST['action'] ?? '';

if ($action === 'add') {
    $plant = $_POST['plant_id'];
    $start = $_POST['start_date'];
    $end = $_POST['end_date'];
    $round = $_POST['care_round'];
    $notes = $_POST['notes'];

    $res = $conn->query("SELECT care_id FROM care_records ORDER BY care_id DESC LIMIT 1");
    $next = 'CR001';
    if ($res->num_rows > 0) {
        $last = $res->fetch_assoc()['care_id'];
        $num = intval(substr($last, 2)) + 1;
        $next = 'CR' . str_pad($num, 3, '0', STR_PAD_LEFT);
    }

    $stmt = $conn->prepare("INSERT INTO care_records (care_id, plant_id, start_date, end_date, care_round, notes)
                            VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $next, $plant, $start, $end, $round, $notes);
    $ok = $stmt->execute();
    echo json_encode(['success' => $ok]);
}

elseif ($action === 'get_all') {
    $data = [];
    $res = $conn->query("SELECT * FROM care_records ORDER BY care_id DESC");
    while ($row = $res->fetch_assoc()) $data[] = $row;
    echo json_encode($data);
}

$conn->close();
?>
