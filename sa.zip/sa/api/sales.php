<?php
header('Content-Type: application/json');
require_once "config.php";

$action = $_POST['action'] ?? '';

if ($action === 'add') {
    $date = $_POST['sale_date'];
    $amount = $_POST['total_amount'];

    $res = $conn->query("SELECT sale_id FROM sales ORDER BY sale_id DESC LIMIT 1");
    $next = 'SL001';
    if ($res->num_rows > 0) {
        $last = $res->fetch_assoc()['sale_id'];
        $num = intval(substr($last, 2)) + 1;
        $next = 'SL' . str_pad($num, 3, '0', STR_PAD_LEFT);
    }

    $stmt = $conn->prepare("INSERT INTO sales (sale_id, sale_date, total_amount) VALUES (?, ?, ?)");
    $stmt->bind_param("ssd", $next, $date, $amount);
    $ok = $stmt->execute();
    echo json_encode(['success' => $ok]);
}

elseif ($action === 'get_all') {
    $data = [];
    $res = $conn->query("SELECT * FROM sales ORDER BY sale_id DESC");
    while ($row = $res->fetch_assoc()) $data[] = $row;
    echo json_encode($data);
}

$conn->close();
?>
