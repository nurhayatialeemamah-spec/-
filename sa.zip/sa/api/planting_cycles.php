<?php
header('Content-Type: application/json');
require_once "config.php";

$action = $_POST['action'] ?? '';

if ($action === 'add') {
    $date = $_POST['planting_date'];
    $total = $_POST['total_plants'];

    $stmt = $conn->prepare("INSERT INTO planting_cycles (planting_date, total_plants) VALUES (?, ?)");
    $stmt->bind_param("si", $date, $total);
    $ok = $stmt->execute();
    echo json_encode(['success' => $ok]);
}

elseif ($action === 'get_all') {
    $data = [];
    $res = $conn->query("SELECT * FROM planting_cycles ORDER BY cycle_no DESC");
    while ($row = $res->fetch_assoc()) $data[] = $row;
    echo json_encode($data);
}

$conn->close();
?>
