<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "vegetable_management";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die(json_encode(["success" => false, "error" => "Database connection failed"]));
}
$conn->set_charset("utf8mb4");
?>
