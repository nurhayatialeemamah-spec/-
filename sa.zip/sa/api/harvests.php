<?php
header('Content-Type: application/json');
require_once "config.php";

$action = $_POST['action'] ?? '';

if ($action === 'add') {
    $plant = $_POST['plant_id'];
    $cycle = $_POST['cycle_no'];
    $date = $_POST['harvest_date'];
    $harvested = $_POST['harvested_amount'];
    $diseased = $_POST['diseased_amount'];
    $dead = $_POST['dead_amount'];

    $res = $conn->query("SELECT harvest_id FROM harvests ORDER BY harvest_id DESC LIMIT 1");
    $next = 'HV001';
    if ($res->num_rows > 0) {
        $last = $res->fetch_assoc()['harvest_id'];
        $num = intval(substr($last, 2)) + 1;
        $next = 'HV' . str_pad($num, 3, '0', STR_PAD_LEFT);
    }

    $stmt = $conn->prepare("INSERT INTO harvests (harvest_id, plant_id, cycle_no, harvest_date, harvested_amount, diseased_amount, dead_amount)
                            VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssisdii", $next, $plant, $cycle, $date, $harvested, $diseased, $dead);
    $ok = $stmt->execute();
    echo json_encode(['success' => $ok]);
}

elseif ($action === 'get_all') {
    $data = [];
    $res = $conn->query("SELECT * FROM harvests ORDER BY harvest_id DESC");
    while ($row = $res->fetch_assoc()) $data[] = $row;
    echo json_encode($data);
}

$conn->close();
?>
