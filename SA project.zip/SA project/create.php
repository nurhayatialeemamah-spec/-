<?php
// ไฟล์: create.php (เวอร์ชัน - เฉพาะข้อมูลผัก 30 records)

ini_set('max_execution_time', 120); // เพิ่มเวลาสูงสุดในการรันสคริปต์เป็น 2 นาที
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ====== ตั้งค่าการเชื่อมต่อ ======
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'vegetable_management');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

echo "Connected to MySQL successfully.<br>";

// ====== ลบและสร้างฐานข้อมูลใหม่ ======
if ($conn->query("DROP DATABASE IF EXISTS " . DB_NAME) === TRUE) {
    echo "Database '" . DB_NAME . "' dropped successfully.<br>";
} else {
    echo "Error dropping database: " . $conn->error . "<br>";
}

if ($conn->query("CREATE DATABASE " . DB_NAME . " CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci") === TRUE) {
    echo "Database '" . DB_NAME . "' created successfully.<br>";
} else {
    echo "Error creating database: " . $conn->error . "<br>";
}
$conn->select_db(DB_NAME);

echo "Database '" . DB_NAME . "' selected.<br><hr>";

// ====== สร้างโครงสร้างตารางทั้งหมด ======
$conn->query("CREATE TABLE vegetables (
    veg_id VARCHAR(10) PRIMARY KEY,
    veg_name VARCHAR(100) NOT NULL,
    duration INT NOT NULL,
    price_per_unit DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE planting_cycles (
    cycle_no INT PRIMARY KEY AUTO_INCREMENT,
    planting_date DATE NOT NULL,
    total_plants INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE plantings (
    plant_id VARCHAR(10) PRIMARY KEY,
    cycle_no INT NOT NULL,
    veg_id VARCHAR(10) NOT NULL,
    quantity INT NOT NULL,
    plot_name VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (cycle_no) REFERENCES planting_cycles(cycle_no) ON DELETE CASCADE,
    FOREIGN KEY (veg_id) REFERENCES vegetables(veg_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE care_records (
    care_id VARCHAR(10) PRIMARY KEY,
    plant_id VARCHAR(10) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    care_round INT NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (plant_id) REFERENCES plantings(plant_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE harvests (
    harvest_id VARCHAR(10) PRIMARY KEY,
    plant_id VARCHAR(10) NOT NULL,
    cycle_no INT NOT NULL,
    harvest_date DATE NOT NULL,
    harvested_amount INT NOT NULL,
    diseased_amount INT DEFAULT 0,
    dead_amount INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (plant_id) REFERENCES plantings(plant_id) ON DELETE CASCADE,
    FOREIGN KEY (cycle_no) REFERENCES planting_cycles(cycle_no) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE sales (
    sale_id VARCHAR(10) PRIMARY KEY,
    sale_date DATE NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE sales_details (
    detail_id INT PRIMARY KEY AUTO_INCREMENT,
    harvest_id VARCHAR(10) NOT NULL,
    sale_id VARCHAR(10) NOT NULL,
    quantity INT NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (harvest_id) REFERENCES harvests(harvest_id) ON DELETE CASCADE,
    FOREIGN KEY (sale_id) REFERENCES sales(sale_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

echo "All 7 tables created successfully.<br><hr>";
echo "Starting vegetable data generation...<br>";

// ====== 1. เพิ่มข้อมูลตัวอย่างผัก (30 records) ======
$veg_names = [
    'ผักกาดหอม', 'คะน้า', 'ผักบุ้ง', 'กวางตุ้ง', 'ผักชี',
    'ต้นหอม', 'พริก', 'มะเขือ', 'แตงกวา', 'ถั่วฝักยาว',
    'โหระพา', 'แมงลัก', 'กะเพรา', 'ข่า', 'ตะไคร้',
    'มะเขือเทศ', 'ฟักทอง', 'กะหล่ำปลี', 'ผักกาดขาว', 'บรอกโคลี',
    'แครอท', 'หัวไชเท้า', 'ข้าวโพด', 'มะนาว', 'ผักชีฝรั่ง',
    'ชะอม', 'ตำลึง', 'สะระแหน่', 'ขึ้นฉ่าย', 'พริกไทยอ่อน'
];

for ($i = 1; $i <= 30; $i++) {
    $veg_id = 'VEG' . str_pad($i, 3, '0', STR_PAD_LEFT);
    $veg_name = $veg_names[$i - 1]; // ใช้ชื่อจาก array โดยตรง
    $duration = rand(25, 60);
    $price = rand(2000, 5000) / 100; // 20.00 - 50.00

    $result = $conn->query("INSERT INTO vegetables (veg_id, veg_name, duration, price_per_unit)
                  VALUES ('$veg_id', '$veg_name', $duration, $price)");
    if (!$result) {
        echo "Error inserting vegetable $veg_id: " . $conn->error . "<br>";
    }
}
echo "1. Inserted 30 'vegetables' records (Unique names).<br>";


/*
// ====== 2. เพิ่มข้อมูลตัวอย่างรอบการปลูก (ถูกลบออก) ======
// ... code removed ...
echo "2. Skipped 'planting_cycles' records.<br>";

// ====== 3. เพิ่มข้อมูลตัวอย่างการปลูก (ถูกลบออก) ======
// ... code removed ...
echo "3. Skipped 'plantings' records.<br>";

// ====== 4. เพิ่มข้อมูลตัวอย่างการดูแล (ถูกลบออก) ======
// ... code removed ...
echo "4. Skipped 'care_records' records.<br>";

// ====== 5. เพิ่มข้อมูลตัวอย่างการเก็บเกี่ยว (ถูกลบออก) ======
// ... code removed ...
echo "5. Skipped 'harvests' records.<br>";

// ====== 6. เพิ่มข้อมูลตัวอย่างการขาย (ถูกลบออก) ======
// ... code removed ...
echo "6. Skipped empty 'sales' records.<br>";

// ====== 7. เพิ่มข้อมูลตัวอย่างรายละเอียดการขาย (ถูกลบออก) ======
// ... code removed ...
echo "7. Skipped 'sales_details' records.<br>";

// ====== 8. อัปเดตยอดรวมในตาราง sales (ถูกลบออก) ======
// ... code removed ...
echo "8. Skipped updating 'sales' totals.<br>";
*/

echo "<hr><h2>Database setup complete!</h2>";
echo "<p>Only the 'vegetables' table has been populated with 30 records.</p>";
echo "<p>You can now go to <a href='main.php'>main.php</a>.</p>";

// ปิดการเชื่อมต่อ
$conn->close();
?>