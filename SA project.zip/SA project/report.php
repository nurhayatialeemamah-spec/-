<?php
// ไฟล์: report.php
include 'db.php'; // Include database connection

// --- Get Cycle Number from URL ---
$cycle_no = filter_input(INPUT_GET, 'cycle', FILTER_VALIDATE_INT);

if (!$cycle_no || $cycle_no <= 0) {
    die("Error: ไม่ได้ระบุรอบการปลูก (cycle) หรือระบุไม่ถูกต้อง โปรดระบุ ?cycle=เลขรอบ ใน URL");
}

// --- Fetch Cycle Header Data ---
$stmt_cycle = $conn->prepare("SELECT planting_date, total_plants FROM planting_cycles WHERE cycle_no = ?");
if (!$stmt_cycle) die("Prepare failed (cycle): " . $conn->error); // Error check
$stmt_cycle->bind_param("i", $cycle_no);
$stmt_cycle->execute();
$result_cycle = $stmt_cycle->get_result();
$cycle_data = $result_cycle->fetch_assoc();
$stmt_cycle->close();

if (!$cycle_data) {
    die("Error: ไม่พบข้อมูลสำหรับรอบการปลูกที่ " . htmlspecialchars($cycle_no)); // Sanitize output
}

$planting_date = $cycle_data['planting_date'];
$total_plants_in_cycle = $cycle_data['total_plants'];

// --- Fetch Planting and Harvest Details for this Cycle ---
$plantings_in_cycle = [];
$total_harvested_calc = 0;
$total_planted_calc = 0;
$total_diseased_calc = 0;
$total_dead_calc = 0;

$sql_plantings = "
    SELECT
        p.plant_id,
        v.veg_name,
        p.quantity AS quantity_planted,
        h.harvest_id,
        h.harvested_amount,
        h.diseased_amount,
        h.dead_amount
    FROM plantings p
    JOIN vegetables v ON p.veg_id = v.veg_id
    LEFT JOIN harvests h ON p.plant_id = h.plant_id AND h.cycle_no = p.cycle_no
    WHERE p.cycle_no = ?
    ORDER BY v.veg_name;
";
$stmt_plantings = $conn->prepare($sql_plantings);
if (!$stmt_plantings) die("Prepare failed (plantings): " . $conn->error); // Error check
$stmt_plantings->bind_param("i", $cycle_no);
$stmt_plantings->execute();
$result_plantings = $stmt_plantings->get_result();

while ($row = $result_plantings->fetch_assoc()) {
    $plantings_in_cycle[] = $row;
    $total_planted_calc += (int)$row['quantity_planted'];
    if (isset($row['harvested_amount'])) {
        $total_harvested_calc += (int)$row['harvested_amount'];
        $total_diseased_calc += (int)($row['diseased_amount'] ?? 0);
        $total_dead_calc += (int)($row['dead_amount'] ?? 0);
    }
}
$stmt_plantings->close();

// --- Fetch Sales Details related to Harvests from this Cycle ---
$sales_details_in_cycle = [];
$total_revenue_calc = 0.00;
$total_sold_quantity_calc = 0;

$sql_sales = "
    SELECT
        sd.harvest_id,
        v.veg_name,
        s.sale_date,
        s.sale_id,
        sd.quantity AS quantity_sold,
        sd.subtotal
    FROM sales_details sd
    JOIN harvests h ON sd.harvest_id = h.harvest_id
    JOIN plantings p ON h.plant_id = p.plant_id
    JOIN vegetables v ON p.veg_id = v.veg_id
    JOIN sales s ON sd.sale_id = s.sale_id
    WHERE p.cycle_no = ?
    ORDER BY s.sale_date, sd.detail_id;
";
$stmt_sales = $conn->prepare($sql_sales);
if (!$stmt_sales) die("Prepare failed (sales): " . $conn->error); // Error check
$stmt_sales->bind_param("i", $cycle_no);
$stmt_sales->execute();
$result_sales = $stmt_sales->get_result();

while ($row = $result_sales->fetch_assoc()) {
    $sales_details_in_cycle[] = $row;
    $total_revenue_calc += (float)($row['subtotal'] ?? 0);
    $total_sold_quantity_calc += (int)($row['quantity_sold'] ?? 0);
}
$stmt_sales->close();

$conn->close();
?>

<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>รายงานสรุปรอบการปลูกที่ <?php echo htmlspecialchars($cycle_no); ?></title>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@300;400;500;600&display=swap"
        rel="stylesheet">
    <style>
        /* === BASE STYLES === */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Bai Jamjuree', sans-serif !important;
            /* ใช้ Bai Jamjuree เป็นหลัก */
        }

        body {
            background-color: #e9f5f3;
            /* สีเขียวอ่อนๆ คล้ายธีม */
            color: #333;
            /* สีข้อความหลัก */
            padding: 20px;
            line-height: 1.6;
        }

        /* === REPORT CONTAINER === */
        .report-container {
            max-width: 950px;
            /* ขยายเล็กน้อย */
            margin: 20px auto;
            background: #ffffff;
            /* พื้นหลังสีขาว */
            padding: 30px 40px;
            /* เพิ่ม padding ด้านข้าง */
            border-radius: 8px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
            border-top: 5px solid #11998e;
            /* แถบสีเขียวด้านบน */
        }

        /* === REPORT HEADER === */
        .report-header {
            text-align: center;
            margin-bottom: 35px;
            padding-bottom: 20px;
            border-bottom: 1px solid #d1e7dd;
            /* เส้นคั่นสีเขียวอ่อน */
        }

        .report-header h1 {
            color: #11998e;
            /* สีเขียวหลัก */
            font-weight: 600;
            margin-bottom: 15px;
            /* เพิ่มระยะห่าง */
            font-size: 1.8em;
            /* ปรับขนาด */
        }

        .report-header p {
            margin-bottom: 8px;
            font-size: 1.05em;
            /* ปรับขนาดเล็กน้อย */
            color: #555;
            /* สีเทาเข้ม */
        }

        .report-header p strong {
            font-weight: 500;
            /* น้ำหนักปานกลาง */
            color: #1a202c;
            /* สีเกือบดำ */
        }

        /* === REPORT SECTION === */
        .report-section {
            margin-bottom: 35px;
        }

        .report-section h2 {
            color: #1e3c72;
            /* สีน้ำเงินเข้ม */
            border-bottom: 2px solid #e9f5f3;
            /* เส้นคั่นสีพื้นหลัง */
            padding-bottom: 8px;
            margin-bottom: 20px;
            font-size: 1.5em;
            /* ปรับขนาด */
            font-weight: 500;
            /* น้ำหนักปานกลาง */
            display: flex;
            /* สำหรับใส่ icon */
            align-items: center;
        }

        /* เพิ่ม icon หน้าหัวข้อ */
        .report-section h2::before {
            content: attr(data-icon);
            /* ใช้ emoji จาก data-icon attribute */
            margin-right: 10px;
            font-size: 1.2em;
        }


        /* === REPORT TABLE === */
        table.report-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            font-size: 0.9em;
            /* ลดขนาด font ในตาราง */
        }

        table.report-table th,
        table.report-table td {
            border: 1px solid #e2e8f0;
            /* เส้นตารางสีเทาอ่อน */
            padding: 12px 15px;
            /* ปรับ padding */
            text-align: left;
            vertical-align: middle;
        }

        table.report-table th {
            background-color: #f0f4f8;
            /* สีเทาฟ้าอ่อน */
            font-weight: 500;
            /* น้ำหนักปานกลาง */
            color: #4a5568;
            /* สีเทาเข้ม */
            text-transform: uppercase;
            /* ตัวพิมพ์ใหญ่ */
            font-size: 0.85em;
            /* ลดขนาดหัวตาราง */
            letter-spacing: 0.5px;
        }

        table.report-table tbody tr:nth-child(even) {
            background-color: #f7fafc;
            /* สลับสีแถว */
        }

        table.report-table tbody tr:hover {
            background-color: #e6f2ef;
            /* สีเขียวอ่อนเมื่อ hover */
        }


        table.report-table td.number {
            text-align: right;
            font-variant-numeric: tabular-nums;
            /* ให้ตัวเลขเรียงตรงกัน */
        }

        table.report-table td.status-ok {
            color: #28a745;
            font-weight: 500;
        }

        /* สีเขียว */
        table.report-table td.status-warn {
            color: #ffc107;
            font-weight: 500;
        }

        /* สีเหลือง */
        table.report-table td.status-bad {
            color: #dc3545;
            font-weight: 500;
        }

        /* สีแดง */
        table.report-table i.not-harvested {
            color: #6c757d;
        }

        /* สีเทา */

        /* === TABLE FOOTER (TOTALS) === */
        table.report-table tfoot tr {
            background-color: #e9ecef;
            /* สีเทาอ่อน */
            font-weight: bold;
            color: #1a202c;
        }

        table.report-table tfoot td {
            border-top: 2px solid #adb5bd;
            /* เส้นหนาบน footer */
        }


        /* === SUMMARY FOOTER === */
        .summary-footer {
            margin-top: 40px;
            padding-top: 25px;
            border-top: 1px solid #d1e7dd;
            /* เส้นคั่นสีเขียวอ่อน */
            background-color: #f8f9fa;
            /* พื้นหลังเทาอ่อน */
            padding: 25px;
            border-radius: 6px;
        }

        .summary-footer h2 {
            color: #11998e;
            /* สีเขียวหลัก */
            font-size: 1.5em;
            /* ปรับขนาด */
            margin-bottom: 20px;
            border-bottom: none;
            /* เอาเส้นใต้หัวข้อออก */
            font-weight: 500;
            display: flex;
            align-items: center;
        }

        .summary-footer h2::before {
            content: "📈";
            margin-right: 10px;
            font-size: 1.2em;
        }

        .summary-footer p {
            font-size: 1.1em;
            margin-bottom: 10px;
            line-height: 1.7;
            color: #495057;
            /* สีเทาเข้ม */
        }

        .summary-footer strong {
            font-weight: 600;
            color: #212529;
            /* สีดำ */
        }

        .summary-footer strong.revenue {
            color: #28a745;
            /* สีเขียวสำหรับรายได้ */
            font-size: 1.15em;
            /* เน้นขนาด */
        }

        /* === PRINT STYLES === */
        @media print {
            body {
                background: white;
                padding: 0;
                font-size: 10pt;
            }

            .report-container {
                box-shadow: none;
                border: 1px solid #ccc;
                margin: 0;
                max-width: 100%;
                border-radius: 0;
                padding: 15px;
            }

            .report-header,
            .report-section,
            .summary-footer {
                margin-bottom: 15px;
                padding-bottom: 10px;
                border: none;
                /* Remove borders for print */
                background: none;
                /* Remove background colors */
            }

            table.report-table,
            table.report-table th,
            table.report-table td {
                border: 1px solid #999;
                /* Use darker border for print */
                padding: 5px;
                font-size: 9pt;
            }

            table.report-table th {
                background-color: #eee !important;
                /* Lighter gray for header */
                -webkit-print-color-adjust: exact;
                /* Force background color print */
                color-adjust: exact;
            }

            table.report-table tfoot tr {
                background-color: #f5f5f5 !important;
                -webkit-print-color-adjust: exact;
                color-adjust: exact;
            }

            h1 {
                font-size: 16pt;
                color: black !important;
            }

            h2 {
                font-size: 12pt;
                color: black !important;
            }

            p,
            strong {
                font-size: 10pt;
                color: black !important;
            }

            .summary-footer strong.revenue {
                color: black !important;
            }

            /* Revenue black in print */

            /* Hide things like background gradients */
            body,
            header,
            .btn,
            .stat-card {
                background: none !important;
                color: black !important;
            }

            /* Hide interactive elements */
            button,
            a.btn {
                display: none !important;
            }

            @page {
                margin: 1cm;
            }
        }
    </style>
</head>

<body>
    
    <div class="report-container">
        <div class="report-header">
            <h1>📄 รายงานสรุปรอบการปลูก</h1>
            <p><strong>รอบการปลูกที่:</strong> <?php echo htmlspecialchars($cycle_no); ?></p>
            <p><strong>วันที่เริ่มปลูก:</strong> <?php echo htmlspecialchars($planting_date); ?></p>
            <p><strong>จำนวนต้นที่ควรปลูก (ตามบันทึกรอบ):</strong> <?php echo number_format($total_plants_in_cycle); ?> ต้น</p>
            <?php if ($total_plants_in_cycle != $total_planted_calc): ?>
                <p style="color: orange;"><i>(หมายเหตุ: จำนวนต้นที่ปลูกจริงคือ <?php echo number_format($total_planted_calc); ?> ต้น)</i></p>
            <?php endif; ?>
        </div>

        <div class="report-section">
            <h2 data-icon="🌱">รายละเอียดการปลูกและการเก็บเกี่ยว</h2>
            <?php if (!empty($plantings_in_cycle)): ?>
                <table class="report-table">
                    <thead>
                        <tr>
                            <th>ชื่อผัก (รหัสปลูก)</th>
                            <th class="number">จำนวนที่ปลูก</th>
                            <th class="number">จำนวนที่เก็บได้</th>
                            <th class="number">ติดโรค</th>
                            <th class="number">ตาย</th>
                            <th class="number">รวมสูญเสีย</th>
                            <th class="number">อัตราสูญเสีย (%)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($plantings_in_cycle as $plant): ?>
                            <?php
                            $planted = (int)$plant['quantity_planted'];
                            $harvested = isset($plant['harvested_amount']) ? (int)$plant['harvested_amount'] : null;
                            $diseased = isset($plant['diseased_amount']) ? (int)$plant['diseased_amount'] : 0;
                            $dead = isset($plant['dead_amount']) ? (int)$plant['dead_amount'] : 0;
                            $loss_count = $diseased + $dead;
                            $loss_rate = ($planted > 0) ? round(($loss_count / $planted) * 100, 1) : 0;
                            $harvest_display = is_null($harvested) ? '<i class="not-harvested">ยังไม่เก็บเกี่ยว</i>' : number_format($harvested);
                            $loss_class = ($loss_count == 0 && !is_null($harvested)) ? 'status-ok' : (($loss_rate < 15) ? 'status-warn' : 'status-bad');
                            if (is_null($harvested)) $loss_class = 'status-warn'; // Mark unharvested as warning
                            ?>
                            <tr>
                                <td><?php echo htmlspecialchars($plant['veg_name']); ?> (<?php echo htmlspecialchars($plant['plant_id']); ?>)</td>
                                <td class="number"><?php echo number_format($planted); ?></td>
                                <td class="number"><?php echo $harvest_display; ?></td>
                                <td class="number"><?php echo number_format($diseased); ?></td>
                                <td class="number"><?php echo number_format($dead); ?></td>
                                <td class="number"><?php echo number_format($loss_count); ?></td>
                                <td class="number <?php echo $loss_class; ?>"><?php echo number_format($loss_rate, 1); ?>%</td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td><strong>รวมทั้งหมด</strong></td>
                            <td class="number"><strong><?php echo number_format($total_planted_calc); ?></strong></td>
                            <td class="number"><strong><?php echo number_format($total_harvested_calc); ?></strong></td>
                            <td class="number"><strong><?php echo number_format($total_diseased_calc); ?></strong></td>
                            <td class="number"><strong><?php echo number_format($total_dead_calc); ?></strong></td>
                            <td class="number"><strong><?php echo number_format($total_diseased_calc + $total_dead_calc); ?></strong></td>
                            <td class="number <?php echo (($total_diseased_calc + $total_dead_calc) == 0 && $total_harvested_calc > 0) ? 'status-ok' : (((($total_diseased_calc + $total_dead_calc) / $total_planted_calc * 100 < 15) && $total_planted_calc > 0) ? 'status-warn' : 'status-bad'); ?>">
                                <strong><?php echo ($total_planted_calc > 0) ? number_format((($total_diseased_calc + $total_dead_calc) / $total_planted_calc) * 100, 1) : '0.0'; ?>%</strong>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            <?php else: ?>
                <p><i>ไม่มีข้อมูลการปลูกสำหรับรอบนี้</i></p>
            <?php endif; ?>
        </div>

        <div class="report-section">
            <h2 data-icon="💰">รายละเอียดการขาย (จากผลผลิตรอบนี้)</h2>
            <?php if (!empty($sales_details_in_cycle)): ?>
                <table class="report-table">
                    <thead>
                        <tr>
                            <th>วันที่ขาย</th>
                            <th>รหัสการขาย</th>
                            <th>ผัก (จากการเก็บเกี่ยว)</th>
                            <th class="number">จำนวนที่ขาย</th>
                            <th class="number">ยอดรวม (บาท)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($sales_details_in_cycle as $sale): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($sale['sale_date']); ?></td>
                                <td><?php echo htmlspecialchars($sale['sale_id']); ?></td>
                                <td><?php echo htmlspecialchars($sale['veg_name']); ?> (<?php echo htmlspecialchars($sale['harvest_id']); ?>)</td>
                                <td class="number"><?php echo number_format((int)$sale['quantity_sold']); ?></td>
                                <td class="number"><?php echo number_format((float)$sale['subtotal'], 2); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3"><strong>รวมยอดขายทั้งหมด</strong></td>
                            <td class="number"><strong><?php echo number_format($total_sold_quantity_calc); ?></strong></td>
                            <td class="number"><strong><?php echo number_format($total_revenue_calc, 2); ?></strong></td>
                        </tr>
                    </tfoot>
                </table>
            <?php else: ?>
                <p><i>ยังไม่มีการขายผลผลิตจากรอบนี้</i></p>
            <?php endif; ?>
        </div>

        <div class="summary-footer">
            <h2>สรุปผลรวมสำหรับรอบการปลูกที่ <?php echo htmlspecialchars($cycle_no); ?></h2>
            <p><strong>จำนวนต้นที่ปลูกทั้งหมด:</strong> <?php echo number_format($total_planted_calc); ?> ต้น</p>
            <p><strong>จำนวนผลผลิตที่เก็บเกี่ยวได้:</strong> <?php echo number_format($total_harvested_calc); ?> ต้น</p>
            <p><strong>จำนวนผลผลิตที่เสียหาย (ติดโรค + ตาย):</strong> <?php echo number_format($total_diseased_calc + $total_dead_calc); ?> ต้น (<?php echo ($total_planted_calc > 0) ? number_format((($total_diseased_calc + $total_dead_calc) / $total_planted_calc) * 100, 1) : '0.0'; ?>%)</p>
            <p><strong>จำนวนผลผลิตที่ขายได้:</strong> <?php echo number_format($total_sold_quantity_calc); ?> หน่วย</p>
            <p><strong>รายได้รวมจากการขาย:</strong> <strong class="revenue"><?php echo number_format($total_revenue_calc, 2); ?> บาท</strong></p>
        </div>

    </div>
</body>

</html>