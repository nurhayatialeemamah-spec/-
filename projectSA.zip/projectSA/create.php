<?php
// create.php - สร้างฐานข้อมูลพร้อมข้อมูลจำลองอย่างน้อย 30 แถว/ตาราง

ini_set('max_execution_time', 300);
error_reporting(E_ALL);
ini_set('display_errors', 1);

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'vegetable_management');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS);
if ($conn->connect_error) die("❌ Connection failed: " . $conn->connect_error);
$conn->set_charset("utf8mb4");

?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🌱 สร้างฐานข้อมูลจัดการผัก</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 1000px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
        }
        h1 {
            color: #2ecc71;
            font-size: 2.5rem;
            margin-bottom: 10px;
            border-bottom: 4px solid #2ecc71;
            padding-bottom: 15px;
            text-align: center;
        }
        h2 {
            color: #3498db;
            font-size: 1.8rem;
            margin: 30px 0 15px 0;
        }
        .step {
            background: #f8f9fa;
            padding: 15px 20px;
            margin: 10px 0;
            border-radius: 8px;
            border-left: 4px solid #3498db;
        }
        .success {
            background: #d4edda;
            color: #155724;
            padding: 12px 20px;
            margin: 8px 0;
            border-radius: 8px;
            border-left: 4px solid #28a745;
            font-weight: 500;
        }
        .info {
            color: #2980b9;
            margin: 10px 0;
            font-size: 1.1rem;
        }
        hr {
            margin: 30px 0;
            border: none;
            border-top: 2px solid #ecf0f1;
        }
        .btn {
            display: inline-block;
            margin-top: 30px;
            padding: 18px 40px;
            background: linear-gradient(135deg, #2ecc71 0%, #27ae60 100%);
            color: white;
            text-decoration: none;
            border-radius: 10px;
            font-size: 1.3rem;
            font-weight: bold;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(46, 204, 113, 0.3);
        }
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(46, 204, 113, 0.4);
        }
        .progress {
            background: #ecf0f1;
            height: 35px;
            border-radius: 20px;
            overflow: hidden;
            margin: 25px 0;
            box-shadow: inset 0 2px 4px rgba(0,0,0,0.1);
        }
        .progress-bar {
            background: linear-gradient(90deg, #2ecc71, #27ae60);
            height: 100%;
            transition: width 0.5s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.1rem;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 25px 0;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border-radius: 10px;
            overflow: hidden;
        }
        th {
            background: linear-gradient(135deg, #2ecc71 0%, #27ae60 100%);
            color: white;
            padding: 15px;
            text-align: left;
            font-size: 1.1rem;
        }
        th:last-child {
            text-align: right;
        }
        td {
            padding: 12px 15px;
            border-bottom: 1px solid #ecf0f1;
        }
        td:last-child {
            text-align: right;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background: #f8f9fa;
        }
        tr:hover {
            background: #e8f5e9;
        }
        .summary-box {
            background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
            padding: 30px;
            border-radius: 15px;
            margin: 25px 0;
            border: 3px solid #28a745;
        }
        .summary-box h3 {
            color: #155724;
            margin-bottom: 15px;
            font-size: 1.5rem;
        }
        .summary-box p {
            margin: 10px 0;
            font-size: 1.2rem;
            font-weight: 500;
        }
        .total-row {
            background: linear-gradient(135deg, #3498db 0%, #2980b9 100%) !important;
            color: white !important;
            font-weight: bold;
            font-size: 1.2rem;
        }
        .center {
            text-align: center;
        }
        .highlight {
            background: yellow;
            padding: 2px 6px;
            border-radius: 4px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🌱 สร้างฐานข้อมูลจัดการผัก</h1>
        <p class="center info">ระบบจะสร้างข้อมูลจำลอง <span class="highlight">อย่างน้อย 30 แถว</span> ในแต่ละตาราง</p>
        
        <?php
        // ลบและสร้างฐานข้อมูล
        if ($conn->query("DROP DATABASE IF EXISTS " . DB_NAME)) {
            echo "<p class='success'>✅ ลบฐานข้อมูลเดิมสำเร็จ</p>";
        }
        
        if ($conn->query("CREATE DATABASE " . DB_NAME . " CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")) {
            echo "<p class='success'>✅ สร้างฐานข้อมูล 'vegetable_management' สำเร็จ</p>";
        }
        $conn->select_db(DB_NAME);
        
        echo "<hr><h2>📊 ขั้นตอนที่ 1: สร้างโครงสร้างตาราง</h2>";
        
        // สร้างตาราง
        $tables = [
            "vegetables" => "CREATE TABLE vegetables (
                veg_id VARCHAR(10) PRIMARY KEY,
                veg_name VARCHAR(100) NOT NULL,
                duration INT NOT NULL,
                price_per_unit DECIMAL(10,2) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
            
            "planting_cycles" => "CREATE TABLE planting_cycles (
                cycle_no INT PRIMARY KEY AUTO_INCREMENT,
                planting_date DATE NOT NULL,
                total_plants INT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
            
            "plantings" => "CREATE TABLE plantings (
                plant_id VARCHAR(10) PRIMARY KEY,
                cycle_no INT NOT NULL,
                veg_id VARCHAR(10) NOT NULL,
                quantity INT NOT NULL,
                plot_name VARCHAR(50) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (cycle_no) REFERENCES planting_cycles(cycle_no) ON DELETE CASCADE,
                FOREIGN KEY (veg_id) REFERENCES vegetables(veg_id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
            
            "care_records" => "CREATE TABLE care_records (
                care_id VARCHAR(10) PRIMARY KEY,
                plant_id VARCHAR(10) NOT NULL,
                start_date DATE NOT NULL,
                end_date DATE NOT NULL,
                care_round INT NOT NULL,
                notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (plant_id) REFERENCES plantings(plant_id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
            
            "harvests" => "CREATE TABLE harvests (
                harvest_id VARCHAR(10) PRIMARY KEY,
                plant_id VARCHAR(10) NOT NULL,
                cycle_no INT NOT NULL,
                harvest_date DATE NOT NULL,
                harvested_amount INT NOT NULL,
                diseased_amount INT DEFAULT 0,
                dead_amount INT DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (plant_id) REFERENCES plantings(plant_id) ON DELETE CASCADE,
                FOREIGN KEY (cycle_no) REFERENCES planting_cycles(cycle_no) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
            
            "sales" => "CREATE TABLE sales (
                sale_id VARCHAR(10) PRIMARY KEY,
                sale_date DATE NOT NULL,
                total_amount DECIMAL(10,2) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
            
            "sales_details" => "CREATE TABLE sales_details (
                detail_id INT PRIMARY KEY AUTO_INCREMENT,
                harvest_id VARCHAR(10) NOT NULL,
                sale_id VARCHAR(10) NOT NULL,
                quantity INT NOT NULL,
                subtotal DECIMAL(10,2) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (harvest_id) REFERENCES harvests(harvest_id) ON DELETE CASCADE,
                FOREIGN KEY (sale_id) REFERENCES sales(sale_id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        ];
        
        foreach ($tables as $name => $sql) {
            if ($conn->query($sql)) {
                echo "<p class='step'>✅ สร้างตาราง <strong>$name</strong> สำเร็จ</p>";
            }
        }
        
        echo "<hr><h2>📝 ขั้นตอนที่ 2: เพิ่มข้อมูลจำลอง</h2>";
        echo "<div class='progress'><div class='progress-bar' id='bar'>เริ่มต้น...</div></div>";
        flush();
        
        // ========================
        // 1. VEGETABLES (30 แถว)
        // ========================
        echo "<div class='step'>🌿 กำลังเพิ่มข้อมูลผัก 30 ชนิด...</div>";
        flush();
        
        $vegetables = [
            ['ผักกาดหอม', 30, 25.50], ['คะน้า', 45, 30.00], ['ผักบุ้ง', 25, 20.00],
            ['กวางตุ้ง', 35, 28.00], ['ผักชี', 40, 22.00], ['ต้นหอม', 50, 35.00],
            ['พริก', 90, 45.00], ['มะเขือ', 70, 38.00], ['แตงกวา', 60, 32.00],
            ['ถั่วฝักยาว', 55, 30.00], ['โหระพา', 35, 25.00], ['แมงลัก', 30, 24.00],
            ['กะเพรา', 40, 26.00], ['ข่า', 180, 65.00], ['ตะไคร้', 120, 45.00],
            ['มะเขือเทศ', 75, 40.00], ['ฟักทอง', 100, 35.00], ['กะหล่ำปลี', 80, 38.00],
            ['ผักกาดขาว', 50, 28.00], ['บรอกโคลี', 85, 42.00], ['แครอท', 90, 36.00],
            ['หัวไชเท้า', 60, 30.00], ['ข้าวโพด', 75, 25.00], ['มะนาว', 365, 80.00],
            ['ผักชีฝรั่ง', 55, 28.00], ['ชะอม', 45, 32.00], ['ตำลึง', 40, 26.00],
            ['สะระแหน่', 35, 24.00], ['ขึ้นฉ่าย', 50, 30.00], ['พริกไทยอ่อน', 60, 35.00]
        ];
        
        foreach ($vegetables as $i => $v) {
            $id = 'VEG' . str_pad($i + 1, 3, '0', STR_PAD_LEFT);
            $conn->query("INSERT INTO vegetables VALUES ('$id', '{$v[0]}', {$v[1]}, {$v[2]}, NOW())");
        }
        
        echo "<p class='success'>✅ เพิ่ม <strong>30 แถว</strong> 'vegetables' สำเร็จ</p>";
        echo "<script>document.getElementById('bar').style.width='14%';document.getElementById('bar').textContent='14% - ผักเสร็จแล้ว';</script>";
        flush();
        
        // ========================
        // 2. PLANTING CYCLES (30 แถว)
        // ========================
        echo "<div class='step'>🔄 กำลังสร้างรอบการปลูก 30 รอบ...</div>";
        flush();
        
        for ($i = 1; $i <= 30; $i++) {
            $date = date('Y-m-d', strtotime("-" . (30 - $i) . " days"));
            $plants = rand(800, 1500);
            $conn->query("INSERT INTO planting_cycles (planting_date, total_plants) VALUES ('$date', $plants)");
        }
        
        echo "<p class='success'>✅ เพิ่ม <strong>30 แถว</strong> 'planting_cycles' สำเร็จ</p>";
        echo "<script>document.getElementById('bar').style.width='28%';document.getElementById('bar').textContent='28% - รอบการปลูกเสร็จแล้ว';</script>";
        flush();
        
        // ========================
        // 3. PLANTINGS (30 แถว)
        // ========================
        echo "<div class='step'>🌱 กำลังสร้างข้อมูลการปลูก 30 แถว...</div>";
        flush();
        
        $plots = ['แปลง A', 'แปลง B', 'แปลง C', 'แปลง D', 'แปลง E', 'แปลง F', 'แปลง G', 'แปลง H', 'แปลง I', 'แปลง J'];
        
        for ($i = 1; $i <= 30; $i++) {
            $plant_id = 'PL' . str_pad($i, 3, '0', STR_PAD_LEFT);
            $cycle = rand(1, 30);
            $veg = 'VEG' . str_pad(rand(1, 30), 3, '0', STR_PAD_LEFT);
            $qty = rand(50, 200);
            $plot = $plots[rand(0, 9)];
            $conn->query("INSERT INTO plantings VALUES ('$plant_id', $cycle, '$veg', $qty, '$plot', NOW())");
        }
        
        echo "<p class='success'>✅ เพิ่ม <strong>30 แถว</strong> 'plantings' สำเร็จ</p>";
        echo "<script>document.getElementById('bar').style.width='42%';document.getElementById('bar').textContent='42% - การปลูกเสร็จแล้ว';</script>";
        flush();
        
        // ========================
        // 4. CARE RECORDS (30 แถว)
        // ========================
        echo "<div class='step'>💧 กำลังสร้างบันทึกการดูแล 30 แถว...</div>";
        flush();
        
        $care_notes = [
            'รดน้ำสม่ำเสมอ เช้า-เย็น',
            'ใส่ปุ๋ยอินทรีย์ครั้งแรก',
            'ใส่ปุ๋ยเคมีสูตร 15-15-15',
            'กำจัดวัชพืชรอบแปลง',
            'ป้องกันโรคแมลง ฉีดยา',
            'ตัดแต่งกิ่งที่แห้งตาย',
            'ตรวจสอบโรคพืชและแมลง',
            'รดน้ำเพิ่มช่วงแล้ง',
            'ใส่ปุ๋ยทางใบ',
            'ถอนหญ้าแซมปลูก'
        ];
        
        for ($i = 1; $i <= 30; $i++) {
            $care_id = 'CR' . str_pad($i, 3, '0', STR_PAD_LEFT);
            $plant = 'PL' . str_pad(rand(1, 30), 3, '0', STR_PAD_LEFT);
            $start = date('Y-m-d', strtotime("-" . rand(20, 50) . " days"));
            $end = date('Y-m-d', strtotime($start . " +" . rand(7, 21) . " days"));
            $round = rand(1, 5);
            $notes = $care_notes[rand(0, 9)];
            $conn->query("INSERT INTO care_records VALUES ('$care_id', '$plant', '$start', '$end', $round, '$notes', NOW())");
        }
        
        echo "<p class='success'>✅ เพิ่ม <strong>30 แถว</strong> 'care_records' สำเร็จ</p>";
        echo "<script>document.getElementById('bar').style.width='57%';document.getElementById('bar').textContent='57% - การดูแลเสร็จแล้ว';</script>";
        flush();
        
        // ========================
        // 5. HARVESTS (30 แถว)
        // ========================
        echo "<div class='step'>🌾 กำลังสร้างข้อมูลการเก็บเกี่ยว 30 แถว...</div>";
        flush();
        
        for ($i = 1; $i <= 30; $i++) {
            $harvest_id = 'HV' . str_pad($i, 3, '0', STR_PAD_LEFT);
            $plant = 'PL' . str_pad(rand(1, 30), 3, '0', STR_PAD_LEFT);
            $cycle = rand(1, 30);
            $date = date('Y-m-d', strtotime("-" . rand(1, 25) . " days"));
            $harvested = rand(30, 180);
            $diseased = rand(0, 10);
            $dead = rand(0, 5);
            $conn->query("INSERT INTO harvests VALUES ('$harvest_id', '$plant', $cycle, '$date', $harvested, $diseased, $dead, NOW())");
        }
        
        echo "<p class='success'>✅ เพิ่ม <strong>30 แถว</strong> 'harvests' สำเร็จ</p>";
        echo "<script>document.getElementById('bar').style.width='71%';document.getElementById('bar').textContent='71% - การเก็บเกี่ยวเสร็จแล้ว';</script>";
        flush();
        
        // ========================
        // 6. SALES (30 แถว)
        // ========================
        echo "<div class='step'>💰 กำลังสร้างข้อมูลการขาย 30 แถว...</div>";
        flush();
        
        for ($i = 1; $i <= 30; $i++) {
            $sale_id = 'SL' . str_pad($i, 3, '0', STR_PAD_LEFT);
            $date = date('Y-m-d', strtotime("-" . rand(1, 29) . " days"));
            $amount = rand(5000, 15000) / 100;
            $conn->query("INSERT INTO sales VALUES ('$sale_id', '$date', $amount, NOW())");
        }
        
        echo "<p class='success'>✅ เพิ่ม <strong>30 แถว</strong> 'sales' สำเร็จ</p>";
        echo "<script>document.getElementById('bar').style.width='85%';document.getElementById('bar').textContent='85% - การขายเสร็จแล้ว';</script>";
        flush();
        
        // ========================
        // 7. SALES DETAILS (30 แถว)
        // ========================
        echo "<div class='step'>📋 กำลังสร้างรายละเอียดการขาย 30 แถว...</div>";
        flush();
        
        for ($i = 1; $i <= 30; $i++) {
            $harvest = 'HV' . str_pad(rand(1, 30), 3, '0', STR_PAD_LEFT);
            $sale = 'SL' . str_pad(rand(1, 30), 3, '0', STR_PAD_LEFT);
            $qty = rand(10, 100);
            $subtotal = rand(500, 3000) / 100;
            $conn->query("INSERT INTO sales_details (harvest_id, sale_id, quantity, subtotal) VALUES ('$harvest', '$sale', $qty, $subtotal)");
        }
        
        echo "<p class='success'>✅ เพิ่ม <strong>30 แถว</strong> 'sales_details' สำเร็จ</p>";
        echo "<script>document.getElementById('bar').style.width='100%';document.getElementById('bar').textContent='100% - เสร็จสมบูรณ์!';</script>";
        flush();
        
        echo "<hr>";
        echo "<div class='summary-box'>";
        echo "<h3>🎉 สร้างฐานข้อมูลสำเร็จ!</h3>";
        echo "<p>✅ สร้างโครงสร้างตาราง 7 ตาราง</p>";
        echo "<p>✅ เพิ่มข้อมูลจำลอง <strong>อย่างน้อย 30 แถว</strong> ในแต่ละตาราง</p>";
        echo "<p>✅ ข้อมูลพร้อมใช้งาน</p>";
        echo "</div>";
        
        // สรุปจำนวนแถว
        echo "<h2>📊 ขั้นตอนที่ 3: สรุปข้อมูลในฐานข้อมูล</h2>";
        echo "<table>";
        echo "<tr><th>ตาราง</th><th>จำนวนแถว</th></tr>";
        
        $table_labels = [
            'vegetables' => 'ผัก (Vegetables)',
            'planting_cycles' => 'รอบการปลูก (Planting Cycles)',
            'plantings' => 'การปลูก (Plantings)',
            'care_records' => 'การดูแล (Care Records)',
            'harvests' => 'การเก็บเกี่ยว (Harvests)',
            'sales' => 'การขาย (Sales)',
            'sales_details' => 'รายละเอียดขาย (Sales Details)'
        ];
        
        $total_rows = 0;
        foreach ($table_labels as $table => $label) {
            $result = $conn->query("SELECT COUNT(*) as cnt FROM $table");
            $count = $result->fetch_assoc()['cnt'];
            $total_rows += $count;
            $status = ($count >= 30) ? '✅' : '⚠️';
            echo "<tr><td>$status $label</td><td>$count</td></tr>";
        }
        
        echo "<tr class='total-row'><td>รวมทั้งหมด</td><td>$total_rows แถว</td></tr>";
        echo "</table>";
        
        echo "<div class='center'>";
        echo "<a href='main.php' class='btn'>🚀 เปิดระบบจัดการผัก</a>";
        echo "</div>";
        
        $conn->close();
        ?>
        
        <div style="margin-top: 40px; padding: 20px; background: #e3f2fd; border-radius: 10px; border-left: 4px solid #2196f3;">
            <h3 style="color: #1976d2; margin-bottom: 10px;">💡 ข้อมูลเพิ่มเติม</h3>
            <p style="margin: 8px 0;">📌 ข้อมูลที่สร้างเป็นข้อมูลจำลองสำหรับทดสอบระบบ</p>
            <p style="margin: 8px 0;">📌 สามารถเพิ่ม แก้ไข ลบข้อมูลได้ตามต้องการ</p>
            <p style="margin: 8px 0;">📌 หากต้องการสร้างข้อมูลใหม่ ให้เรียก create.php อีกครั้ง</p>
        </div>
    </div>
</body>
</html>