// ไฟล์: app.js

// ตัวแปรสำหรับเก็บข้อมูลทั้งหมด
let DB = {
    vegetables: [],
    planting_cycles: [],
    plantings: [],
    care_records: [],
    harvests: [],
    sales: [],
    sales_details: []
};

// URL ของ API
const API_URL = 'api.php';

// Array ชั่วคราวสำหรับเก็บรายการปลูกในหน้า "เพิ่มรอบปลูกใหม่"
let currentCyclePlantings = [];

// ========== EVENT LISTENER เมื่อโหลดหน้า ==========
document.addEventListener('DOMContentLoaded', () => {
    loadAllData();
    setupTabs();
    setupFormListeners(); // Setup listeners for existing forms (veg, care, harvest, sales, details)
    setupTableListeners();
    setupSearch();
    setupAutomationListeners();
    setupSummaryClickListeners();
    setupNewCycleFormListeners(); // Setup listeners for the new combined form
});

// ========== 1. SETUP FUNCTIONS ==========

function setupTabs() {
    const tabButtons = document.querySelectorAll('.nav-tabs .tab-btn');
    tabButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            // Find the tab name from the onclick attribute
            const onclickAttr = e.target.getAttribute('onclick');
            if (onclickAttr) {
                const match = onclickAttr.match(/'([^']+)'/);
                if (match && match[1]) {
                    openTab(match[1]);
                }
            }
        });
    });
}

function setupFormListeners() {
    // Keep listeners for forms that still exist
    document.getElementById('vegetableForm')?.addEventListener('submit', handleVegetableSubmit);
    document.getElementById('careForm')?.addEventListener('submit', handleCareSubmit);
    document.getElementById('harvestForm')?.addEventListener('submit', handleHarvestSubmit);
    document.getElementById('salesForm')?.addEventListener('submit', handleSalesSubmit);
    document.getElementById('salesDetailForm')?.addEventListener('submit', handleSalesDetailSubmit);
}

function setupNewCycleFormListeners() {
    const addBtn = document.getElementById('addPlantingItemBtn');
    const form = document.getElementById('newCycleForm');
    const tempTableBody = document.getElementById('tempPlantingsTableBody');

    if (addBtn) {
        addBtn.addEventListener('click', handleAddPlantingItem);
    }
    if (form) {
        form.addEventListener('submit', handleSaveNewCycle);
    }
    if (tempTableBody) {
        tempTableBody.addEventListener('click', (e) => {
            if (e.target.classList.contains('remove-temp-item-btn')) {
                const indexToRemove = parseInt(e.target.dataset.index, 10);
                handleRemoveTempPlantingItem(indexToRemove);
            }
        });
    }
}


function setupTableListeners() {
    const tableBodies = document.querySelectorAll('.data-table-container tbody');
    tableBodies.forEach(tbody => {
        tbody.addEventListener('click', (e) => {
            // Target the button specifically, not just any click in the cell
            const target = e.target.closest('button.btn-edit, button.btn-delete');
            if (!target) return; // Exit if the click wasn't on an edit or delete button

            const id = target.dataset.id;
            const action = target.classList.contains('btn-edit') ? 'edit' : 'delete'; // Simplified action detection
            if (!id) return; // Ensure id exists

            const tableId = tbody.id;

            switch (tableId) {
                case 'vegetableTableBody':
                    if (action === 'edit') editVegetable(id);
                    else if (action === 'delete') deleteVegetable(id);
                    break;
                case 'plantingCycleTableBody':
                    if (action === 'edit') editPlantingCycle(id); // Re-enabled edit listener
                    else if (action === 'delete') deletePlantingCycle(id);
                    break;
                case 'plantingTableBody':
                    if (action === 'edit') editPlanting(id); // Keep edit listener for planting list if needed
                    else if (action === 'delete') deletePlanting(id);
                    break;
                case 'careTableBody':
                    if (action === 'edit') editCare(id);
                    else if (action === 'delete') deleteCare(id);
                    break;
                case 'harvestTableBody':
                    if (action === 'edit') editHarvest(id);
                    else if (action === 'delete') deleteHarvest(id);
                    break;
                case 'salesTableBody':
                    if (action === 'edit') editSale(id);
                    else if (action === 'delete') deleteSale(id);
                    break;
                case 'salesDetailTableBody':
                    if (action === 'edit') editDetail(id);
                    else if (action === 'delete') deleteDetail(id);
                    break;
            }
        });
    });
}


function setupSearch() {
    // 1. ค้นหาผัก
    document.getElementById('searchVegetable')?.addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase();
        const filtered = (DB.vegetables || []).filter(v =>
            v.veg_id.toLowerCase().includes(query) ||
            v.veg_name.toLowerCase().includes(query) ||
            String(v.price_per_unit).includes(query)
        );
        renderVegetableTable(filtered);
    });

    // 2. ค้นหารอบการปลูก
    document.getElementById('searchCycle')?.addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase();
        const filtered = (DB.planting_cycles || []).filter(c =>
            String(c.cycle_no).includes(query) ||
            (c.planting_date && c.planting_date.includes(query)) ||
            String(c.total_plants).includes(query)
        );
        renderPlantingCycleTable(filtered);
    });

    // 3. ค้นหาการปลูก
    document.getElementById('searchPlanting')?.addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase();
        const filtered = (DB.plantings || []).filter(p => {
            const veg = (DB.vegetables || []).find(v => v.veg_id === p.veg_id);
            const vegName = veg ? veg.veg_name.toLowerCase() : '';
            return p.plant_id.toLowerCase().includes(query) ||
                String(p.cycle_no).includes(query) ||
                p.veg_id.toLowerCase().includes(query) ||
                p.plot_name.toLowerCase().includes(query) ||
                vegName.includes(query);
        });
        renderPlantingTable(filtered);
    });

    // 4. ค้นหาการดูแล
    document.getElementById('searchCare')?.addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase();
        const filtered = (DB.care_records || []).filter(c => {
            let vegName = '';
            const plant = (DB.plantings || []).find(p => p.plant_id === c.plant_id);
            if (plant) {
                const veg = (DB.vegetables || []).find(v => v.veg_id === plant.veg_id);
                if (veg) vegName = veg.veg_name.toLowerCase();
            }
            return c.care_id.toLowerCase().includes(query) ||
                c.plant_id.toLowerCase().includes(query) ||
                (c.start_date && c.start_date.includes(query)) ||
                (c.end_date && c.end_date.includes(query)) ||
                (c.notes && c.notes.toLowerCase().includes(query)) ||
                vegName.includes(query);
        });
        renderCareTable(filtered);
    });

    // 5. ค้นหาการเก็บเกี่ยว
    document.getElementById('searchHarvest')?.addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase();
        const filtered = (DB.harvests || []).filter(h => {
            let vegName = '';
            const plant = (DB.plantings || []).find(p => p.plant_id === h.plant_id);
            if (plant) {
                const veg = (DB.vegetables || []).find(v => v.veg_id === plant.veg_id);
                if (veg) vegName = veg.veg_name.toLowerCase();
            }
            return h.harvest_id.toLowerCase().includes(query) ||
                h.plant_id.toLowerCase().includes(query) ||
                String(h.cycle_no).includes(query) ||
                (h.harvest_date && h.harvest_date.includes(query)) ||
                String(h.harvested_amount).includes(query) ||
                vegName.includes(query);
        });
        renderHarvestTable(filtered);
    });

    // 6. ค้นหาการขาย
    document.getElementById('searchSales')?.addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase();
        const filtered = (DB.sales || []).filter(s =>
            s.sale_id.toLowerCase().includes(query) ||
            (s.sale_date && s.sale_date.includes(query)) ||
            String(s.total_amount).includes(query)
        );
        renderSalesTable(filtered);
    });

    // 7. ค้นหารายละเอียดการขาย
    document.getElementById('searchSalesDetail')?.addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase();
        const filtered = (DB.sales_details || []).filter(d =>
            String(d.detail_id).includes(query) ||
            d.harvest_id.toLowerCase().includes(query) ||
            d.sale_id.toLowerCase().includes(query) ||
            String(d.quantity).includes(query) ||
            String(d.subtotal).includes(query)
        );
        renderSalesDetailTable(filtered);
    });
}


// ========== 2. TAB HANDLING ==========

function openTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));

    const activeTab = document.getElementById(tabName);
    const activeButton = document.querySelector(`.tab-btn[onclick="openTab('${tabName}')"]`);

    if (activeTab) activeTab.classList.add('active');
    if (activeButton) activeButton.classList.add('active');

    if (tabName === 'summary') {
        loadSummaryData();
    }
}


// ========== 3. DATA LOADING & RENDERING ==========

async function loadAllData() {
    try {
        const response = await fetch(`${API_URL}?action=get_all_data`);
        const result = await response.json();

        if (result.status === 'success' && result.data) {
            DB = {
                vegetables: result.data.vegetables || [],
                planting_cycles: result.data.planting_cycles || [],
                plantings: result.data.plantings || [],
                care_records: result.data.care_records || [],
                harvests: result.data.harvests || [],
                sales: result.data.sales || [],
                sales_details: result.data.sales_details || []
            };

            renderVegetableTable(DB.vegetables);
            renderPlantingCycleTable(DB.planting_cycles);
            renderPlantingTable(DB.plantings);
            renderCareTable(DB.care_records);
            renderHarvestTable(DB.harvests);
            renderSalesTable(DB.sales);
            renderSalesDetailTable(DB.sales_details);

            populateDropdowns();
            renderTempPlantingsTable();

        } else {
            console.error('Error loading data:', result.message, result.debug_errors);
            alert('Error loading data: ' + (result.message || 'Unknown error'));
            renderVegetableTable([]);
            renderPlantingCycleTable([]);
            renderPlantingTable([]);
            renderCareTable([]);
            renderHarvestTable([]);
            renderSalesTable([]);
            renderSalesDetailTable([]);
        }
    } catch (error) {
        console.error('Fetch Error:', error);
        alert('Cannot connect to server.');
        renderVegetableTable([]);
        renderPlantingCycleTable([]);
        renderPlantingTable([]);
        renderCareTable([]);
        renderHarvestTable([]);
        renderSalesTable([]);
        renderSalesDetailTable([]);
    }
}


async function loadSummaryData() {
    try {
        const response = await fetch(`${API_URL}?action=get_summary`);
        const result = await response.json();
        if (result.status !== 'success' || !result.data) {
            console.error('Failed to load summary data:', result.message);
            return;
        }

        const data = result.data;
        // Stats Grid
        document.getElementById('totalVegetables').textContent = data.totalVegetables || 0;
        document.getElementById('totalCycles').textContent = data.totalCycles || 0;
        document.getElementById('totalPlantings').textContent = data.totalPlantings || 0;
        document.getElementById('totalCares').textContent = data.totalCares || 0;
        document.getElementById('summaryTotalHarvests').textContent = data.totalHarvests || 0;
        document.getElementById('summaryTotalSales').textContent = data.totalSalesCount || 0;
        document.getElementById('summaryTotalSalesDetails').textContent = data.totalSalesDetails || 0;

        // Harvest Summary
        document.getElementById('totalHarvests').textContent = data.totalHarvests || 0;
        document.getElementById('totalHarvestAmount').textContent = data.totalHarvestAmount || 0;
        document.getElementById('totalDisease').textContent = data.totalDisease || 0;
        document.getElementById('totalDead').textContent = data.totalDead || 0;

        // Sales Summary
        document.getElementById('totalSalesCount').textContent = data.totalSalesCount || 0;
        document.getElementById('totalSalesAmount').textContent = parseFloat(data.totalSalesAmount || 0).toFixed(2);
        document.getElementById('totalSalesDetails').textContent = data.totalSalesDetails || 0;

        // Recent Activities - Set Text
        document.getElementById('latestHarvestText').textContent = data.latestHarvestText || 'ยังไม่มีข้อมูล';
        document.getElementById('latestSaleText').textContent = data.latestSaleText || 'ยังไม่มีข้อมูล';
        document.getElementById('latestCareText').textContent = data.latestCareText || 'ยังไม่มีข้อมูล';

        // Set data-id attributes for clicking
        const latestHarvestItem = document.getElementById('latestHarvestItem');
        const latestSaleItem = document.getElementById('latestSaleItem');
        const latestCareItem = document.getElementById('latestCareItem');

        if (latestHarvestItem) latestHarvestItem.dataset.id = data.latestHarvestId || '';
        if (latestSaleItem) latestSaleItem.dataset.id = data.latestSaleId || '';
        if (latestCareItem) latestCareItem.dataset.id = data.latestCareId || '';

    } catch (error) {
        console.error('Error loading summary:', error);
        document.getElementById('totalVegetables').textContent = 'Error';
        // ... clear others ...
    }
}


function populateDropdowns() {
    const carePlantSelect = document.getElementById('carePlantId');
    const harvestPlantSelect = document.getElementById('harvestPlantId');
    const detailHarvestSelect = document.getElementById('detailHarvestId');
    const detailSaleSelect = document.getElementById('detailSaleId');
    const newPlantVegSelect = document.getElementById('newPlantVegId');

    const getOption = (val, text) => `<option value="${val}">${text}</option>`;

    const clearSelect = (selectElem, defaultText) => {
        if (selectElem) selectElem.innerHTML = `<option value="">${defaultText}</option>`;
    };

    clearSelect(carePlantSelect, '-- เลือกการปลูก --');
    clearSelect(harvestPlantSelect, '-- เลือกการปลูก --');
    clearSelect(detailHarvestSelect, '-- เลือกการเก็บเกี่ยว --');
    clearSelect(detailSaleSelect, '-- เลือกการขาย --');
    clearSelect(newPlantVegSelect, '-- เลือกผัก --');

    // Populate Vegetables for the new cycle form
    (DB.vegetables || []).forEach(v => {
        const optionText = `${v.veg_id} - ${v.veg_name}`;
        if (newPlantVegSelect) newPlantVegSelect.innerHTML += getOption(v.veg_id, optionText);
    });

    // Populate Plantings for Care and Harvest selects
    (DB.plantings || []).forEach(p => {
        const veg = (DB.vegetables || []).find(v => v.veg_id === p.veg_id);
        const vegName = veg ? veg.veg_name : 'N/A';
        const optionText = `${p.plant_id} (แปลง ${p.plot_name} - ${vegName})`;
        if (carePlantSelect) carePlantSelect.innerHTML += getOption(p.plant_id, optionText);
        if (harvestPlantSelect) harvestPlantSelect.innerHTML += getOption(p.plant_id, optionText);
    });

    // Populate Harvests for Sales Detail select
    (DB.harvests || []).forEach(h => {
        const soldQuantity = (DB.sales_details || [])
            .filter(d => d.harvest_id === h.harvest_id)
            .reduce((sum, d) => sum + parseInt(d.quantity || 0, 10), 0);
        const availableAmount = parseInt(h.harvested_amount || 0, 10) - soldQuantity;

        if (availableAmount > 0 && detailHarvestSelect) {
            const plant = (DB.plantings || []).find(p => p.plant_id === h.plant_id);
            const veg = plant ? (DB.vegetables || []).find(v => v.veg_id === plant.veg_id) : null;
            const vegName = veg ? veg.veg_name : 'N/A';
            detailHarvestSelect.innerHTML += getOption(h.harvest_id, `${h.harvest_id} (${vegName} - คงเหลือ ${availableAmount})`);
        }
    });

    // Populate Sales for Sales Detail select
    (DB.sales || []).forEach(s => {
        if (detailSaleSelect) detailSaleSelect.innerHTML += getOption(s.sale_id, `${s.sale_id} (วันที่ ${s.sale_date})`);
    });
}


// --- Render Functions ---

const sanitize = (str) => {
    if (str === null || typeof str === 'undefined') return '-';
    if (typeof str === 'number' && !Number.isInteger(str)) {
        str = str.toFixed(2);
    }
    const temp = document.createElement('div');
    temp.textContent = String(str);
    return temp.innerHTML;
};


function renderVegetableTable(data) {
    const tbody = document.getElementById('vegetableTableBody');
    if (!tbody) return;
    tbody.innerHTML = '';
    if (!data || data.length === 0) {
        tbody.innerHTML = '<tr class="empty-state"><td colspan="5"><p>ยังไม่มีข้อมูลผัก</p></td></tr>';
        return;
    }
    data.forEach(v => {
        tbody.innerHTML += `
            <tr>
                <td>${sanitize(v.veg_id)}</td>
                <td>${sanitize(v.veg_name)}</td>
                <td>${sanitize(v.duration)} วัน</td>
                <td>${parseFloat(v.price_per_unit || 0).toFixed(2)} บาท</td>
                <td class="action-buttons">
                    <button class="btn btn-edit" data-id="${sanitize(v.veg_id)}">✏️ แก้ไข</button>
                    <button class="btn btn-delete" data-id="${sanitize(v.veg_id)}">🗑️ ลบ</button>
                </td>
            </tr>`;
    });
}

function renderPlantingCycleTable(data) {
    const tbody = document.getElementById('plantingCycleTableBody');
    if (!tbody) return;
    tbody.innerHTML = '';
    if (!data || data.length === 0) {
        // Correct colspan based on the final columns (Cycle#, Date, Total, Actions)
        tbody.innerHTML = '<tr class="empty-state"><td colspan="4"><p>ยังไม่มีข้อมูลรอบการปลูก</p></td></tr>';
        return;
    }
    data.forEach(c => {
        const cycleNo = sanitize(c.cycle_no);
        tbody.innerHTML += `
            <tr>
                <td>${cycleNo}</td>
                <td>${sanitize(c.planting_date)}</td>
                <td class="number">${sanitize(c.total_plants)}</td>
                <td class="action-buttons" style="min-width: 220px;"> <a href="report.php?cycle=${cycleNo}" target="_blank" class="btn btn-view-report" style="background: #007bff; color: white; padding: 5px 10px; font-size: 0.8em; text-decoration: none; border-radius: 5px; display: inline-block; margin-right: 5px;">
                       📄 ดูรายงาน
                    </a>
                    <button class="btn btn-edit" data-id="${cycleNo}">✏️ แก้ไข</button>
                    <button class="btn btn-delete" data-id="${cycleNo}">🗑️ ลบ</button>
                </td>
            </tr>`;
    });
}


function renderPlantingTable(data) {
    const tbody = document.getElementById('plantingTableBody');
    if (!tbody) return;
    tbody.innerHTML = '';
    if (!data || data.length === 0) {
        tbody.innerHTML = '<tr class="empty-state"><td colspan="6"><p>ยังไม่มีข้อมูลการปลูก</p></td></tr>';
        return;
    }
    data.forEach(p => {
        const veg = (DB.vegetables || []).find(v => v.veg_id === p.veg_id);
        const vegName = veg ? `(${sanitize(veg.veg_name)})` : '';
        tbody.innerHTML += `
            <tr>
                <td>${sanitize(p.plant_id)}</td>
                <td>${sanitize(p.cycle_no)}</td>
                <td>${sanitize(p.veg_id)} ${vegName}</td>
                <td class="number">${sanitize(p.quantity)}</td>
                <td>${sanitize(p.plot_name)}</td>
                <td class="action-buttons">
                    <button class="btn btn-edit" data-id="${sanitize(p.plant_id)}">✏️ แก้ไข</button>
                    <button class="btn btn-delete" data-id="${sanitize(p.plant_id)}">🗑️ ลบ</button>
                </td>
            </tr>`;
    });
}

function renderCareTable(data) {
    const tbody = document.getElementById('careTableBody');
    if (!tbody) return;
    tbody.innerHTML = '';
    if (!data || data.length === 0) {
        tbody.innerHTML = '<tr class="empty-state"><td colspan="7"><p>ยังไม่มีข้อมูลการดูแล</p></td></tr>';
        return;
    }
    data.forEach(c => {
        const plant = (DB.plantings || []).find(p => p.plant_id === c.plant_id);
        const veg = plant ? (DB.vegetables || []).find(v => v.veg_id === plant.veg_id) : null;
        const vegName = veg ? `(${sanitize(veg.veg_name)})` : '';
        tbody.innerHTML += `
            <tr>
                <td>${sanitize(c.care_id)}</td>
                <td>${sanitize(c.plant_id)} ${vegName}</td>
                <td>${sanitize(c.start_date)}</td>
                <td>${sanitize(c.end_date)}</td>
                <td class="number">${sanitize(c.care_round)}</td>
                <td>${sanitize(c.notes)}</td>
                <td class="action-buttons">
                    <button class="btn btn-edit" data-id="${sanitize(c.care_id)}">✏️ แก้ไข</button>
                    <button class="btn btn-delete" data-id="${sanitize(c.care_id)}">🗑️ ลบ</button>
                </td>
            </tr>`;
    });
}

function renderHarvestTable(data) {
    const tbody = document.getElementById('harvestTableBody');
    if (!tbody) return;
    tbody.innerHTML = '';
    if (!data || data.length === 0) {
        tbody.innerHTML = '<tr class="empty-state"><td colspan="8"><p>ยังไม่มีข้อมูลการเก็บเกี่ยว</p></td></tr>';
        return;
    }
    data.forEach(h => {
        const plant = (DB.plantings || []).find(p => p.plant_id === h.plant_id);
        const veg = plant ? (DB.vegetables || []).find(v => v.veg_id === plant.veg_id) : null;
        const vegName = veg ? `(${sanitize(veg.veg_name)})` : '';
        tbody.innerHTML += `
            <tr>
                <td>${sanitize(h.harvest_id)}</td>
                <td>${sanitize(h.plant_id)} ${vegName}</td>
                <td class="number">${sanitize(h.cycle_no)}</td>
                <td>${sanitize(h.harvest_date)}</td>
                <td class="number">${sanitize(h.harvested_amount)}</td>
                <td class="number">${sanitize(h.diseased_amount)}</td>
                <td class="number">${sanitize(h.dead_amount)}</td>
                <td class="action-buttons">
                    <button class="btn btn-edit" data-id="${sanitize(h.harvest_id)}">✏️ แก้ไข</button>
                    <button class="btn btn-delete" data-id="${sanitize(h.harvest_id)}">🗑️ ลบ</button>
                </td>
            </tr>`;
    });
}

function renderSalesTable(data) {
    const tbody = document.getElementById('salesTableBody');
    if (!tbody) return;
    tbody.innerHTML = '';
    if (!data || data.length === 0) {
        tbody.innerHTML = '<tr class="empty-state"><td colspan="4"><p>ยังไม่มีข้อมูลการขาย</p></td></tr>';
        return;
    }
    data.forEach(s => {
        tbody.innerHTML += `
            <tr>
                <td>${sanitize(s.sale_id)}</td>
                <td>${sanitize(s.sale_date)}</td>
                <td class="number">${parseFloat(s.total_amount || 0).toFixed(2)} บาท</td>
                <td class="action-buttons">
                    <button class="btn btn-edit" data-id="${sanitize(s.sale_id)}">✏️ แก้ไข</button>
                    <button class="btn btn-delete" data-id="${sanitize(s.sale_id)}">🗑️ ลบ</button>
                </td>
            </tr>`;
    });
}

function renderSalesDetailTable(data) {
    const tbody = document.getElementById('salesDetailTableBody');
    if (!tbody) return;
    tbody.innerHTML = '';
    if (!data || data.length === 0) {
        tbody.innerHTML = '<tr class="empty-state"><td colspan="6"><p>ยังไม่มีรายละเอียดการขาย</p></td></tr>';
        return;
    }
    data.forEach(d => {
        tbody.innerHTML += `
            <tr>
                <td>${sanitize(d.detail_id)}</td>
                <td>${sanitize(d.harvest_id)}</td>
                <td>${sanitize(d.sale_id)}</td>
                <td class="number">${sanitize(d.quantity)}</td>
                <td class="number">${parseFloat(d.subtotal || 0).toFixed(2)} บาท</td>
                <td class="action-buttons">
                    <button class="btn btn-edit" data-id="${sanitize(d.detail_id)}">✏️ แก้ไข</button>
                    <button class="btn btn-delete" data-id="${sanitize(d.detail_id)}">🗑️ ลบ</button>
                </td>
            </tr>`;
    });
}

function renderTempPlantingsTable() {
    const tbody = document.getElementById('tempPlantingsTableBody');
    const totalPlantsInput = document.getElementById('calculatedTotalPlants');
    if (!tbody || !totalPlantsInput) return;

    tbody.innerHTML = '';
    let currentTotalPlants = 0;

    if (currentCyclePlantings.length === 0) {
        tbody.innerHTML = '<tr class="empty-state"><td colspan="4"><p>ยังไม่มีรายการปลูก</p></td></tr>';
        totalPlantsInput.value = 0;
        return;
    }

    currentCyclePlantings.forEach((item, index) => {
        const veg = (DB.vegetables || []).find(v => v.veg_id === item.veg_id);
        const vegName = veg ? veg.veg_name : 'N/A';
        tbody.innerHTML += `
            <tr>
                <td>${sanitize(vegName)} (${sanitize(item.veg_id)})</td>
                <td class="number">${sanitize(item.quantity)}</td>
                <td>${sanitize(item.plot_name)}</td>
                <td class="action-buttons">
                    <button type="button" class="btn btn-delete remove-temp-item-btn" data-index="${index}">🗑️ ลบ</button>
                </td>
            </tr>
        `;
        currentTotalPlants += parseInt(item.quantity || 0, 10);
    });
    totalPlantsInput.value = currentTotalPlants;
}

// ========== 4. FORM SUBMIT HANDLERS ==========

async function sendFormData(action, formData) {
    formData.append('action', action);
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            body: formData
        });
        const contentType = response.headers.get("content-type");
        if (!contentType || !contentType.includes("application/json")) {
            const textResponse = await response.text();
            throw new Error(`Invalid response from server: ${textResponse}`);
        }

        const result = await response.json();
        alert(result.message);
        if (result.status === 'success') {
            await loadAllData();
            return true;
        } else {
            console.error('API Error:', result.message);
        }
    } catch (error) {
        console.error('Submit Error:', error);
        alert('เกิดข้อผิดพลาดในการส่งข้อมูล: ' + error.message);
    }
    return false;
}

async function handleVegetableSubmit(e) {
    e.preventDefault();
    const formData = new FormData();
    formData.append('veg_id', document.getElementById('vegId')?.value);
    formData.append('veg_name', document.getElementById('vegName')?.value);
    formData.append('duration', document.getElementById('vegDuration')?.value);
    formData.append('price_per_unit', document.getElementById('vegPrice')?.value);

    if (await sendFormData('manage_vegetable', formData)) {
        cancelEditVegetable();
    }
}

async function handleCareSubmit(e) {
    e.preventDefault();
    const formData = new FormData();
    formData.append('care_id', document.getElementById('careId')?.value);
    formData.append('plant_id', document.getElementById('carePlantId')?.value);
    formData.append('care_round', document.getElementById('careCycle')?.value);
    formData.append('start_date', document.getElementById('careStartDate')?.value);
    formData.append('end_date', document.getElementById('careEndDate')?.value);
    formData.append('notes', document.getElementById('careNote')?.value);

    if (await sendFormData('manage_care_record', formData)) {
        cancelEditCare();
    }
}

async function handleHarvestSubmit(e) {
    e.preventDefault();
    const formData = new FormData();
    formData.append('harvest_id', document.getElementById('harvestId')?.value);
    formData.append('plant_id', document.getElementById('harvestPlantId')?.value);
    formData.append('cycle_no', document.getElementById('harvestCycleNo')?.value);
    formData.append('harvest_date', document.getElementById('harvestDate')?.value);
    formData.append('harvested_amount', document.getElementById('harvestAmount')?.value);
    formData.append('diseased_amount', document.getElementById('harvestDisease')?.value);
    formData.append('dead_amount', document.getElementById('harvestDead')?.value);

    if (await sendFormData('manage_harvest', formData)) {
        cancelEditHarvest();
    }
}

async function handleSalesSubmit(e) {
    e.preventDefault();
    const formData = new FormData();
    formData.append('sale_id', document.getElementById('saleId')?.value);
    formData.append('sale_date', document.getElementById('saleDate')?.value);

    if (await sendFormData('manage_sale', formData)) {
        cancelEditSale();
    }
}

async function handleSalesDetailSubmit(e) {
    e.preventDefault();
    const formData = new FormData();
    formData.append('detail_id', document.getElementById('detailId')?.value);
    formData.append('harvest_id', document.getElementById('detailHarvestId')?.value);
    formData.append('sale_id', document.getElementById('detailSaleId')?.value);
    formData.append('quantity', document.getElementById('detailQuantity')?.value);
    formData.append('subtotal', document.getElementById('detailTotal')?.value);

    if (await sendFormData('manage_sales_detail', formData)) {
        cancelEditDetail();
    }
}

function handleAddPlantingItem() {
    const vegIdInput = document.getElementById('newPlantVegId');
    const quantityInput = document.getElementById('newPlantQuantity');
    const plotNameInput = document.getElementById('newPlantPlot');

    if (!vegIdInput || !quantityInput || !plotNameInput) return;

    const vegId = vegIdInput.value;
    const quantity = quantityInput.value;
    const plotName = plotNameInput.value;

    if (!vegId || !quantity || !plotName) {
        alert('กรุณากรอกข้อมูลการปลูกให้ครบ (ผัก, จำนวน, แปลง)');
        return;
    }
    const qtyInt = parseInt(quantity, 10);
    if (isNaN(qtyInt) || qtyInt <= 0) {
        alert('จำนวนต้นต้องเป็นตัวเลขและมากกว่า 0');
        quantityInput.focus();
        return;
    }

    currentCyclePlantings.push({
        veg_id: vegId,
        quantity: qtyInt,
        plot_name: plotName
    });

    renderTempPlantingsTable();

    vegIdInput.value = '';
    quantityInput.value = '';
    plotNameInput.value = '';
    vegIdInput.focus();
}

function handleRemoveTempPlantingItem(indexToRemove) {
    if (indexToRemove >= 0 && indexToRemove < currentCyclePlantings.length) {
        currentCyclePlantings.splice(indexToRemove, 1);
        renderTempPlantingsTable();
    }
}

async function handleSaveNewCycle(e) {
    e.preventDefault();
    const cycleDateInput = document.getElementById('newCycleDate');
    if (!cycleDateInput) return;

    const cycleDate = cycleDateInput.value;

    if (!cycleDate) {
        alert('กรุณาเลือกวันที่เริ่มรอบปลูก');
        cycleDateInput.focus();
        return;
    }
    if (currentCyclePlantings.length === 0) {
        alert('กรุณาเพิ่มรายการปลูกอย่างน้อย 1 รายการ');
        document.getElementById('newPlantVegId')?.focus();
        return;
    }

    const formData = new FormData();
    formData.append('planting_date', cycleDate);
    formData.append('plantings', JSON.stringify(currentCyclePlantings));

    const success = await sendFormData('add_cycle_with_plantings', formData);

    if (success) {
        const form = document.getElementById('newCycleForm');
        if (form) form.reset();
        currentCyclePlantings = [];
        renderTempPlantingsTable();
        openTab('plantingCycles');
    }
}

// ========== 5. EDIT & DELETE HANDLERS ==========

function editVegetable(id) {
    const veg = (DB.vegetables || []).find(v => v.veg_id === id);
    if (!veg) return;
    const form = document.getElementById('vegetableForm');
    if (!form) { alert("ฟอร์มแก้ไขข้อมูลผักไม่พบ"); return; }

    document.getElementById('vegId') && (document.getElementById('vegId').value = veg.veg_id);
    document.getElementById('vegIdDisplay') && (document.getElementById('vegIdDisplay').value = veg.veg_id);
    document.getElementById('vegName') && (document.getElementById('vegName').value = veg.veg_name);
    document.getElementById('vegDuration') && (document.getElementById('vegDuration').value = veg.duration);
    document.getElementById('vegPrice') && (document.getElementById('vegPrice').value = veg.price_per_unit);

    document.getElementById('vegSubmitBtn') && (document.getElementById('vegSubmitBtn').textContent = '✏️ อัปเดตข้อมูล');
    document.getElementById('vegCancelBtn') && (document.getElementById('vegCancelBtn').style.display = 'inline-block');
    form.scrollIntoView({ behavior: 'smooth' });
}

// Edit function for Planting Cycle - MODIFIED to only edit date via prompt
function editPlantingCycle(id) {
    const cycle = (DB.planting_cycles || []).find(c => c.cycle_no == id);
    if (!cycle) {
        alert("ไม่พบข้อมูลรอบการปลูกที่ต้องการแก้ไข");
        return;
    }

    const newDate = prompt(`แก้ไขวันที่ปลูกสำหรับรอบ ${id} (YYYY-MM-DD):`, cycle.planting_date);

    if (newDate !== null) {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(newDate)) {
            alert("รูปแบบวันที่ไม่ถูกต้อง กรุณาใช้ YYYY-MM-DD");
            return;
        }
        if (newDate === cycle.planting_date) {
            alert("วันที่ไม่ได้เปลี่ยนแปลง");
            return;
        }

        const formData = new FormData();
        formData.append('cycle_no', id);
        formData.append('planting_date', newDate);
        // Do NOT send 'total_plants'

        sendFormData('manage_planting_cycle', formData);
    }
}


function editPlanting(id) {
    const plant = (DB.plantings || []).find(p => p.plant_id === id);
    if (!plant) return;
    alert(`การแก้ไขข้อมูลการปลูก (${id}) ยังไม่รองรับในหน้านี้ ต้องสร้างฟอร์มแก้ไขแยกต่างหาก`);
    // Placeholder for modal/form implementation
}

function editCare(id) {
    const care = (DB.care_records || []).find(c => c.care_id === id);
    if (!care) return;
    const form = document.getElementById('careForm');
    if (!form) { alert("ฟอร์มแก้ไขข้อมูลดูแลไม่พบ"); return; }

    document.getElementById('careId') && (document.getElementById('careId').value = care.care_id);
    document.getElementById('careIdDisplay') && (document.getElementById('careIdDisplay').value = care.care_id);
    document.getElementById('carePlantId') && (document.getElementById('carePlantId').value = care.plant_id);
    document.getElementById('careCycle') && (document.getElementById('careCycle').value = care.care_round);
    document.getElementById('careStartDate') && (document.getElementById('careStartDate').value = care.start_date);
    document.getElementById('careEndDate') && (document.getElementById('careEndDate').value = care.end_date);
    document.getElementById('careNote') && (document.getElementById('careNote').value = care.notes || '');

    document.getElementById('careSubmitBtn') && (document.getElementById('careSubmitBtn').textContent = '✏️ อัปเดตข้อมูล');
    document.getElementById('careCancelBtn') && (document.getElementById('careCancelBtn').style.display = 'inline-block');
    form.scrollIntoView({ behavior: 'smooth' });
}

function editHarvest(id) {
    const harvest = (DB.harvests || []).find(h => h.harvest_id === id);
    if (!harvest) return;
    const form = document.getElementById('harvestForm');
    if (!form) { alert("ฟอร์มแก้ไขข้อมูลเก็บเกี่ยวไม่พบ"); return; }

    document.getElementById('harvestId') && (document.getElementById('harvestId').value = harvest.harvest_id);
    document.getElementById('harvestIdDisplay') && (document.getElementById('harvestIdDisplay').value = harvest.harvest_id);
    document.getElementById('harvestPlantId') && (document.getElementById('harvestPlantId').value = harvest.plant_id);
    document.getElementById('harvestCycleNo') && (document.getElementById('harvestCycleNo').value = harvest.cycle_no);
    document.getElementById('harvestDate') && (document.getElementById('harvestDate').value = harvest.harvest_date);
    document.getElementById('harvestAmount') && (document.getElementById('harvestAmount').value = harvest.harvested_amount);
    document.getElementById('harvestDisease') && (document.getElementById('harvestDisease').value = harvest.diseased_amount);
    document.getElementById('harvestDead') && (document.getElementById('harvestDead').value = harvest.dead_amount);

    document.getElementById('harvestSubmitBtn') && (document.getElementById('harvestSubmitBtn').textContent = '✏️ อัปเดตข้อมูล');
    document.getElementById('harvestCancelBtn') && (document.getElementById('harvestCancelBtn').style.display = 'inline-block');
    form.scrollIntoView({ behavior: 'smooth' });
}

function editSale(id) {
    const sale = (DB.sales || []).find(s => s.sale_id === id);
    if (!sale) return;
    const form = document.getElementById('salesForm');
    if (!form) { alert("ฟอร์มแก้ไขข้อมูลการขายไม่พบ"); return; }

    document.getElementById('saleId') && (document.getElementById('saleId').value = sale.sale_id);
    document.getElementById('saleIdDisplay') && (document.getElementById('saleIdDisplay').value = sale.sale_id);
    document.getElementById('saleDate') && (document.getElementById('saleDate').value = sale.sale_date);
    document.getElementById('saleAmount') && (document.getElementById('saleAmount').value = parseFloat(sale.total_amount || 0).toFixed(2));

    document.getElementById('saleSubmitBtn') && (document.getElementById('saleSubmitBtn').textContent = '✏️ อัปเดตข้อมูล');
    document.getElementById('saleCancelBtn') && (document.getElementById('saleCancelBtn').style.display = 'inline-block');
    form.scrollIntoView({ behavior: 'smooth' });
}

function editDetail(id) {
    const detail = (DB.sales_details || []).find(d => d.detail_id == id);
    if (!detail) return;
    const form = document.getElementById('salesDetailForm');
    if (!form) { alert("ฟอร์มแก้ไขรายละเอียดขายไม่พบ"); return; }

    document.getElementById('detailId') && (document.getElementById('detailId').value = detail.detail_id);
    document.getElementById('detailIdDisplay') && (document.getElementById('detailIdDisplay').value = detail.detail_id);
    document.getElementById('detailHarvestId') && (document.getElementById('detailHarvestId').value = detail.harvest_id);
    document.getElementById('detailSaleId') && (document.getElementById('detailSaleId').value = detail.sale_id);
    document.getElementById('detailQuantity') && (document.getElementById('detailQuantity').value = detail.quantity);
    document.getElementById('detailTotal') && (document.getElementById('detailTotal').value = parseFloat(detail.subtotal || 0).toFixed(2));

    document.getElementById('detailSubmitBtn') && (document.getElementById('detailSubmitBtn').textContent = '✏️ อัปเดตข้อมูล');
    document.getElementById('detailCancelBtn') && (document.getElementById('detailCancelBtn').style.display = 'inline-block');
    form.scrollIntoView({ behavior: 'smooth' });
}

// --- Delete Functions ---
async function deleteData(action, idKey, id, confirmText) {
    if (!confirm(confirmText)) return;
    const formData = new FormData();
    formData.append(idKey, id);
    await sendFormData(action, formData);
}

function deleteVegetable(id) {
    deleteData('delete_vegetable', 'veg_id', id, `ลบข้อมูลผัก ${id} ? (อาจลบข้อมูลการปลูกที่เกี่ยวข้องไม่ได้ หากมีการอ้างอิง)`);
}
function deletePlantingCycle(id) {
    deleteData('delete_planting_cycle', 'cycle_no', id, `ลบรอบการปลูก ${id} ? (ข้อมูลการปลูก, ดูแล, เก็บเกี่ยว ที่อ้างอิงจะถูกลบด้วย)`);
}
function deletePlanting(id) {
    deleteData('delete_planting', 'plant_id', id, `ลบการปลูก ${id} ? (ข้อมูลดูแลและเก็บเกี่ยวที่อ้างอิงจะถูกลบด้วย)`);
}
function deleteCare(id) {
    deleteData('delete_care_record', 'care_id', id, `ลบการดูแล ${id} ?`);
}
function deleteHarvest(id) {
    deleteData('delete_harvest', 'harvest_id', id, `ลบการเก็บเกี่ยว ${id} ? (อาจลบรายละเอียดการขายที่เกี่ยวข้องไม่ได้ หากมีการอ้างอิง)`);
}
function deleteSale(id) {
    deleteData('delete_sale', 'sale_id', id, `ลบการขาย ${id} ? (รายละเอียดการขายที่อ้างอิงจะถูกลบด้วย)`);
}
function deleteDetail(id) {
    deleteData('delete_sales_detail', 'detail_id', id, `ลบรายละเอียดการขาย ${id} ? (ยอดรวมการขายจะถูกอัปเดตอัตโนมัติ)`);
}

// ========== 6. FORM CANCEL HANDLERS ==========

function cancelEditVegetable() {
    const form = document.getElementById('vegetableForm');
    if (form) {
        form.reset();
        document.getElementById('vegId') && (document.getElementById('vegId').value = '');
        document.getElementById('vegIdDisplay') && (document.getElementById('vegIdDisplay').value = '');
        document.getElementById('vegSubmitBtn') && (document.getElementById('vegSubmitBtn').textContent = '➕ เพิ่มข้อมูลผัก');
        document.getElementById('vegCancelBtn') && (document.getElementById('vegCancelBtn').style.display = 'none');
    }
}

function cancelEditCare() {
    const form = document.getElementById('careForm');
    if (form) {
        form.reset();
        document.getElementById('careId') && (document.getElementById('careId').value = '');
        document.getElementById('careIdDisplay') && (document.getElementById('careIdDisplay').value = '');
        document.getElementById('careSubmitBtn') && (document.getElementById('careSubmitBtn').textContent = '➕ เพิ่มข้อมูลการดูแล');
        document.getElementById('careCancelBtn') && (document.getElementById('careCancelBtn').style.display = 'none');
        updateCareRound();
    }
}
function cancelEditHarvest() {
    const form = document.getElementById('harvestForm');
    if (form) {
        form.reset();
        document.getElementById('harvestId') && (document.getElementById('harvestId').value = '');
        document.getElementById('harvestIdDisplay') && (document.getElementById('harvestIdDisplay').value = '');
        document.getElementById('harvestSubmitBtn') && (document.getElementById('harvestSubmitBtn').textContent = '➕ เพิ่มข้อมูลการเก็บเกี่ยว');
        document.getElementById('harvestCancelBtn') && (document.getElementById('harvestCancelBtn').style.display = 'none');
        document.getElementById('harvestCycleNo') && (document.getElementById('harvestCycleNo').value = '');
    }
}
function cancelEditSale() {
    const form = document.getElementById('salesForm');
    if (form) {
        form.reset();
        document.getElementById('saleId') && (document.getElementById('saleId').value = '');
        document.getElementById('saleIdDisplay') && (document.getElementById('saleIdDisplay').value = '');
        document.getElementById('saleAmount') && (document.getElementById('saleAmount').value = '0.00');
        document.getElementById('saleSubmitBtn') && (document.getElementById('saleSubmitBtn').textContent = '➕ เพิ่มข้อมูลการขาย');
        document.getElementById('saleCancelBtn') && (document.getElementById('saleCancelBtn').style.display = 'none');
    }
}
function cancelEditDetail() {
    const form = document.getElementById('salesDetailForm');
    if (form) {
        form.reset();
        document.getElementById('detailId') && (document.getElementById('detailId').value = '');
        document.getElementById('detailIdDisplay') && (document.getElementById('detailIdDisplay').value = '');
        document.getElementById('detailTotal') && (document.getElementById('detailTotal').value = '');
        document.getElementById('detailSubmitBtn') && (document.getElementById('detailSubmitBtn').textContent = '➕ เพิ่มรายละเอียดการขาย');
        document.getElementById('detailCancelBtn') && (document.getElementById('detailCancelBtn').style.display = 'none');
    }
}


// ========== 7. AUTOMATION FUNCTIONS ==========

function setupAutomationListeners() {
    document.getElementById('carePlantId')?.addEventListener('change', updateCareRound);
    document.getElementById('harvestPlantId')?.addEventListener('change', updateHarvestCycleNo);
    document.getElementById('detailHarvestId')?.addEventListener('change', calculateSalesDetailSubtotal);
    document.getElementById('detailQuantity')?.addEventListener('input', calculateSalesDetailSubtotal);
}

function updateCareRound() {
    const plantId = document.getElementById('carePlantId')?.value;
    const careCycleInput = document.getElementById('careCycle');
    if (!careCycleInput) return;

    let nextRound = 1;
    if (plantId && DB.care_records) {
        const careRecords = DB.care_records.filter(c => c.plant_id === plantId);
        if (careRecords.length > 0) {
            const maxRound = Math.max(0, ...careRecords.map(c => parseInt(c.care_round || 0, 10)));
            nextRound = maxRound + 1;
        }
    }
    careCycleInput.value = nextRound;
}

function updateHarvestCycleNo() {
    const plantId = document.getElementById('harvestPlantId')?.value;
    const cycleNoInput = document.getElementById('harvestCycleNo');
    if (!cycleNoInput) return;

    let cycleNo = '';
    if (plantId && DB.plantings) {
        const plant = DB.plantings.find(p => p.plant_id === plantId);
        if (plant) {
            cycleNo = plant.cycle_no;
        }
    }
    cycleNoInput.value = cycleNo;
}

function calculateSalesDetailSubtotal() {
    const harvestId = document.getElementById('detailHarvestId')?.value;
    const quantityInput = document.getElementById('detailQuantity');
    const totalInput = document.getElementById('detailTotal');
    const detailIdBeingEdited = document.getElementById('detailId')?.value;

    if (!quantityInput || !totalInput) return;

    const quantity = parseInt(quantityInput.value, 10) || 0;
    let subtotal = 0;

    if (harvestId && quantity >= 0 && DB.harvests && DB.plantings && DB.vegetables) { // Allow quantity 0 for calculation reset
        try {
            const harvest = DB.harvests.find(h => h.harvest_id === harvestId);
            if (!harvest) throw new Error('Harvest not found');

            const plant = DB.plantings.find(p => p.plant_id === harvest.plant_id);
            if (!plant) throw new Error('Planting not found');

            const veg = DB.vegetables.find(v => v.veg_id === plant.veg_id);
            if (!veg) throw new Error('Vegetable not found');

            const price = parseFloat(veg.price_per_unit);
            if (isNaN(price)) throw new Error('Invalid price');

            const soldQuantity = (DB.sales_details || [])
                .filter(d => d.harvest_id === harvestId && d.detail_id != detailIdBeingEdited)
                .reduce((sum, d) => sum + parseInt(d.quantity || 0, 10), 0);
            const availableAmount = parseInt(harvest.harvested_amount || 0, 10) - soldQuantity;

            if (quantity > availableAmount) {
                alert(`ไม่สามารถขายเกินจำนวนคงเหลือ (${availableAmount})`);
                quantityInput.value = availableAmount;
                subtotal = price * availableAmount;
            } else {
                subtotal = price * quantity;
            }

        } catch (e) {
            console.error("Error calculating subtotal:", e.message);
            subtotal = 0;
        }
    }
    totalInput.value = subtotal.toFixed(2);
}


// ========== 8. SUMMARY DASHBOARD CLICK HANDLER ==========
function setupSummaryClickListeners() {
    const container = document.getElementById('recentActivitiesContainer');
    if (!container) return;

    container.addEventListener('click', (e) => {
        const item = e.target.closest('.activity-item');
        if (!item) return;

        const tabName = item.dataset.tab;
        const dataId = item.dataset.id;

        if (!tabName || !dataId) {
            console.log("Activity item clicked, but no tab or ID found:", item.dataset);
            return;
        }

        openTab(tabName);

        setTimeout(() => {
            let searchInput;
            if (tabName === 'harvest') {
                searchInput = document.getElementById('searchHarvest');
            } else if (tabName === 'sales') {
                searchInput = document.getElementById('searchSales');
            } else if (tabName === 'care') {
                searchInput = document.getElementById('searchCare');
            } else {
                console.log("No search input defined for tab:", tabName);
                return;
            }

            if (searchInput) {
                searchInput.value = dataId;
                searchInput.dispatchEvent(new Event('input', { bubbles: true }));
                searchInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
                console.log(`Mapsd to tab '${tabName}' and searched for '${dataId}'`);
            } else {
                console.log("Search input not found for tab:", tabName);
            }
        }, 100);
    });
}