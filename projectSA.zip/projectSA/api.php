<?php
// ไฟล์: api.php
include 'db.php'; // <--- ตรวจสอบว่า include ไฟล์นี้ถูกต้อง

header('Content-Type: application/json');

// --- HELPER FUNCTIONS ---

// สร้าง ID อัตโนมัติ (เช่น VEG001 -> VEG002)
function getNextID($conn, $column, $table, $prefix)
{
    // ใช้ CAST เพื่อเรียงลำดับตัวเลขให้ถูกต้อง แม้จะมีหลายหลัก (เช่น PLT10 vs PLT100)
    $sql = "SELECT $column FROM $table ORDER BY CAST(SUBSTRING($column, " . (strlen($prefix) + 1) . ") AS UNSIGNED) DESC LIMIT 1";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) { // เพิ่มการตรวจสอบ $result
        $lastID = $result->fetch_assoc()[$column];
        // ใช้ regex เพื่อดึงเฉพาะตัวเลขท้าย ID เผื่อกรณี prefix มีตัวเลข
        preg_match('/(\d+)$/', $lastID, $matches);
        $number = isset($matches[1]) ? (int)$matches[1] + 1 : 1;
    } else {
        $number = 1;
    }
    return $prefix . str_pad($number, 3, '0', STR_PAD_LEFT);
}


// อัปเดตยอดรวมในตาราง sales อัตโนมัติ
function updateSaleTotal($conn, $sale_id)
{
    if (!$conn || empty($sale_id)) return; // เพิ่มการตรวจสอบ
    $stmt = $conn->prepare("UPDATE sales SET total_amount = (SELECT COALESCE(SUM(subtotal), 0) FROM sales_details WHERE sale_id = ?) WHERE sale_id = ?");
    if ($stmt) {
        $stmt->bind_param("ss", $sale_id, $sale_id);
        $stmt->execute();
        $stmt->close();
    } else {
        error_log("Prepare failed (updateSaleTotal): " . $conn->error); // Log error
    }
}

// --- MAIN CONTROLLER ---

$action = $_REQUEST['action'] ?? ''; // ใช้ $_REQUEST เพื่อรับได้ทั้ง GET/POST
$response = ['status' => 'error', 'message' => 'Invalid action'];

switch ($action) {

    // ========== GET ALL DATA (สำหรับโหลดครั้งแรก) ==========
    case 'get_all_data':
        $data = [];
        $tables = ['vegetables', 'planting_cycles', 'plantings', 'care_records', 'harvests', 'sales', 'sales_details'];
        // กำหนดการเรียงลำดับเริ่มต้นสำหรับแต่ละตาราง
        $orderBy = [
            'vegetables' => 'veg_id ASC',
            'planting_cycles' => 'cycle_no ASC',
            'plantings' => 'plant_id ASC',
            'care_records' => 'care_id ASC',
            'harvests' => 'harvest_id ASC',
            'sales' => 'sale_id ASC',
            'sales_details' => 'detail_id ASC'
        ];

        foreach ($tables as $table) {
            $order = $orderBy[$table] ?? 'created_at DESC'; // ใช้ created_at DESC ถ้าไม่ได้กำหนด
            $result = $conn->query("SELECT * FROM $table ORDER BY $order");
            if ($result) {
                $data[$table] = $result->fetch_all(MYSQLI_ASSOC);
            } else {
                $data[$table] = []; // ส่ง array ว่างกลับไปถ้า query ไม่สำเร็จ
                error_log("Error fetching $table: " . $conn->error); // Log error ไว้ดูฝั่ง server
                $response['debug_errors'][] = "Error fetching $table: " . $conn->error; // ส่ง error กลับไป (เผื่อ debug)
            }
        }
        // ตรวจสอบว่ามี error เกิดขึ้นหรือไม่
        if (!isset($response['debug_errors'])) {
            $response = ['status' => 'success', 'data' => $data];
        } else {
            $response['message'] = 'Error fetching some data from database.';
        }
        break;

    // ========== GET SUMMARY DATA ==========
    case 'get_summary':
        $summary = [];
        // ใช้ COALESCE เพื่อให้ได้ 0 หากตารางว่าง
        $summary['totalVegetables'] = $conn->query("SELECT COUNT(*) as c FROM vegetables")->fetch_assoc()['c'] ?? 0;
        $summary['totalCycles'] = $conn->query("SELECT COUNT(*) as c FROM planting_cycles")->fetch_assoc()['c'] ?? 0;
        $summary['totalPlantings'] = $conn->query("SELECT COUNT(*) as c FROM plantings")->fetch_assoc()['c'] ?? 0;
        $summary['totalCares'] = $conn->query("SELECT COUNT(*) as c FROM care_records")->fetch_assoc()['c'] ?? 0;

        $harvestData = $conn->query("SELECT COUNT(*) as totalHarvests, COALESCE(SUM(harvested_amount), 0) as totalHarvestAmount, COALESCE(SUM(diseased_amount), 0) as totalDisease, COALESCE(SUM(dead_amount), 0) as totalDead FROM harvests")->fetch_assoc();
        $summary = array_merge($summary, $harvestData ?: []); // Merge empty array if query fails

        $salesData = $conn->query("SELECT COUNT(*) as totalSalesCount, COALESCE(SUM(total_amount), 0) as totalSalesAmount FROM sales")->fetch_assoc();
        $summary = array_merge($summary, $salesData ?: []); // Merge empty array if query fails
        $summary['totalSalesDetails'] = $conn->query("SELECT COUNT(*) as c FROM sales_details")->fetch_assoc()['c'] ?? 0;

        // กิจกรรมล่าสุด (เรียงตามวันที่ก่อน แล้วตาม ID ล่าสุด)
        $latestHarvest = $conn->query("SELECT harvest_id, harvest_date FROM harvests ORDER BY harvest_date DESC, harvest_id DESC LIMIT 1")->fetch_assoc();
        $latestSale = $conn->query("SELECT sale_id, sale_date, total_amount FROM sales ORDER BY sale_date DESC, sale_id DESC LIMIT 1")->fetch_assoc();
        $latestCare = $conn->query("SELECT care_id, plant_id, start_date FROM care_records ORDER BY start_date DESC, care_id DESC LIMIT 1")->fetch_assoc();

        // Set Text (ใช้ number_format)
        $summary['latestHarvestText'] = $latestHarvest ? "{$latestHarvest['harvest_id']} (วันที่ {$latestHarvest['harvest_date']})" : 'ยังไม่มีข้อมูล';
        $summary['latestSaleText'] = $latestSale ? "{$latestSale['sale_id']} (วันที่ {$latestSale['sale_date']} - ยอด " . number_format($latestSale['total_amount'], 2) . " บาท)" : 'ยังไม่มีข้อมูล';
        $summary['latestCareText'] = $latestCare ? "{$latestCare['care_id']} (รหัสปลูก {$latestCare['plant_id']} - วันที่ {$latestCare['start_date']})" : 'ยังไม่มีข้อมูล';

        // Set raw IDs for dashboard clicks
        $summary['latestHarvestId'] = $latestHarvest ? $latestHarvest['harvest_id'] : null;
        $summary['latestSaleId'] = $latestSale ? $latestSale['sale_id'] : null;
        $summary['latestCareId'] = $latestCare ? $latestCare['care_id'] : null;

        $response = ['status' => 'success', 'data' => $summary];
        break;

    // ========== NEW CASE: ADD CYCLE WITH MULTIPLE PLANTINGS ==========
    case 'add_cycle_with_plantings':
        $planting_date = $_POST['planting_date'] ?? null;
        $plantings_json = $_POST['plantings'] ?? null;
        $plantings = json_decode($plantings_json, true);

        if (!$planting_date || !$plantings || !is_array($plantings) || empty($plantings)) {
            $response['message'] = 'ข้อมูลไม่ครบถ้วน (วันที่ หรือ รายการปลูก)';
            break;
        }

        $conn->begin_transaction();
        $new_cycle_no = null;

        try {
            // 1. Calculate total plants
            $total_plants = 0;
            foreach ($plantings as $p) {
                if (!isset($p['quantity']) || !is_numeric($p['quantity']) || (int)$p['quantity'] <= 0) {
                    throw new Exception("จำนวนต้นไม่ถูกต้องในรายการปลูก");
                }
                $total_plants += (int)$p['quantity'];
            }
            if ($total_plants <= 0) {
                throw new Exception("จำนวนต้นรวมต้องมากกว่า 0");
            }

            // 2. Insert into planting_cycles
            $stmt_cycle = $conn->prepare("INSERT INTO planting_cycles (planting_date, total_plants) VALUES (?, ?)");
            if (!$stmt_cycle) throw new Exception("Prepare failed (cycle): " . $conn->error);
            $stmt_cycle->bind_param("si", $planting_date, $total_plants);
            if (!$stmt_cycle->execute()) throw new Exception("Execute failed (cycle): " . $stmt_cycle->error);

            $new_cycle_no = $conn->insert_id;
            $stmt_cycle->close();

            if (!$new_cycle_no) throw new Exception("Failed to get new cycle number.");

            // 3. Loop and Insert into plantings
            $stmt_plant = $conn->prepare("INSERT INTO plantings (plant_id, cycle_no, veg_id, quantity, plot_name) VALUES (?, ?, ?, ?, ?)");
            if (!$stmt_plant) throw new Exception("Prepare failed (planting): " . $conn->error);

            foreach ($plantings as $p) {
                if (empty($p['veg_id']) || empty($p['plot_name'])) {
                    throw new Exception("ข้อมูลรายการปลูก (ผัก/แปลง) ไม่ครบถ้วน");
                }
                $plant_id = getNextID($conn, 'plant_id', 'plantings', 'PLT'); // สร้าง ID ใหม่ทุกครั้ง
                $veg_id = $p['veg_id'];
                $quantity = (int)$p['quantity'];
                $plot_name = $p['plot_name'];

                $stmt_plant->bind_param("sisis", $plant_id, $new_cycle_no, $veg_id, $quantity, $plot_name);
                if (!$stmt_plant->execute()) {
                    error_log("Execute failed (planting item " . $plant_id . "): " . $stmt_plant->error);
                    throw new Exception("Execute failed (planting item)");
                }
            }
            $stmt_plant->close();

            // Commit transaction
            $conn->commit();
            $response = ['status' => 'success', 'message' => 'บันทึกรอบการปลูก ' . $new_cycle_no . ' และรายการปลูก ' . count($plantings) . ' รายการสำเร็จ'];
        } catch (Exception $e) {
            // Rollback on error
            $conn->rollback();
            $response['message'] = 'เกิดข้อผิดพลาดในการบันทึก: ' . $e->getMessage();
            error_log("Transaction failed (add_cycle_with_plantings): " . $e->getMessage());
        }
        break;

    // ========== MANAGE VEGETABLES ==========
    case 'manage_vegetable':
        $veg_id = $_POST['veg_id'] ?? '';
        $veg_name = trim($_POST['veg_name'] ?? ''); // ใช้ trim เพื่อตัดช่องว่าง
        $duration = filter_input(INPUT_POST, 'duration', FILTER_VALIDATE_INT);
        $price = filter_input(INPUT_POST, 'price_per_unit', FILTER_VALIDATE_FLOAT);

        // --- เพิ่ม Validation ---
        if (empty($veg_name) || $duration === false || $duration <= 0 || $price === false || $price < 0) {
            $response['message'] = 'ข้อมูลผักไม่ถูกต้อง (ชื่อ, ระยะเวลา > 0, ราคา >= 0)';
            break;
        }

        if (empty($veg_id)) { // เพิ่มใหม่
            $veg_id = getNextID($conn, 'veg_id', 'vegetables', 'VEG');
            $stmt = $conn->prepare("INSERT INTO vegetables (veg_id, veg_name, duration, price_per_unit) VALUES (?, ?, ?, ?)");
            if (!$stmt) {
                $response['message'] = "Prepare failed: " . $conn->error;
                break;
            }
            $stmt->bind_param("sssd", $veg_id, $veg_name, $duration, $price);
        } else { // แก้ไข
            $stmt = $conn->prepare("UPDATE vegetables SET veg_name = ?, duration = ?, price_per_unit = ? WHERE veg_id = ?");
            if (!$stmt) {
                $response['message'] = "Prepare failed: " . $conn->error;
                break;
            }
            $stmt->bind_param("sids", $veg_name, $duration, $price, $veg_id);
        }

        if ($stmt->execute()) {
            $response = ['status' => 'success', 'message' => (empty($_POST['veg_id']) ? 'เพิ่ม' : 'แก้ไข') . 'ข้อมูลผักสำเร็จ'];
        } else {
            $response['message'] = 'Error: ' . $stmt->error;
        }
        $stmt->close();
        break;

    case 'delete_vegetable':
        $veg_id = $_POST['veg_id'] ?? '';
        if (empty($veg_id)) {
            $response['message'] = "Missing veg_id";
            break;
        }

        $stmt = $conn->prepare("DELETE FROM vegetables WHERE veg_id = ?");
        if (!$stmt) {
            $response['message'] = "Prepare failed: " . $conn->error;
            break;
        }
        $stmt->bind_param("s", $veg_id);
        if ($stmt->execute()) {
            $response = ['status' => 'success', 'message' => 'ลบข้อมูลผักสำเร็จ'];
        } else {
            // Check for foreign key constraint error
            if ($conn->errno == 1451) { // Error code for foreign key constraint fail
                $response['message'] = 'Error: ไม่สามารถลบผักได้เนื่องจากมีการใช้งานข้อมูลนี้อยู่ในตารางการปลูก';
            } else {
                $response['message'] = 'Error: ' . $stmt->error;
            }
        }
        $stmt->close();
        break;

    // ========== MANAGE PLANTING CYCLES ==========
    case 'manage_planting_cycle': // **Corrected Validation Logic Here**
        $cycle_no = filter_input(INPUT_POST, 'cycle_no', FILTER_VALIDATE_INT);
        $planting_date = $_POST['planting_date'] ?? '';

        // Validate planting_date format
        if (empty($planting_date) || !preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/", $planting_date)) {
            $response['message'] = 'รูปแบบวันที่ไม่ถูกต้อง (YYYY-MM-DD)';
            break;
        }

        // Validate total_plants ONLY if it's a NEW record (cycle_no is empty)
        if (empty($cycle_no)) {
            // This block might be redundant if using the combined form exclusively
            $total_plants_insert = filter_input(INPUT_POST, 'total_plants', FILTER_VALIDATE_INT);
            if ($total_plants_insert === false || $total_plants_insert <= 0) {
                $response['message'] = 'ข้อมูลรอบการปลูกไม่ถูกต้อง (จำนวนต้น > 0)';
                break;
            }
            $stmt = $conn->prepare("INSERT INTO planting_cycles (planting_date, total_plants) VALUES (?, ?)");
            if (!$stmt) {
                $response['message'] = "Prepare failed (insert cycle): " . $conn->error;
                break;
            }
            $stmt->bind_param("si", $planting_date, $total_plants_insert);
        } else { // EDIT record: Only need cycle_no and planting_date
            $stmt = $conn->prepare("UPDATE planting_cycles SET planting_date = ? WHERE cycle_no = ?");
            if (!$stmt) {
                $response['message'] = "Prepare failed (update cycle): " . $conn->error;
                break;
            }
            $stmt->bind_param("si", $planting_date, $cycle_no);
        }

        // --- Execute statement ---
        if ($stmt->execute()) {
            $response = ['status' => 'success', 'message' => (empty($cycle_no) ? 'เพิ่ม' : 'แก้ไข') . 'รอบการปลูกสำเร็จ'];
        } else {
            $response['message'] = 'Error: ' . $stmt->error;
        }
        $stmt->close();
        break; // End of case 'manage_planting_cycle'


    case 'delete_planting_cycle':
        $cycle_no = filter_input(INPUT_POST, 'cycle_no', FILTER_VALIDATE_INT);
        if ($cycle_no === false || $cycle_no <= 0) {
            $response['message'] = "Invalid cycle_no";
            break;
        }

        $stmt = $conn->prepare("DELETE FROM planting_cycles WHERE cycle_no = ?");
        if (!$stmt) {
            $response['message'] = "Prepare failed: " . $conn->error;
            break;
        }
        $stmt->bind_param("i", $cycle_no);
        if ($stmt->execute()) {
            $response = ['status' => 'success', 'message' => 'ลบรอบการปลูกสำเร็จ (ข้อมูลที่เกี่ยวข้องถูกลบด้วย Cascade)'];
        } else {
            $response['message'] = 'Error: ' . $stmt->error;
        }
        $stmt->close();
        break;

    // ========== MANAGE PLANTINGS ==========
    // (Keep manage_planting and delete_planting cases if you need separate editing/deleting functionality)
    case 'manage_planting':
        $plant_id = $_POST['plant_id'] ?? '';
        $cycle_no = filter_input(INPUT_POST, 'cycle_no', FILTER_VALIDATE_INT);
        $veg_id = $_POST['veg_id'] ?? '';
        $quantity = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT);
        $plot_name = trim($_POST['plot_name'] ?? '');

        if ($cycle_no === false || $cycle_no <= 0 || empty($veg_id) || $quantity === false || $quantity <= 0 || empty($plot_name)) {
            $response['message'] = 'ข้อมูลการปลูกไม่ถูกต้อง';
            break;
        }

        if (empty($plant_id)) { // เพิ่มใหม่ (Unlikely needed with combined form)
            $plant_id = getNextID($conn, 'plant_id', 'plantings', 'PLT');
            $stmt = $conn->prepare("INSERT INTO plantings (plant_id, cycle_no, veg_id, quantity, plot_name) VALUES (?, ?, ?, ?, ?)");
            if (!$stmt) {
                $response['message'] = "Prepare failed: " . $conn->error;
                break;
            }
            $stmt->bind_param("sisis", $plant_id, $cycle_no, $veg_id, $quantity, $plot_name);
        } else { // แก้ไข
            $stmt = $conn->prepare("UPDATE plantings SET cycle_no = ?, veg_id = ?, quantity = ?, plot_name = ? WHERE plant_id = ?");
            if (!$stmt) {
                $response['message'] = "Prepare failed: " . $conn->error;
                break;
            }
            $stmt->bind_param("isiss", $cycle_no, $veg_id, $quantity, $plot_name, $plant_id);
        }

        if ($stmt->execute()) {
            $response = ['status' => 'success', 'message' => (empty($_POST['plant_id']) ? 'เพิ่ม' : 'แก้ไข') . 'ข้อมูลการปลูกสำเร็จ'];
        } else {
            $response['message'] = 'Error: ' . $stmt->error;
        }
        $stmt->close();
        break;

    case 'delete_planting':
        $plant_id = $_POST['plant_id'] ?? '';
        if (empty($plant_id)) {
            $response['message'] = "Missing plant_id";
            break;
        }

        $stmt = $conn->prepare("DELETE FROM plantings WHERE plant_id = ?");
        if (!$stmt) {
            $response['message'] = "Prepare failed: " . $conn->error;
            break;
        }
        $stmt->bind_param("s", $plant_id);
        if ($stmt->execute()) {
            $response = ['status' => 'success', 'message' => 'ลบข้อมูลการปลูกสำเร็จ (ข้อมูลที่เกี่ยวข้องถูกลบด้วย Cascade)'];
        } else {
            $response['message'] = 'Error: ' . $stmt->error;
        }
        $stmt->close();
        break;

    // ========== MANAGE CARE RECORDS ==========
    case 'manage_care_record':
        $care_id = $_POST['care_id'] ?? '';
        $plant_id = $_POST['plant_id'] ?? '';
        $start_date = $_POST['start_date'] ?? '';
        $end_date = $_POST['end_date'] ?? '';
        $care_round = filter_input(INPUT_POST, 'care_round', FILTER_VALIDATE_INT);
        $notes = trim($_POST['notes'] ?? '');

        if (empty($plant_id) || empty($start_date) || empty($end_date) || $care_round === false || $care_round <= 0 || strtotime($end_date) < strtotime($start_date)) {
            $response['message'] = 'ข้อมูลการดูแลไม่ถูกต้อง (รหัสปลูก, วันที่เริ่ม/สิ้นสุด, รอบ > 0)';
            break;
        }

        if (empty($care_id)) { // เพิ่มใหม่
            $care_id = getNextID($conn, 'care_id', 'care_records', 'CARE');
            $stmt = $conn->prepare("INSERT INTO care_records (care_id, plant_id, start_date, end_date, care_round, notes) VALUES (?, ?, ?, ?, ?, ?)");
            if (!$stmt) {
                $response['message'] = "Prepare failed: " . $conn->error;
                break;
            }
            $stmt->bind_param("ssssis", $care_id, $plant_id, $start_date, $end_date, $care_round, $notes);
        } else { // แก้ไข
            $stmt = $conn->prepare("UPDATE care_records SET plant_id = ?, start_date = ?, end_date = ?, care_round = ?, notes = ? WHERE care_id = ?");
            if (!$stmt) {
                $response['message'] = "Prepare failed: " . $conn->error;
                break;
            }
            $stmt->bind_param("ssisss", $plant_id, $start_date, $end_date, $care_round, $notes, $care_id);
        }

        if ($stmt->execute()) {
            $response = ['status' => 'success', 'message' => (empty($_POST['care_id']) ? 'เพิ่ม' : 'แก้ไข') . 'ข้อมูลการดูแลสำเร็จ'];
        } else {
            $response['message'] = 'Error: ' . $stmt->error;
        }
        $stmt->close();
        break;

    case 'delete_care_record':
        $care_id = $_POST['care_id'] ?? '';
        if (empty($care_id)) {
            $response['message'] = "Missing care_id";
            break;
        }

        $stmt = $conn->prepare("DELETE FROM care_records WHERE care_id = ?");
        if (!$stmt) {
            $response['message'] = "Prepare failed: " . $conn->error;
            break;
        }
        $stmt->bind_param("s", $care_id);
        if ($stmt->execute()) {
            $response = ['status' => 'success', 'message' => 'ลบข้อมูลการดูแลสำเร็จ'];
        } else {
            $response['message'] = 'Error: ' . $stmt->error;
        }
        $stmt->close();
        break;

    // ========== MANAGE HARVESTS ==========
    case 'manage_harvest':
        $harvest_id = $_POST['harvest_id'] ?? '';
        $plant_id = $_POST['plant_id'] ?? '';
        $cycle_no = filter_input(INPUT_POST, 'cycle_no', FILTER_VALIDATE_INT);
        $harvest_date = $_POST['harvest_date'] ?? '';
        $harvested_amount = filter_input(INPUT_POST, 'harvested_amount', FILTER_VALIDATE_INT);
        $diseased_amount = filter_input(INPUT_POST, 'diseased_amount', FILTER_VALIDATE_INT, ['options' => ['default' => 0, 'min_range' => 0]]);
        $dead_amount = filter_input(INPUT_POST, 'dead_amount', FILTER_VALIDATE_INT, ['options' => ['default' => 0, 'min_range' => 0]]);

        if (empty($plant_id) || $cycle_no === false || $cycle_no <= 0 || empty($harvest_date) || $harvested_amount === false || $harvested_amount < 0 || $diseased_amount === false || $dead_amount === false) {
            $response['message'] = 'ข้อมูลการเก็บเกี่ยวไม่ถูกต้อง';
            break;
        }

        if (empty($harvest_id)) { // เพิ่มใหม่
            $harvest_id = getNextID($conn, 'harvest_id', 'harvests', 'HRV');
            $stmt = $conn->prepare("INSERT INTO harvests (harvest_id, plant_id, cycle_no, harvest_date, harvested_amount, diseased_amount, dead_amount) VALUES (?, ?, ?, ?, ?, ?, ?)");
            if (!$stmt) {
                $response['message'] = "Prepare failed: " . $conn->error;
                break;
            }
            $stmt->bind_param("ssisiii", $harvest_id, $plant_id, $cycle_no, $harvest_date, $harvested_amount, $diseased_amount, $dead_amount);
        } else { // แก้ไข
            $stmt = $conn->prepare("UPDATE harvests SET plant_id = ?, cycle_no = ?, harvest_date = ?, harvested_amount = ?, diseased_amount = ?, dead_amount = ? WHERE harvest_id = ?");
            if (!$stmt) {
                $response['message'] = "Prepare failed: " . $conn->error;
                break;
            }
            $stmt->bind_param("sisiiis", $plant_id, $cycle_no, $harvest_date, $harvested_amount, $diseased_amount, $dead_amount, $harvest_id);
        }

        if ($stmt->execute()) {
            $response = ['status' => 'success', 'message' => (empty($_POST['harvest_id']) ? 'เพิ่ม' : 'แก้ไข') . 'ข้อมูลเก็บเกี่ยวสำเร็จ'];
        } else {
            $response['message'] = 'Error: ' . $stmt->error;
        }
        $stmt->close();
        break;

    case 'delete_harvest':
        $harvest_id = $_POST['harvest_id'] ?? '';
        if (empty($harvest_id)) {
            $response['message'] = "Missing harvest_id";
            break;
        }

        $stmt = $conn->prepare("DELETE FROM harvests WHERE harvest_id = ?");
        if (!$stmt) {
            $response['message'] = "Prepare failed: " . $conn->error;
            break;
        }
        $stmt->bind_param("s", $harvest_id);
        if ($stmt->execute()) {
            $response = ['status' => 'success', 'message' => 'ลบข้อมูลเก็บเกี่ยวสำเร็จ (ข้อมูลที่เกี่ยวข้องถูกลบด้วย Cascade)'];
        } else {
            if ($conn->errno == 1451) {
                $response['message'] = 'Error: ไม่สามารถลบได้เนื่องจากมีการใช้งานข้อมูลนี้อยู่ในรายละเอียดการขาย';
            } else {
                $response['message'] = 'Error: ' . $stmt->error;
            }
        }
        $stmt->close();
        break;

    // ========== MANAGE SALES ==========
    case 'manage_sale':
        $sale_id = $_POST['sale_id'] ?? '';
        $sale_date = $_POST['sale_date'] ?? '';

        if (empty($sale_date) || !preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/", $sale_date)) {
            $response['message'] = 'ข้อมูลการขาย (วันที่) ไม่ถูกต้อง';
            break;
        }

        if (empty($sale_id)) { // เพิ่มใหม่ - ยอดเริ่มต้นเป็น 0
            $sale_id = getNextID($conn, 'sale_id', 'sales', 'SALE');
            $stmt = $conn->prepare("INSERT INTO sales (sale_id, sale_date, total_amount) VALUES (?, ?, 0.00)");
            if (!$stmt) {
                $response['message'] = "Prepare failed: " . $conn->error;
                break;
            }
            $stmt->bind_param("ss", $sale_id, $sale_date);
        } else { // แก้ไข - อนุญาตให้แก้แค่วันที่
            $stmt = $conn->prepare("UPDATE sales SET sale_date = ? WHERE sale_id = ?");
            if (!$stmt) {
                $response['message'] = "Prepare failed: " . $conn->error;
                break;
            }
            $stmt->bind_param("ss", $sale_date, $sale_id);
        }

        if ($stmt->execute()) {
            $response = ['status' => 'success', 'message' => (empty($_POST['sale_id']) ? 'เพิ่ม' : 'แก้ไข') . 'ข้อมูลการขายสำเร็จ'];
            if (empty($_POST['sale_id'])) {
                $response['new_sale_id'] = $sale_id;
            }
        } else {
            $response['message'] = 'Error: ' . $stmt->error;
        }
        $stmt->close();
        break;

    case 'delete_sale':
        $sale_id = $_POST['sale_id'] ?? '';
        if (empty($sale_id)) {
            $response['message'] = "Missing sale_id";
            break;
        }

        $stmt = $conn->prepare("DELETE FROM sales WHERE sale_id = ?");
        if (!$stmt) {
            $response['message'] = "Prepare failed: " . $conn->error;
            break;
        }
        $stmt->bind_param("s", $sale_id);
        if ($stmt->execute()) {
            $response = ['status' => 'success', 'message' => 'ลบข้อมูลการขายสำเร็จ (รายละเอียดการขายถูกลบด้วย Cascade)'];
        } else {
            $response['message'] = 'Error: ' . $stmt->error;
        }
        $stmt->close();
        break;

    // ========== MANAGE SALES DETAILS ==========
    case 'manage_sales_detail':
        $detail_id = filter_input(INPUT_POST, 'detail_id', FILTER_VALIDATE_INT);
        $harvest_id = $_POST['harvest_id'] ?? '';
        $sale_id = $_POST['sale_id'] ?? '';
        $quantity = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT);
        $subtotal = filter_input(INPUT_POST, 'subtotal', FILTER_VALIDATE_FLOAT);

        if (empty($harvest_id) || empty($sale_id) || $quantity === false || $quantity <= 0 || $subtotal === false || $subtotal < 0) {
            $response['message'] = 'ข้อมูลรายละเอียดการขายไม่ถูกต้อง';
            break;
        }

        // --- Stock Check ---
        $stock_check_sql = "SELECT harvested_amount FROM harvests WHERE harvest_id = ?";
        $stmt_stock = $conn->prepare($stock_check_sql);
        if (!$stmt_stock) {
            $response['message'] = "Prepare failed (stock check): " . $conn->error;
            break;
        }
        $stmt_stock->bind_param("s", $harvest_id);
        $stmt_stock->execute();
        $stock_result = $stmt_stock->get_result();
        $harvest_record = $stock_result->fetch_assoc();
        $stmt_stock->close();

        if (!$harvest_record) {
            $response['message'] = 'ไม่พบข้อมูลการเก็บเกี่ยวที่อ้างอิง';
            break;
        }
        $total_harvested = (int)$harvest_record['harvested_amount'];

        $sold_check_sql = "SELECT COALESCE(SUM(quantity), 0) as total_sold FROM sales_details WHERE harvest_id = ? AND detail_id != ?";
        $stmt_sold = $conn->prepare($sold_check_sql);
        if (!$stmt_sold) {
            $response['message'] = "Prepare failed (sold check): " . $conn->error;
            break;
        }
        $current_detail_id = $detail_id ?: 0;
        $stmt_sold->bind_param("si", $harvest_id, $current_detail_id);
        $stmt_sold->execute();
        $sold_result = $stmt_sold->get_result();
        $already_sold = (int)$sold_result->fetch_assoc()['total_sold'];
        $stmt_sold->close();

        $available_stock = $total_harvested - $already_sold;

        if ($quantity > $available_stock) {
            $response['message'] = "เกิดข้อผิดพลาด: จำนวนขาย ($quantity) เกินจำนวนคงเหลือ ($available_stock)";
            break;
        }
        // --- End Stock Check ---

        $old_sale_id = null;
        if (!empty($detail_id)) {
            $res = $conn->query("SELECT sale_id FROM sales_details WHERE detail_id = " . (int)$detail_id);
            if ($res && $res->num_rows > 0) {
                $old_sale_id = $res->fetch_assoc()['sale_id'];
            }
        }

        if (empty($detail_id)) { // Add new
            $stmt = $conn->prepare("INSERT INTO sales_details (harvest_id, sale_id, quantity, subtotal) VALUES (?, ?, ?, ?)");
            if (!$stmt) {
                $response['message'] = "Prepare failed: " . $conn->error;
                break;
            }
            $stmt->bind_param("ssid", $harvest_id, $sale_id, $quantity, $subtotal);
        } else { // Edit existing
            $stmt = $conn->prepare("UPDATE sales_details SET harvest_id = ?, sale_id = ?, quantity = ?, subtotal = ? WHERE detail_id = ?");
            if (!$stmt) {
                $response['message'] = "Prepare failed: " . $conn->error;
                break;
            }
            $stmt->bind_param("ssidi", $harvest_id, $sale_id, $quantity, $subtotal, $detail_id);
        }

        if ($stmt->execute()) {
            updateSaleTotal($conn, $sale_id);
            if ($old_sale_id && $old_sale_id !== $sale_id) {
                updateSaleTotal($conn, $old_sale_id);
            }
            $response = ['status' => 'success', 'message' => (empty($_POST['detail_id']) ? 'เพิ่ม' : 'แก้ไข') . 'รายละเอียดการขายสำเร็จ'];
        } else {
            $response['message'] = 'Error: ' . $stmt->error;
        }
        $stmt->close();
        break;

    case 'delete_sales_detail':
        $detail_id = filter_input(INPUT_POST, 'detail_id', FILTER_VALIDATE_INT);
        if ($detail_id === false || $detail_id <= 0) {
            $response['message'] = "Invalid detail_id";
            break;
        }

        $sale_id = null;
        $stmt_get_sale = $conn->prepare("SELECT sale_id FROM sales_details WHERE detail_id = ?");
        if ($stmt_get_sale) {
            $stmt_get_sale->bind_param("i", $detail_id);
            $stmt_get_sale->execute();
            $result = $stmt_get_sale->get_result();
            if ($result->num_rows > 0) {
                $sale_id = $result->fetch_assoc()['sale_id'];
            }
            $stmt_get_sale->close();
        }

        if ($sale_id) {
            $stmt = $conn->prepare("DELETE FROM sales_details WHERE detail_id = ?");
            if (!$stmt) {
                $response['message'] = "Prepare failed: " . $conn->error;
                break;
            }
            $stmt->bind_param("i", $detail_id);

            if ($stmt->execute()) {
                updateSaleTotal($conn, $sale_id);
                $response = ['status' => 'success', 'message' => 'ลบรายละเอียดการขายสำเร็จ'];
            } else {
                $response['message'] = 'Error: ' . $stmt->error;
            }
            $stmt->close();
        } else {
            $response['message'] = 'ไม่พบรายการที่จะลบ หรือไม่สามารถดึงข้อมูล sale_id ได้';
        }
        break;

    default:
        // Keep the default message initialized at the top
        break;
}

$conn->close();
echo json_encode($response);
